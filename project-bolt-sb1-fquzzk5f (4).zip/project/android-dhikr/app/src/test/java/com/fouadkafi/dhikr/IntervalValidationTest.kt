package com.fouadkafi.dhikr

import com.fouadkafi.dhikr.domain.AppSettings
import com.fouadkafi.dhikr.domain.Milestones
import org.junit.Assert.*
import org.junit.Test

class IntervalValidationTest {

    @Test
    fun `Interval presets contain expected values`() {
        val presets = Milestones.INTERVAL_PRESETS
        assertTrue(presets.contains(1))
        assertTrue(presets.contains(5))
        assertTrue(presets.contains(10))
        assertTrue(presets.contains(60))
    }

    @Test
    fun `Friday presets contain 2 minute default`() {
        val presets = Milestones.FRIDAY_PRESETS
        assertTrue(presets.contains(2))
    }

    @Test
    fun `All milestones are sorted ascending`() {
        val milestones = Milestones.ALL
        for (i in 1 until milestones.size) {
            assertTrue(milestones[i].count > milestones[i - 1].count)
        }
    }

    @Test
    fun `Milestone count 100 exists`() {
        assertTrue(Milestones.ALL.any { it.count == 100 })
    }

    @Test
    fun `Milestone count 10000 exists`() {
        assertTrue(Milestones.ALL.any { it.count == 10000 })
    }

    @Test
    fun `Default settings have sensible values`() {
        val settings = AppSettings()
        assertEquals(10, settings.reminderIntervalMinutes)
        assertEquals(2, settings.fridayIntervalMinutes)
        assertEquals(100, settings.dailyGoal)
        assertTrue(settings.fridayModeEnabled)
        assertTrue(settings.animationsEnabled)
        assertFalse(settings.remindersEnabled)
    }
}
