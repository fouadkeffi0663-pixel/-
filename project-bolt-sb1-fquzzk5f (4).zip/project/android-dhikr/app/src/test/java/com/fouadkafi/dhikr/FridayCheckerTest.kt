package com.fouadkafi.dhikr

import com.fouadkafi.dhikr.domain.AppSettings
import com.fouadkafi.dhikr.domain.FridayCalcMethod
import com.fouadkafi.dhikr.friday.FridayChecker
import org.junit.Assert.*
import org.junit.Test
import java.time.DayOfWeek
import java.time.LocalTime
import java.time.ZonedDateTime
import java.time.ZoneId

class FridayCheckerTest {

    private val baseSettings = AppSettings(
        fridayModeEnabled = true,
        fridayCalcMethod = FridayCalcMethod.MANUAL,
        manualFridaySunset = "18:30"
    )

    @Test
    fun `Thursday before sunset is not Friday period`() {
        val thu = ZonedDateTime.of(2026, 10, 15, 10, 0, 0, 0, ZoneId.systemDefault())
        assertEquals(DayOfWeek.THURSDAY, thu.dayOfWeek)
        assertFalse(FridayChecker.isFridayPeriod(baseSettings, thu))
    }

    @Test
    fun `Thursday after sunset is Friday period`() {
        val thuEvening = ZonedDateTime.of(2026, 10, 15, 19, 0, 0, 0, ZoneId.systemDefault())
        assertEquals(DayOfWeek.THURSDAY, thuEvening.dayOfWeek)
        assertTrue(FridayChecker.isFridayPeriod(baseSettings, thuEvening))
    }

    @Test
    fun `Friday before sunset is Friday period`() {
        val friMorning = ZonedDateTime.of(2026, 10, 16, 8, 0, 0, 0, ZoneId.systemDefault())
        assertEquals(DayOfWeek.FRIDAY, friMorning.dayOfWeek)
        assertTrue(FridayChecker.isFridayPeriod(baseSettings, friMorning))
    }

    @Test
    fun `Friday after sunset is not Friday period`() {
        val friEvening = ZonedDateTime.of(2026, 10, 16, 19, 0, 0, 0, ZoneId.systemDefault())
        assertEquals(DayOfWeek.FRIDAY, friEvening.dayOfWeek)
        assertFalse(FridayChecker.isFridayPeriod(baseSettings, friEvening))
    }

    @Test
    fun `Saturday is never Friday period`() {
        val sat = ZonedDateTime.of(2026, 10, 17, 10, 0, 0, 0, ZoneId.systemDefault())
        assertEquals(DayOfWeek.SATURDAY, sat.dayOfWeek)
        assertFalse(FridayChecker.isFridayPeriod(baseSettings, sat))
    }

    @Test
    fun `Disabled friday mode returns false always`() {
        val disabled = baseSettings.copy(fridayModeEnabled = false)
        val friMorning = ZonedDateTime.of(2026, 10, 16, 8, 0, 0, 0, ZoneId.systemDefault())
        assertFalse(FridayChecker.isFridayPeriod(disabled, friMorning))
    }

    @Test
    fun `Astronomical method uses approximate sunset`() {
        val astronomical = baseSettings.copy(fridayCalcMethod = FridayCalcMethod.ASTRONOMICAL)
        val thuEvening = ZonedDateTime.of(2026, 10, 15, 19, 0, 0, 0, ZoneId.systemDefault())
        assertTrue(FridayChecker.isFridayPeriod(astronomical, thuEvening))
    }

    @Test
    fun `getCurrentInterval returns friday interval during friday period`() {
        val settings = baseSettings.copy(reminderIntervalMinutes = 10, fridayIntervalMinutes = 2)
        val friMorning = ZonedDateTime.of(2026, 10, 16, 8, 0, 0, 0, ZoneId.systemDefault())
        assertEquals(2, FridayChecker.getCurrentInterval(settings, friMorning))
    }

    @Test
    fun `getCurrentInterval returns standard interval outside friday period`() {
        val settings = baseSettings.copy(reminderIntervalMinutes = 10, fridayIntervalMinutes = 2)
        val sat = ZonedDateTime.of(2026, 10, 17, 10, 0, 0, 0, ZoneId.systemDefault())
        assertEquals(10, FridayChecker.getCurrentInterval(settings, sat))
    }
}
