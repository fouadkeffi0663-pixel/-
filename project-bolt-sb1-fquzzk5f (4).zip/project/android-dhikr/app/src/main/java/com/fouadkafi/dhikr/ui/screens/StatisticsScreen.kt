package com.fouadkafi.dhikr.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fouadkafi.dhikr.domain.*
import com.fouadkafi.dhikr.ui.components.IslamicPatternBackground
import com.fouadkafi.dhikr.ui.theme.*

@Composable
fun StatisticsScreen(
    settings: AppSettings?,
    onNavigate: (String) -> Unit
) {
    val lang = settings?.language ?: Language.ARABIC
    var showResetDialog by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Midnight, Color(0xFF031410))))
    ) {
        IslamicPatternBackground(color = Champagne, alpha = 0.03f)

        Column(
            modifier = Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Spacer(modifier = Modifier.height(20.dp))

            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = { onNavigate("dashboard") }) {
                    Text("←", color = Ivory, fontSize = 22.sp)
                }
                Text(
                    text = if (lang == Language.ARABIC) "الإحصائيات" else "Statistics",
                    color = Ivory, fontSize = 18.sp, fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(40.dp))
            }

            // Summary
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                StatBox(if (lang == Language.ARABIC) "الإجمالي" else "Lifetime", "0", Champagne, Modifier.weight(1f))
                StatBox(if (lang == Language.ARABIC) "أفضل يوم" else "Best Day", "0", EmeraldLight, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                StatBox(if (lang == Language.ARABIC) "السلسلة" else "Streak", "0", EmeraldLight, Modifier.weight(1f))
                StatBox(if (lang == Language.ARABIC) "اليوم" else "Today", "0", Champagne, Modifier.weight(1f))
            }

            // Achievements
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = EmeraldDeep.copy(alpha = 0.4f),
                border = BorderStroke(0.5.dp, Champagne.copy(alpha = 0.1f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (lang == Language.ARABIC) "الإنجازات" else "Achievements",
                        color = Ivory, fontSize = 14.sp, fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    // Milestone grid
                    Milestones.ALL.chunked(3).forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            row.forEach { m ->
                                val unlocked = false
                                Surface(
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (unlocked) Champagne.copy(alpha = 0.15f) else Color(0xFF052016).copy(alpha = 0.5f),
                                    border = BorderStroke(0.5.dp, if (unlocked) Champagne.copy(alpha = 0.3f) else Champagne.copy(alpha = 0.05f))
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = if (unlocked) "★" else "○",
                                            color = if (unlocked) Champagne else Ivory.copy(alpha = 0.2f),
                                            fontSize = 18.sp
                                        )
                                        Text(
                                            text = m.count.toString(),
                                            color = if (unlocked) Champagne else Ivory.copy(alpha = 0.3f),
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = if (unlocked) (if (lang == Language.ARABIC) "مفتوح" else "Unlocked")
                                                   else (if (lang == Language.ARABIC) "مغلق" else "Locked"),
                                            color = if (unlocked) Champagne.copy(alpha = 0.6f) else Ivory.copy(alpha = 0.3f),
                                            fontSize = 9.sp
                                        )
                                    }
                                }
                            }
                            // Fill remaining slots
                            repeat(3 - row.size) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }

            // Streak info
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = EmeraldDeep.copy(alpha = 0.3f),
                border = BorderStroke(0.5.dp, Champagne.copy(alpha = 0.08f))
            ) {
                Text(
                    text = if (lang == Language.ARABIC)
                        "تحسب السلسلة من النشاط اليومي الفعلي. يوم متتالي = سلسلة +1."
                    else
                        "Streak is calculated from actual daily activity. Consecutive day = streak +1.",
                    color = Ivory.copy(alpha = 0.5f),
                    fontSize = 11.sp,
                    modifier = Modifier.padding(16.dp)
                )
            }

            // Reset button
            OutlinedButton(
                onClick = { showResetDialog = true },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF884444))
            ) {
                Text(if (lang == Language.ARABIC) "إعادة تعيين الإحصائيات" else "Reset Statistics")
            }

            BottomNav(lang, "statistics", onNavigate)
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text(if (lang == Language.ARABIC) "إعادة تعيين جميع الإحصائيات؟" else "Reset all statistics?") },
            text = { Text(if (lang == Language.ARABIC) "لا يمكن التراجع عن هذا الإجراء." else "This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text(if (lang == Language.ARABIC) "تأكيد" else "Confirm", color = Color(0xFF884444))
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text(if (lang == Language.ARABIC) "إلغاء" else "Cancel")
                }
            },
            containerColor = EmeraldDeep
        )
    }
}

@Composable
private fun StatBox(label: String, value: String, color: Color, modifier: Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = EmeraldDeep.copy(alpha = 0.4f),
        border = BorderStroke(0.5.dp, Champagne.copy(alpha = 0.1f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(label, color = Ivory.copy(alpha = 0.5f), fontSize = 11.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, color = color, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
    }
}
