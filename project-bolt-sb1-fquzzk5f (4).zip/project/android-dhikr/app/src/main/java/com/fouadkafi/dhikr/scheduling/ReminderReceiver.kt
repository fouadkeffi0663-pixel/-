package com.fouadkafi.dhikr.scheduling

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.fouadkafi.dhikr.overlay.OverlayService

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Start the overlay service to show the floating reminder
        val serviceIntent = Intent(context, OverlayService::class.java).apply {
            action = OverlayService.ACTION_SHOW_REMINDER
        }
        context.startService(serviceIntent)
    }
}
