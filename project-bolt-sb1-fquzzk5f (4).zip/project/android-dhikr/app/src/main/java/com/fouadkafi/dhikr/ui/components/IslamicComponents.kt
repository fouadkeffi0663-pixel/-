package com.fouadkafi.dhikr.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

@Composable
fun IslamicPatternBackground(
    modifier: Modifier = Modifier,
    color: Color = Color(0xFFD4AF6E),
    alpha: Float = 0.04f
) {
    Canvas(
        modifier = modifier.fillMaxSize()
    ) {
        val w = size.width
        val h = size.height
        val tileSize = 80.dp.toPx()

        val rows = (h / tileSize).toInt() + 2
        val cols = (w / tileSize).toInt() + 2

        for (row in 0..rows) {
            for (col in 0..cols) {
                val cx = col * tileSize + tileSize / 2
                val cy = row * tileSize + tileSize / 2

                // Star pattern
                val path = Path()
                val r1 = tileSize * 0.3f
                val r2 = tileSize * 0.12f

                for (i in 0 until 8) {
                    val angle = (Math.PI * 2 * i / 8).toFloat()
                    val r = if (i % 2 == 0) r1 else r2
                    val x = cx + r * kotlin.math.cos(angle)
                    val y = cy + r * kotlin.math.sin(angle)
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()

                drawPath(
                    path = path,
                    color = color.copy(alpha = alpha),
                    style = Stroke(width = 1.dp.toPx())
                )
            }
        }
    }
}

@Composable
fun CrescentIcon(
    modifier: Modifier = Modifier,
    size: Int = 48,
    color: Color = Color(0xFFD4AF6E)
) {
    Canvas(modifier = modifier) {
        val radius = size.dp.toPx() / 2
        drawCircle(
            color = color,
            radius = radius,
            center = Offset(center.x, center.y)
        )
        drawCircle(
            color = Color.Transparent,
            radius = radius * 0.75f,
            center = Offset(center.x + radius * 0.25f, center.y),
            blendMode = androidx.compose.ui.graphics.BlendMode.Clear
        )
    }
}

@Composable
fun GeometricDivider(
    modifier: Modifier = Modifier,
    color: Color = Color(0xFFD4AF6E)
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cy = h / 2

        // Lines
        drawLine(
            color = color.copy(alpha = 0.4f),
            start = Offset(0f, cy),
            end = Offset(w * 0.35f, cy),
            strokeWidth = 1.dp.toPx()
        )
        drawLine(
            color = color.copy(alpha = 0.4f),
            start = Offset(w * 0.65f, cy),
            end = Offset(w, cy),
            strokeWidth = 1.dp.toPx()
        )

        // Center diamond
        val diamondSize = 8.dp.toPx()
        val path = Path().apply {
            moveTo(w / 2, cy - diamondSize)
            lineTo(w / 2 + diamondSize, cy)
            lineTo(w / 2, cy + diamondSize)
            lineTo(w / 2 - diamondSize, cy)
            close()
        }
        drawPath(
            path = path,
            color = color.copy(alpha = 0.6f),
            style = Stroke(width = 1.dp.toPx())
        )

        // Small circles
        drawCircle(
            color = color.copy(alpha = 0.3f),
            radius = 2.dp.toPx(),
            center = Offset(w * 0.35f, cy)
        )
        drawCircle(
            color = color.copy(alpha = 0.3f),
            radius = 2.dp.toPx(),
            center = Offset(w * 0.65f, cy)
        )
    }
}
