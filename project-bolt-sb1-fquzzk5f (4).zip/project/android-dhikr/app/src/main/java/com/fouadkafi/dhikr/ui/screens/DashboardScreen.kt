package com.fouadkafi.dhikr.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fouadkafi.dhikr.domain.*
import com.fouadkafi.dhikr.friday.FridayChecker
import com.fouadkafi.dhikr.ui.components.IslamicPatternBackground
import com.fouadkafi.dhikr.ui.components.CrescentIcon
import com.fouadkafi.dhikr.ui.theme.*
import java.time.ZonedDateTime

@Composable
fun DashboardScreen(
    settings: AppSettings?,
    onNavigate: (String) -> Unit,
    onToggleReminders: (Boolean) -> Unit
) {
    val lang = settings?.language ?: Language.ARABIC
    val isRtl = lang == Language.ARABIC
    val now = remember { ZonedDateTime.now() }

    val fridayActive = settings?.let { FridayChecker.isFridayPeriod(it, now) } ?: false
    val currentInterval = settings?.let { FridayChecker.getCurrentInterval(it, now) } ?: 10
    val reminderActive = settings?.remindersEnabled == true
    val goalProgress = if (settings != null && settings.dailyGoal > 0) {
        minOf(100f, 0f / settings.dailyGoal * 100f)
    } else 0f

    val bgColor = Brush.verticalGradient(
        listOf(Midnight, Color(0xFF031410))
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgColor)
    ) {
        IslamicPatternBackground(color = Champagne, alpha = 0.03f)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Spacer(modifier = Modifier.height(20.dp))

            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Brush.linearGradient(listOf(EmeraldMid, EmeraldDark))),
                        contentAlignment = Alignment.Center
                    ) { CrescentIcon(size = 24) }
                    Column {
                        Text(
                            text = if (lang == Language.ARABIC) "السلام عليكم" else "Peace be upon you",
                            color = Ivory.copy(alpha = 0.6f),
                            fontSize = 12.sp
                        )
                        Text("ذِكر ﷺ", color = Ivory, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                }
                IconButton(onClick = { onNavigate("settings") }) {
                    Text("⚙", color = Champagne, fontSize = 22.sp)
                }
            }

            // Reminder status card
            StatusCard(
                lang = lang,
                active = reminderActive,
                fridayActive = fridayActive,
                currentInterval = currentInterval,
                onToggle = { onToggleReminders(!reminderActive) }
            )

            // Stats grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(
                    modifier = Modifier.weight(1f),
                    label = if (lang == Language.ARABIC) "عدد اليوم" else "Today",
                    value = "0",
                    color = Champagne
                )
                StatCard(
                    modifier = Modifier.weight(1f),
                    label = if (lang == Language.ARABIC) "العدد الإجمالي" else "Lifetime",
                    value = "0",
                    color = EmeraldLight
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(
                    modifier = Modifier.weight(1f),
                    label = if (lang == Language.ARABIC) "السلسلة" else "Streak",
                    value = "0 ${if (lang == Language.ARABIC) "يوم" else "days"}",
                    color = EmeraldLight
                )
                StatCard(
                    modifier = Modifier.weight(1f),
                    label = if (lang == Language.ARABIC) "أفضل يوم" else "Best Day",
                    value = "0",
                    color = Champagne
                )
            }

            // Daily goal progress
            GoalCard(
                lang = lang,
                todayCount = 0,
                dailyGoal = settings?.dailyGoal ?: 100,
                progress = goalProgress
            )

            // Open counter button
            Button(
                onClick = { onNavigate("counter") },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = EmeraldMid,
                    contentColor = Ivory
                )
            ) {
                Text(
                    text = if (lang == Language.ARABIC) "افتح العداد" else "Open Counter",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Bottom nav
            BottomNav(
                lang = lang,
                currentRoute = "dashboard",
                onNavigate = onNavigate
            )
        }
    }
}

@Composable
private fun StatusCard(
    lang: Language,
    active: Boolean,
    fridayActive: Boolean,
    currentInterval: Int,
    onToggle: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = EmeraldDeep.copy(alpha = 0.5f),
        border = BorderStroke(0.5.dp, Champagne.copy(alpha = 0.1f))
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (lang == Language.ARABIC) "حالة التذكير" else "Reminder Status",
                        color = Ivory.copy(alpha = 0.6f),
                        fontSize = 12.sp
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(RoundedCornerShape(50))
                                .background(if (active) EmeraldLight else Color(0xFF884444).copy(alpha = 0.6f))
                        )
                        Text(
                            text = if (active) (if (lang == Language.ARABIC) "نشط" else "Active")
                                   else (if (lang == Language.ARABIC) "متوقف" else "Disabled"),
                            color = Ivory,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (fridayActive) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = Champagne.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = if (lang == Language.ARABIC) "وضع الجمعة" else "Friday",
                                    color = Champagne,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
                Text(
                    text = "$currentInterval ${if (lang == Language.ARABIC) "دقيقة" else "min"}",
                    color = Ivory.copy(alpha = 0.5f),
                    fontSize = 13.sp
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onToggle,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(14.dp),
                colors = if (active) ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF4D3318),
                    contentColor = Color(0xFFE8CD8A)
                ) else ButtonDefaults.buttonColors(
                    containerColor = EmeraldMid,
                    contentColor = Ivory
                )
            ) {
                Text(
                    text = if (active) (if (lang == Language.ARABIC) "إيقاف مؤقت" else "Pause")
                           else (if (lang == Language.ARABIC) "تفعيل" else "Enable"),
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun StatCard(modifier: Modifier, label: String, value: String, color: Color) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = EmeraldDeep.copy(alpha = 0.4f),
        border = BorderStroke(0.5.dp, Champagne.copy(alpha = 0.1f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(label, color = Ivory.copy(alpha = 0.5f), fontSize = 11.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, color = color, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun GoalCard(lang: Language, todayCount: Int, dailyGoal: Int, progress: Float) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = EmeraldDeep.copy(alpha = 0.4f),
        border = BorderStroke(0.5.dp, Champagne.copy(alpha = 0.1f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (lang == Language.ARABIC) "الهدف اليومي" else "Daily Goal",
                    color = Ivory.copy(alpha = 0.5f),
                    fontSize = 12.sp
                )
                Text("$todayCount / $dailyGoal", color = Ivory, fontSize = 12.sp)
            }
            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { progress / 100f },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)),
                color = Champagne,
                trackColor = EmeraldDark
            )
        }
    }
}

@Composable
fun BottomNav(lang: Language, currentRoute: String, onNavigate: (String) -> Unit) {
    val items = listOf(
        NavItem("dashboard", if (lang == Language.ARABIC) "الرئيسية" else "Home", "⌂"),
        NavItem("counter", if (lang == Language.ARABIC) "العداد" else "Counter", "○"),
        NavItem("statistics", if (lang == Language.ARABIC) "إحصائيات" else "Stats", "█"),
        NavItem("settings", if (lang == Language.ARABIC) "إعدادات" else "Settings", "⚙")
    )
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = EmeraldDeep.copy(alpha = 0.4f),
        border = BorderStroke(0.5.dp, Champagne.copy(alpha = 0.1f))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            items.forEach { item ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable { onNavigate(item.route) }
                ) {
                    Text(
                        text = item.icon,
                        color = if (item.route == currentRoute) Champagne else Ivory.copy(alpha = 0.4f),
                        fontSize = 18.sp
                    )
                    Text(
                        text = item.label,
                        color = if (item.route == currentRoute) Champagne else Ivory.copy(alpha = 0.4f),
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

private data class NavItem(val route: String, val label: String, val icon: String)
