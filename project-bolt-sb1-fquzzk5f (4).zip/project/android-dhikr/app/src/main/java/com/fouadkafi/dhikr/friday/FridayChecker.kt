package com.fouadkafi.dhikr.friday

import com.fouadkafi.dhikr.domain.AppSettings
import com.fouadkafi.dhikr.domain.FridayCalcMethod
import java.time.DayOfWeek
import java.time.LocalTime
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

object FridayChecker {

    fun isFridayPeriod(
        settings: AppSettings,
        now: ZonedDateTime = ZonedDateTime.now()
    ): Boolean {
        if (!settings.fridayModeEnabled) return false

        return when (settings.fridayCalcMethod) {
            FridayCalcMethod.MANUAL -> isManualFridayPeriod(
                settings.manualFridaySunset, now
            )
            FridayCalcMethod.ASTRONOMICAL -> isAstronomicalFridayPeriod(now)
        }
    }

    private fun parseTime(timeStr: String): LocalTime {
        return try {
            LocalTime.parse(timeStr, DateTimeFormatter.ofPattern("HH:mm"))
        } catch (e: Exception) {
            LocalTime.of(18, 30)
        }
    }

    private fun isManualFridayPeriod(sunsetStr: String, now: ZonedDateTime): Boolean {
        val sunset = parseTime(sunsetStr)
        val nowTime = now.toLocalTime()
        val day = now.dayOfWeek

        // Thursday after sunset -> Friday before sunset
        return when (day) {
            DayOfWeek.THURSDAY -> nowTime >= sunset
            DayOfWeek.FRIDAY -> nowTime < sunset
            else -> false
        }
    }

    /**
     * Astronomical approximation. In production, use a prayer-time library
     * like Adhan for precise sunset based on lat/lng.
     * This fallback uses ~18:30 local as approximate sunset.
     */
    private fun isAstronomicalFridayPeriod(now: ZonedDateTime): Boolean {
        // Approximate sunset: 18:30 local
        val sunset = LocalTime.of(18, 30)
        val nowTime = now.toLocalTime()
        val day = now.dayOfWeek

        return when (day) {
            DayOfWeek.THURSDAY -> nowTime >= sunset
            DayOfWeek.FRIDAY -> nowTime < sunset
            else -> false
        }
    }

    fun getCurrentInterval(settings: AppSettings, now: ZonedDateTime = ZonedDateTime.now()): Int {
        return if (isFridayPeriod(settings, now)) {
            settings.fridayIntervalMinutes
        } else {
            settings.reminderIntervalMinutes
        }
    }
}
