package com.fouadkafi.dhikr.overlay

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.findViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class OverlayService : Service() {

    companion object {
        const val ACTION_SHOW_REMINDER = "com.fouadkafi.dhikr.SHOW_REMINDER"
        private const val CAPSULE_WIDTH_EXPANDED = 280
        private const val CAPSULE_HEIGHT_EXPANDED = 64
        private const val CAPSULE_WIDTH_COLLAPSED = 90
        private const val CAPSULE_HEIGHT_COLLAPSED = 28
    }

    private var windowManager: WindowManager? = null
    private var overlayView: ComposeView? = null
    private var isShowing = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_SHOW_REMINDER) {
            if (!isShowing && hasOverlayPermission()) {
                showReminder()
            }
        }
        return START_NOT_STICKY
    }

    private fun hasOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else true
    }

    private fun getLayoutParams(): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dpToPx(40)
        }
    }

    private fun dpToPx(dp: Int): Int {
        val density = resources.displayMetrics.density
        return (dp * density).toInt()
    }

    private fun showReminder() {
        if (overlayView != null) return

        val lifecycleOwner = OverlayLifecycleOwner()
        lifecycleOwner.performCreate()

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(lifecycleOwner)
            val savedStateRegistryOwner = OverlaySavedStateRegistryOwner()
            savedStateRegistryOwner.performRestore(null)
            setViewTreeSavedStateRegistryOwner(savedStateRegistryOwner)

            setContent {
                OverlayCapsule(
                    onDismiss = { removeOverlay() }
                )
            }
        }

        overlayView = composeView

        try {
            windowManager?.addView(composeView, getLayoutParams())
            isShowing = true

            lifecycleOwner.performStart()

            // Auto-remove after animation completes
            kotlinx.coroutines.MainScope().launch {
                delay(4000)
                removeOverlay()
            }
        } catch (e: Exception) {
            // Permission might have been revoked
            overlayView = null
            isShowing = false
        }
    }

    private fun removeOverlay() {
        overlayView?.let { view ->
            try {
                windowManager?.removeView(view)
            } catch (e: Exception) {
                // already removed
            }
        }
        overlayView = null
        isShowing = false
    }

    override fun onDestroy() {
        removeOverlay()
        super.onDestroy()
    }
}

@Composable
private fun OverlayCapsule(
    onDismiss: () -> Unit
) {
    // Animation phases
    var phase by remember { mutableStateOf(0) }

    // Phase: 0=entering, 1=expanding, 2=displaying, 3=contracting, 4=exiting
    LaunchedEffect(Unit) {
        delay(300)   // enter
        phase = 1    // expand
        delay(450)   // expansion duration
        phase = 2    // display
        delay(2000)  // display duration
        phase = 3    // contract
        delay(400)   // contraction
        phase = 4    // exit
        delay(300)   // exit
    }

    val targetWidth = when (phase) {
        0 -> 90f
        1 -> 280f
        2 -> 280f
        3 -> 90f
        else -> 90f
    }
    val targetHeight = when (phase) {
        0 -> 28f
        1 -> 64f
        2 -> 64f
        3 -> 28f
        else -> 28f
    }

    val width by animateFloatAsState(
        targetValue = targetWidth,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "width"
    )
    val height by animateFloatAsState(
        targetValue = targetHeight,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "height"
    )
    val alpha by animateFloatAsState(
        targetValue = if (phase == 0) 1f else if (phase == 4) 0f else 1f,
        animationSpec = tween(300),
        label = "alpha"
    )
    val offsetY by animateFloatAsState(
        targetValue = if (phase == 0) -30f else if (phase == 4) -30f else 0f,
        animationSpec = tween(300),
        label = "offsetY"
    )
    val textAlpha by animateFloatAsState(
        targetValue = if (phase >= 2 && phase <= 3) 1f else 0f,
        animationSpec = tween(300),
        label = "textAlpha"
    )

    Box(
        modifier = Modifier
            .padding(16.dp)
            .offset(y = offsetY.dp)
            .width(width.dp)
            .height(height.dp)
            .clip(RoundedCornerShape(height.dp / 2))
            .background(Color(0xFF0A0A0A))
            .border(0.5.dp, Color(0x20D4AF6E), RoundedCornerShape(height.dp / 2)),
        contentAlignment = Alignment.Center
    ) {
        // Crescent icon (always visible)
        Box(
            modifier = Modifier
                .size(14.dp)
                .background(Color(0xFFD4AF6E), androidx.compose.foundation.shape.CircleShape),
            contentAlignment = Alignment.Center
        ) {}

        // Text (visible when expanded)
        if (textAlpha > 0.01f) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "صلِّ على النبي ﷺ",
                    color = Color.White.copy(alpha = textAlpha),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

// --- Lifecycle management for ComposeView in overlay ---

private class OverlayLifecycleOwner : LifecycleOwner {
    private val lifecycleRegistry = LifecycleRegistry(this)

    override val lifecycle: Lifecycle = lifecycleRegistry

    fun performCreate() {
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
    }

    fun performStart() {
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
    }

    fun performStop() {
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
    }

    fun performDestroy() {
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    }
}

private class OverlaySavedStateRegistryOwner : SavedStateRegistryOwner {
    private val controller = SavedStateRegistryController.create(this)
    override val savedStateRegistry: SavedStateRegistry = controller.savedStateRegistry

    private val lifecycleRegistry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle = lifecycleRegistry

    fun performRestore(savedState: SavedStateRegistry.SavedState?) {
        controller.performRestore(savedState)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
    }
}
