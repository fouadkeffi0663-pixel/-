package com.fouadkafi.dhikr

import android.app.Application

class DhikrApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
