package com.fouadkafi.dhikr.domain

enum class Language(val code: String, val displayName: String) {
    ARABIC("ar", "العربية"),
    ENGLISH("en", "English");

    companion object {
        fun fromCode(code: String): Language = entries.find { it.code == code } ?: ARABIC
    }
}

enum class ThemeMode { LIGHT, DARK, SYSTEM }

enum class OverlayStyle { DYNAMIC_ISLAND, FROSTED_GLASS }

enum class ReminderStatus { ACTIVE, PAUSED, DISABLED }

enum class FridayCalcMethod { MANUAL, ASTRONOMICAL }

data class AppSettings(
    val language: Language = Language.ARABIC,
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val overlayStyle: OverlayStyle = OverlayStyle.DYNAMIC_ISLAND,
    val animationsEnabled: Boolean = true,
    val vibrationEnabled: Boolean = false,
    val soundEnabled: Boolean = false,
    val remindersEnabled: Boolean = false,
    val reminderIntervalMinutes: Int = 10,
    val fridayModeEnabled: Boolean = true,
    val fridayIntervalMinutes: Int = 2,
    val quietHoursStart: String = "22:00",
    val quietHoursEnd: String = "06:00",
    val activeHoursStart: String = "06:00",
    val activeHoursEnd: String = "23:00",
    val screenOnOnly: Boolean = true,
    val dailyGoal: Int = 100,
    val overlayTapCounts: Boolean = false,
    val tempPauseUntil: Long? = null,
    val fridayCalcMethod: FridayCalcMethod = FridayCalcMethod.MANUAL,
    val manualFridaySunset: String = "18:30",
    val achievementsEnabled: Boolean = true,
    val onboarded: Boolean = false
)

data class DayRecord(
    val date: String,
    val count: Int
)

data class Stats(
    val lifetimeCount: Int = 0,
    val todayCount: Int = 0,
    val dailyHistory: List<DayRecord> = emptyList(),
    val milestonesShown: List<Int> = emptyList(),
    val personalBestDay: Int = 0,
    val currentStreak: Int = 0,
    val lastActiveDate: String? = null
)

data class Milestone(
    val count: Int,
    val messageAr: String,
    val messageEn: String
)

object Milestones {
    val ALL = listOf(
        Milestone(100, "أحسنت، واصل الذكر.", "Well done, keep up the dhikr."),
        Milestone(500, "بارك الله في وقتك، استمر على الخير.", "May Allah bless your time, continue doing good."),
        Milestone(1000, "لقد حققت هدفًا جديدًا، جعل الله ذكرك مباركًا.", "You reached a new milestone, may Allah make your dhikr blessed."),
        Milestone(2500, "نِعْمَ القلب الذي لا ينسى الصلاة على النبي ﷺ.", "Blessed is the heart that remembers the Prophet ﷺ."),
        Milestone(5000, "نسأل الله أن يجعلك من الذاكرين الله كثيرًا.", "We ask Allah to make you among those who remember Him often."),
        Milestone(10000, "ثبتك الله على ذكره، وجعلها نورًا لك.", "May Allah keep you steadfast in His remembrance.")
    )

    val INTERVAL_PRESETS = listOf(1, 2, 5, 10, 15, 20, 30, 45, 60)
    val FRIDAY_PRESETS = listOf(1, 2, 5, 10, 15, 30)
}
