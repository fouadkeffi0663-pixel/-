package com.fouadkafi.dhikr

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.runtime.*
import androidx.navigation.compose.*
import com.fouadkafi.dhikr.ui.theme.DhikrTheme
import com.fouadkafi.dhikr.ui.screens.*
import com.fouadkafi.dhikr.data.SettingsManager

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            DhikrTheme {
                val navController = rememberNavController()
                val settingsManager = remember { SettingsManager(this) }
                val settings by settingsManager.settingsFlow.collectAsState(initial = null)

                val startRoute = if (settings?.onboarded == true) "dashboard" else "welcome"

                NavHost(
                    navController = navController,
                    startDestination = startRoute
                ) {
                    composable("welcome") {
                        WelcomeScreen(
                            settings = settings,
                            onLanguageChange = { lang ->
                                settingsManager.updateLanguage(lang)
                            },
                            onStart = {
                                settingsManager.setOnboarded(true)
                                navController.navigate("dashboard") {
                                    popUpTo("welcome") { inclusive = true }
                                }
                            }
                        )
                    }
                    composable("dashboard") {
                        DashboardScreen(
                            settings = settings,
                            onNavigate = { route -> navController.navigate(route) },
                            onToggleReminders = { enabled ->
                                settingsManager.updateRemindersEnabled(enabled)
                            }
                        )
                    }
                    composable("counter") {
                        CounterScreen(
                            settings = settings,
                            onNavigate = { route -> navController.navigate(route) }
                        )
                    }
                    composable("statistics") {
                        StatisticsScreen(
                            settings = settings,
                            onNavigate = { route -> navController.navigate(route) }
                        )
                    }
                    composable("settings") {
                        SettingsScreen(
                            settings = settings,
                            onNavigate = { route -> navController.navigate(route) },
                            onUpdateSettings = { partial ->
                                settingsManager.updateSettings(partial)
                            }
                        )
                    }
                }
            }
        }
    }
}
