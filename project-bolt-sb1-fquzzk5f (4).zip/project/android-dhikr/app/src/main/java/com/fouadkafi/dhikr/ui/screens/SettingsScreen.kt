package com.fouadkafi.dhikr.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fouadkafi.dhikr.domain.*
import com.fouadkafi.dhikr.ui.components.CrescentIcon
import com.fouadkafi.dhikr.ui.components.GeometricDivider
import com.fouadkafi.dhikr.ui.components.IslamicPatternBackground
import com.fouadkafi.dhikr.ui.theme.*

@Composable
fun SettingsScreen(
    settings: AppSettings?,
    onNavigate: (String) -> Unit,
    onUpdateSettings: (PartialSettings) -> Unit
) {
    val lang = settings?.language ?: Language.ARABIC
    var expandedSection by remember { mutableStateOf<String?>("reminders") }
    var showEraseDialog by remember { mutableStateOf(false) }

    val sections = listOf(
        "reminders" to (if (lang == Language.ARABIC) "التذكيرات" else "Reminders"),
        "appearance" to (if (lang == Language.ARABIC) "المظهر" else "Appearance"),
        "counting" to (if (lang == Language.ARABIC) "العد والأهداف" else "Counting & Goals"),
        "permissions" to (if (lang == Language.ARABIC) "الأذونات" else "Permissions"),
        "privacy" to (if (lang == Language.ARABIC) "الخصوصية" else "Privacy"),
        "about" to (if (lang == Language.ARABIC) "حول التطبيق" else "About")
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Midnight, Color(0xFF031410))))
    ) {
        IslamicPatternBackground(color = Champagne, alpha = 0.03f)

        Column(
            modifier = Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Spacer(modifier = Modifier.height(20.dp))

            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = { onNavigate("dashboard") }) {
                    Text("←", color = Ivory, fontSize = 22.sp)
                }
                Text(
                    text = if (lang == Language.ARABIC) "الإعدادات" else "Settings",
                    color = Ivory, fontSize = 18.sp, fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(40.dp))
            }

            // Sections
            sections.forEach { (key, title) ->
                SettingsSection(
                    title = title,
                    expanded = expandedSection == key,
                    onToggle = { expandedSection = if (expandedSection == key) null else key }
                ) {
                    when (key) {
                        "reminders" -> RemindersContent(settings, onUpdateSettings, lang)
                        "appearance" -> AppearanceContent(settings, onUpdateSettings, lang)
                        "counting" -> CountingContent(settings, onNavigate, lang)
                        "permissions" -> PermissionsContent(lang)
                        "privacy" -> PrivacyContent(lang) { showEraseDialog = true }
                        "about" -> AboutContent(lang)
                    }
                }
            }

            BottomNav(lang, "settings", onNavigate)
        }
    }

    if (showEraseDialog) {
        AlertDialog(
            onDismissRequest = { showEraseDialog = false },
            title = { Text(if (lang == Language.ARABIC) "مسح جميع البيانات؟" else "Erase all data?") },
            text = { Text(if (lang == Language.ARABIC) "لا يمكن التراجع عن هذا الإجراء." else "This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = { showEraseDialog = false }) {
                    Text(if (lang == Language.ARABIC) "تأكيد" else "Confirm", color = Color(0xFF884444))
                }
            },
            dismissButton = {
                TextButton(onClick = { showEraseDialog = false }) {
                    Text(if (lang == Language.ARABIC) "إلغاء" else "Cancel")
                }
            },
            containerColor = EmeraldDeep
        )
    }
}

@Composable
private fun SettingsSection(
    title: String,
    expanded: Boolean,
    onToggle: () -> Unit,
    content: @Composable () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = EmeraldDeep.copy(alpha = 0.4f),
        border = BorderStroke(0.5.dp, Champagne.copy(alpha = 0.1f))
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggle() }
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, color = Ivory, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(
                    text = if (expanded) "▲" else "▼",
                    color = Ivory.copy(alpha = 0.4f),
                    fontSize = 12.sp
                )
            }
            if (expanded) {
                HorizontalDivider(color = Champagne.copy(alpha = 0.1f), thickness = 0.5.dp)
                Box(modifier = Modifier.padding(16.dp)) {
                    content()
                }
            }
        }
    }
}

@Composable
private fun RemindersContent(settings: AppSettings?, onUpdate: (PartialSettings) -> Unit, lang: Language) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ToggleRow(
            label = if (lang == Language.ARABIC) "تفعيل التذكيرات" else "Enable Reminders",
            checked = settings?.remindersEnabled ?: false,
            onCheckedChange = { onUpdate(PartialSettings(remindersEnabled = it)) }
        )
        ToggleRow(
            label = if (lang == Language.ARABIC) "وضع الجمعة" else "Friday Mode",
            checked = settings?.fridayModeEnabled ?: true,
            onCheckedChange = { onUpdate(PartialSettings(fridayModeEnabled = it)) }
        )
        Text(
            text = if (lang == Language.ARABIC)
                "يبدأ وضع الجمعة من غروب شمس الخميس إلى غروب شمس الجمعة حسب توقيتك المحلي."
            else
                "Friday mode begins from Thursday sunset to Friday sunset according to your local time.",
            color = Ivory.copy(alpha = 0.4f),
            fontSize = 11.sp
        )
        ToggleRow(
            label = if (lang == Language.ARABIC) "الرسوم المتحركة" else "Animations",
            checked = settings?.animationsEnabled ?: true,
            onCheckedChange = { onUpdate(PartialSettings(animationsEnabled = it)) }
        )
        ToggleRow(
            label = if (lang == Language.ARABIC) "الاهتزاز" else "Vibration",
            checked = settings?.vibrationEnabled ?: false,
            onCheckedChange = { onUpdate(PartialSettings(vibrationEnabled = it)) }
        )
        ToggleRow(
            label = if (lang == Language.ARABIC) "الصوت" else "Sound",
            checked = settings?.soundEnabled ?: false,
            onCheckedChange = { onUpdate(PartialSettings(soundEnabled = it)) }
        )
    }
}

@Composable
private fun AppearanceContent(settings: AppSettings?, onUpdate: (PartialSettings) -> Unit, lang: Language) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (lang == Language.ARABIC) "السمة" else "Theme", color = Ivory.copy(alpha = 0.5f), fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(ThemeMode.LIGHT to (if (lang == Language.ARABIC) "فاتح" else "Light"),
                   ThemeMode.DARK to (if (lang == Language.ARABIC) "داكن" else "Dark"),
                   ThemeMode.SYSTEM to (if (lang == Language.ARABIC) "تلقائي" else "System")).forEach { (mode, label) ->
                FilterChip(
                    selected = settings?.theme == mode,
                    onClick = { onUpdate(PartialSettings(theme = mode)) },
                    label = { Text(label, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EmeraldMid,
                        selectedLabelColor = Ivory
                    )
                )
            }
        }
        Text(if (lang == Language.ARABIC) "اللغة" else "Language", color = Ivory.copy(alpha = 0.5f), fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = settings?.language == Language.ARABIC,
                onClick = { onUpdate(PartialSettings(language = Language.ARABIC)) },
                label = { Text("العربية", fontSize = 12.sp) },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = EmeraldMid, selectedLabelColor = Ivory)
            )
            FilterChip(
                selected = settings?.language == Language.ENGLISH,
                onClick = { onUpdate(PartialSettings(language = Language.ENGLISH)) },
                label = { Text("English", fontSize = 12.sp) },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = EmeraldMid, selectedLabelColor = Ivory)
            )
        }
    }
}

@Composable
private fun CountingContent(settings: AppSettings?, onNavigate: (String) -> Unit, lang: Language) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = if (lang == Language.ARABIC) "الهدف اليومي" else "Daily Goal",
            color = Ivory.copy(alpha = 0.5f), fontSize = 12.sp
        )
        Text(
            text = "${settings?.dailyGoal ?: 100}",
            color = Champagne, fontSize = 20.sp, fontWeight = FontWeight.Bold
        )
        Slider(
            value = (settings?.dailyGoal ?: 100).toFloat(),
            onValueChange = { onUpdate(PartialSettings(dailyGoal = it.toInt())) },
            valueRange = 10f..1000f,
            steps = 98,
            colors = SliderDefaults.colors(
                thumbColor = Champagne,
                activeTrackColor = Champagne
            )
        )
        TextButton(onClick = { onNavigate("statistics") }) {
            Text(if (lang == Language.ARABIC) "سجل الإنجازات" else "Achievement History", color = Champagne, fontSize = 12.sp)
        }
    }
}

@Composable
private fun PermissionsContent(lang: Language) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        InfoBox(
            if (lang == Language.ARABIC) "إذن العرض فوق التطبيقات" else "Overlay Permission",
            if (lang == Language.ARABIC) "مطلوب لعرض التذكير العائم فوق التطبيقات الأخرى. يُمنح من إعدادات النظام." else "Required to show the floating reminder over other apps. Granted from system settings."
        )
        InfoBox(
            if (lang == Language.ARABIC) "إذن الإشعارات" else "Notification Permission",
            if (lang == Language.ARABIC) "مطلوب على أندرويد 13 وما فوق." else "Required on Android 13 and above."
        )
        InfoBox(
            if (lang == Language.ARABIC) "موثوقية الخلفية" else "Background Reliability",
            if (lang == Language.ARABIC)
                "بعض الشركات المصنعة قد تؤخر أو تقيّد النشاط في الخلفية. لا يمكن ضمان العمل المتواصل على جميع الأجهزة."
            else
                "Some manufacturers may delay or restrict background activity. Continuous operation cannot be guaranteed on all devices."
        )
    }
}

@Composable
private fun PrivacyContent(lang: Language, onErase: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = if (lang == Language.ARABIC)
                "تُحفظ الإحصائيات محليًا على جهازك. لا يلزم إنشاء حساب. لا يتم تضمين أي حزم تحليلات أو إعلانات. لا يتم تتبع نشاطك عبر التطبيقات."
            else
                "Statistics are stored locally on your device. No account required. No analytics or advertising SDKs included. No cross-app tracking.",
            color = Ivory.copy(alpha = 0.5f),
            fontSize = 12.sp,
            lineHeight = 20.sp
        )
        TextButton(onClick = onErase) {
            Text(
                if (lang == Language.ARABIC) "مسح جميع البيانات" else "Erase All Data",
                color = Color(0xFF884444), fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun AboutContent(lang: Language) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier.size(48.dp).clip(RoundedCornerShape(12.dp))
                .background(Brush.linearGradient(listOf(EmeraldMid, EmeraldDark))),
            contentAlignment = Alignment.Center
        ) { CrescentIcon(size = 26) }
        Text("ذِكر ﷺ", color = Ivory, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        GeometricDivider(modifier = Modifier.width(160.dp).height(16.dp), color = Champagne.copy(alpha = 0.4f))
        Text(
            text = if (lang == Language.ARABIC)
                "تطبيق ذِكر ﷺ هو رفيقك اليومي للإكثار من الصلاة على النبي ﷺ. مصمم ليكون هادئًا وأنيقًا ومحترمًا لخصوصيتك."
            else
                "Dhikr ﷺ is your daily companion for sending abundant blessings upon the Prophet ﷺ. Designed to be peaceful, elegant, and respectful of your privacy.",
            color = Ivory.copy(alpha = 0.5f),
            fontSize = 12.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            lineHeight = 20.sp
        )
        Text(
            text = if (lang == Language.ARABIC) "الإصدار" else "Version",
            color = Ivory.copy(alpha = 0.4f), fontSize = 11.sp
        )
        Text("1.0.0", color = Ivory, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Text("صنع من طرف فؤاد كفي", color = Champagne.copy(alpha = 0.4f), fontSize = 11.sp)
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Ivory, fontSize = 13.sp)
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = EmeraldMid,
                uncheckedTrackColor = EmeraldDark
            )
        )
    }
}

@Composable
private fun InfoBox(title: String, desc: String) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF052016).copy(alpha = 0.5f),
        border = BorderStroke(0.5.dp, Champagne.copy(alpha = 0.08f))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, color = Ivory.copy(alpha = 0.7f), fontSize = 13.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(desc, color = Ivory.copy(alpha = 0.4f), fontSize = 11.sp, lineHeight = 18.sp)
        }
    }
}
