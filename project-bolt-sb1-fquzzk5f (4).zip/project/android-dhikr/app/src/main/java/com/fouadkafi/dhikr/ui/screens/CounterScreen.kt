package com.fouadkafi.dhikr.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fouadkafi.dhikr.domain.*
import com.fouadkafi.dhikr.ui.components.CrescentIcon
import com.fouadkafi.dhikr.ui.components.GeometricDivider
import com.fouadkafi.dhikr.ui.components.IslamicPatternBackground
import com.fouadkafi.dhikr.ui.theme.*

@Composable
fun CounterScreen(
    settings: AppSettings?,
    onNavigate: (String) -> Unit
) {
    val lang = settings?.language ?: Language.ARABIC
    var showResetDialog by remember { mutableStateOf(false) }
    var showMilestone by remember { mutableStateOf<Milestone?>(null) }
    var ripple by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Midnight, Color(0xFF031410))))
    ) {
        IslamicPatternBackground(color = Champagne, alpha = 0.03f)

        Column(
            modifier = Modifier.fillMaxSize().padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(20.dp))

            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = { onNavigate("dashboard") }) {
                    Text("←", color = Ivory, fontSize = 22.sp)
                }
                Text(
                    text = if (lang == Language.ARABIC) "العداد" else "Counter",
                    color = Ivory,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(40.dp))
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Today count
            Text(
                text = if (lang == Language.ARABIC) "عدد اليوم" else "Today's Count",
                color = Ivory.copy(alpha = 0.5f),
                fontSize = 13.sp
            )
            Text(
                text = "0",
                color = Champagne,
                fontSize = 56.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(40.dp))

            // Big tap button
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Brush.radialGradient(listOf(EmeraldMid, EmeraldDark, Midnight)))
                    .border(2.dp, Champagne.copy(alpha = 0.2f), RoundedCornerShape(50))
                    .clickable {
                        ripple = true
                    },
                contentAlignment = Alignment.Center
            ) {
                if (ripple) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(50))
                            .background(Champagne.copy(alpha = 0.1f))
                    )
                    LaunchedEffect(ripple) {
                        kotlinx.coroutines.delay(600)
                        ripple = false
                    }
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CrescentIcon(size = 48)
                    Spacer(modifier = Modifier.height(12.dp))
                    GeometricDivider(
                        modifier = Modifier.width(120.dp).height(16.dp),
                        color = Champagne.copy(alpha = 0.3f)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (lang == Language.ARABIC) "صلّيت على النبي ﷺ"
                               else "I sent blessings upon the Prophet ﷺ",
                        color = Ivory,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 24.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (lang == Language.ARABIC) "اضغط لزيادة العد" else "Tap to increase count",
                        color = Ivory.copy(alpha = 0.4f),
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Quick stats
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MiniStat(if (lang == Language.ARABIC) "الإجمالي" else "Lifetime", "0", Modifier.weight(1f))
                MiniStat(if (lang == Language.ARABIC) "السلسلة" else "Streak", "0", Modifier.weight(1f))
                MiniStat(if (lang == Language.ARABIC) "أفضل يوم" else "Best", "0", Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = {},
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(if (lang == Language.ARABIC) "تصحيح العد" else "Correct")
                }
                OutlinedButton(
                    onClick = { showResetDialog = true },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF884444))
                ) {
                    Text(if (lang == Language.ARABIC) "إعادة تعيين" else "Reset")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            BottomNav(lang, "counter", onNavigate)
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text(if (lang == Language.ARABIC) "إعادة تعيين عداد اليوم؟" else "Reset today's count?") },
            confirmButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text(if (lang == Language.ARABIC) "تأكيد" else "Confirm", color = Color(0xFF884444))
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text(if (lang == Language.ARABIC) "إلغاء" else "Cancel")
                }
            },
            containerColor = EmeraldDeep
        )
    }
}

@Composable
private fun MiniStat(label: String, value: String, modifier: Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = EmeraldDeep.copy(alpha = 0.4f),
        border = BorderStroke(0.5.dp, Champagne.copy(alpha = 0.1f))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, color = Ivory.copy(alpha = 0.5f), fontSize = 10.sp)
            Text(value, color = Champagne, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}
