package com.fouadkafi.dhikr.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import com.fouadkafi.dhikr.domain.DayRecord
import com.fouadkafi.dhikr.domain.Milestone
import com.fouadkafi.dhikr.domain.Milestones
import com.fouadkafi.dhikr.domain.Stats
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class StatsManager(private val context: Context) {

    private object Keys {
        val LIFETIME = intPreferencesKey("lifetime_count")
        val TODAY = intPreferencesKey("today_count")
        val PERSONAL_BEST = intPreferencesKey("personal_best")
        val CURRENT_STREAK = intPreferencesKey("current_streak")
        val LAST_ACTIVE = stringPreferencesKey("last_active_date")
        val MILESTONES_SHOWN = stringPreferencesKey("milestones_shown")
        val DAILY_HISTORY = stringPreferencesKey("daily_history")
    }

    private val dateFmt = DateTimeFormatter.ISO_LOCAL_DATE

    private fun today(): String = LocalDate.now().format(dateFmt)

    val statsFlow: Flow<Stats> = context.dataStore.data.map { prefs ->
        val milestonesStr = prefs[Keys.MILESTONES_SHOWN] ?: ""
        val milestonesShown = if (milestonesStr.isBlank()) emptyList()
            else milestonesStr.split(",").mapNotNull { it.trim().toIntOrNull() }

        val historyStr = prefs[Keys.DAILY_HISTORY] ?: ""
        val history = if (historyStr.isBlank()) emptyList()
            else historyStr.split(";").mapNotNull { entry ->
                val parts = entry.split("|")
                if (parts.size == 2) DayRecord(parts[0], parts[1].toIntOrNull() ?: 0) else null
            }

        Stats(
            lifetimeCount = prefs[Keys.LIFETIME] ?: 0,
            todayCount = prefs[Keys.TODAY] ?: 0,
            dailyHistory = history,
            milestonesShown = milestonesShown,
            personalBestDay = prefs[Keys.PERSONAL_BEST] ?: 0,
            currentStreak = prefs[Keys.CURRENT_STREAK] ?: 0,
            lastActiveDate = prefs[Keys.LAST_ACTIVE]
        )
    }

    suspend fun increment(context2: Context, onMilestone: (Milestone) -> Unit = {}) {
        val today = today()
        context.dataStore.edit { prefs ->
            val prevLifetime = prefs[Keys.LIFETIME] ?: 0
            val prevToday = prefs[Keys.TODAY] ?: 0
            val prevBest = prefs[Keys.PERSONAL_BEST] ?: 0
            val prevStreak = prefs[Keys.CURRENT_STREAK] ?: 0
            val prevLastActive = prefs[Keys.LAST_ACTIVE]
            val prevMilestonesStr = prefs[Keys.MILESTONES_SHOWN] ?: ""
            val prevMilestones = if (prevMilestonesStr.isBlank()) emptyList()
                else prevMilestonesStr.split(",").mapNotNull { it.trim().toIntOrNull() }

            val newLifetime = prevLifetime + 1
            val newToday = prevToday + 1

            prefs[Keys.LIFETIME] = newLifetime
            prefs[Keys.TODAY] = newToday
            prefs[Keys.PERSONAL_BEST] = maxOf(prevBest, newToday)

            // Streak calculation
            val yesterday = LocalDate.now().minusDays(1).format(dateFmt)
            val newStreak = when {
                prevLastActive == today -> prevStreak
                prevLastActive == yesterday -> prevStreak + 1
                else -> 1
            }
            prefs[Keys.CURRENT_STREAK] = newStreak
            prefs[Keys.LAST_ACTIVE] = today

            // Update daily history
            val historyStr = prefs[Keys.DAILY_HISTORY] ?: ""
            val history = if (historyStr.isBlank()) mutableListOf<DayRecord>()
                else historyStr.split(";").mapNotNull { entry ->
                    val parts = entry.split("|")
                    if (parts.size == 2) DayRecord(parts[0], parts[1].toIntOrNull() ?: 0) else null
                }.toMutableList()

            val existingIdx = history.indexOfFirst { it.date == today }
            if (existingIdx >= 0) {
                history[existingIdx] = DayRecord(today, history[existingIdx].count + 1)
            } else {
                history.add(DayRecord(today, 1))
            }
            // Keep last 365 days
            val sortedHistory = history.sortedByDescending { it.date }.take(365)
            prefs[Keys.DAILY_HISTORY] = sortedHistory.joinToString(";") { "${it.date}|${it.count}" }

            // Check milestones
            val newMilestone = Milestones.ALL.find { m ->
                newLifetime >= m.count && m.count !in prevMilestones
            }
            if (newMilestone != null) {
                val updatedMilestones = prevMilestones + newMilestone.count
                prefs[Keys.MILESTONES_SHOWN] = updatedMilestones.joinToString(",")
                onMilestone(newMilestone)
            }
        }
    }

    suspend fun resetToday() {
        context.dataStore.edit { prefs ->
            prefs[Keys.TODAY] = 0
            val today = today()
            val historyStr = prefs[Keys.DAILY_HISTORY] ?: ""
            val history = if (historyStr.isBlank()) mutableListOf()
                else historyStr.split(";").mapNotNull { entry ->
                    val parts = entry.split("|")
                    if (parts.size == 2) DayRecord(parts[0], parts[1].toIntOrNull() ?: 0) else null
                }.toMutableList()
            val idx = history.indexOfFirst { it.date == today }
            if (idx >= 0) history[idx] = DayRecord(today, 0)
            prefs[Keys.DAILY_HISTORY] = history.joinToString(";") { "${it.date}|${it.count}" }
        }
    }

    suspend fun resetAll() {
        context.dataStore.edit { prefs ->
            prefs.remove(Keys.LIFETIME)
            prefs.remove(Keys.TODAY)
            prefs.remove(Keys.PERSONAL_BEST)
            prefs.remove(Keys.CURRENT_STREAK)
            prefs.remove(Keys.LAST_ACTIVE)
            prefs.remove(Keys.MILESTONES_SHOWN)
            prefs.remove(Keys.DAILY_HISTORY)
        }
    }
}
