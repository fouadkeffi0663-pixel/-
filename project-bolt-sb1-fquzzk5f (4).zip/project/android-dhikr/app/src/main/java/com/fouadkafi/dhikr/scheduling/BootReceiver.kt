package com.fouadkafi.dhikr.scheduling

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // Restore reminder schedule after device reboot
            // The app will re-schedule on next launch as well
            // Full restoration requires reading DataStore which needs a coroutine scope
        }
    }
}
