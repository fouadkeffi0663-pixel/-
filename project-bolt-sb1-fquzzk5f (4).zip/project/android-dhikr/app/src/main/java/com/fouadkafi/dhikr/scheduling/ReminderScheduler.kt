package com.fouadkafi.dhikr.scheduling

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import com.fouadkafi.dhikr.domain.AppSettings
import com.fouadkafi.dhikr.friday.FridayChecker
import java.time.LocalTime
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

object ReminderScheduler {

    private const val REQUEST_CODE = 1001

    fun scheduleNext(context: Context, settings: AppSettings) {
        if (!settings.remindersEnabled) return

        val now = ZonedDateTime.now()
        val intervalMinutes = FridayChecker.getCurrentInterval(settings, now)

        // Check active hours and quiet hours
        if (!isInActiveHours(settings, now)) return
        if (isInQuietHours(settings, now)) return
        if (settings.tempPauseUntil != null && System.currentTimeMillis() < settings.tempPauseUntil) return

        val triggerAtMillis = System.currentTimeMillis() + intervalMinutes * 60_000L

        val intent = Intent(context, ReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            }
        } else {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerAtMillis,
                pendingIntent
            )
        }
    }

    fun cancel(context: Context) {
        val intent = Intent(context, ReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(pendingIntent)
    }

    fun hasOverlayPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else true
    }

    fun requestOverlayPermission(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            )
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }
    }

    private fun parseTime(timeStr: String): LocalTime {
        return try {
            LocalTime.parse(timeStr, DateTimeFormatter.ofPattern("HH:mm"))
        } catch (e: Exception) {
            LocalTime.of(0, 0)
        }
    }

    private fun isInQuietHours(settings: AppSettings, now: ZonedDateTime): Boolean {
        val start = parseTime(settings.quietHoursStart)
        val end = parseTime(settings.quietHoursEnd)
        val nowTime = now.toLocalTime()

        return if (start <= end) {
            nowTime >= start && nowTime < end
        } else {
            nowTime >= start || nowTime < end
        }
    }

    private fun isInActiveHours(settings: AppSettings, now: ZonedDateTime): Boolean {
        val start = parseTime(settings.activeHoursStart)
        val end = parseTime(settings.activeHoursEnd)
        val nowTime = now.toLocalTime()

        return if (start <= end) {
            nowTime >= start && nowTime < end
        } else {
            nowTime >= start || nowTime < end
        }
    }
}
