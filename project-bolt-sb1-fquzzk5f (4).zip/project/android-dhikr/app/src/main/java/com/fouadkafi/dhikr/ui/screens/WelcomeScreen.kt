package com.fouadkafi.dhikr.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fouadkafi.dhikr.domain.AppSettings
import com.fouadkafi.dhikr.domain.Language
import com.fouadkafi.dhikr.ui.components.IslamicPatternBackground
import com.fouadkafi.dhikr.ui.components.CrescentIcon
import com.fouadkafi.dhikr.ui.components.GeometricDivider
import com.fouadkafi.dhikr.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun WelcomeScreen(
    settings: AppSettings?,
    onLanguageChange: (Language) -> Unit,
    onStart: () -> Unit
) {
    val context = LocalContext.current
    val isRtl = settings?.language == Language.ARABIC
    val lang = settings?.language ?: Language.ARABIC
    var showOnboarding by remember { mutableStateOf(false) }
    var hasOverlayPermission by remember { mutableStateOf(false) }

    // Check overlay permission on resume
    LaunchedEffect(Unit) {
        hasOverlayPermission = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else true
    }

    val emeraldGradient = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF0A3D2E),
            Color(0xFF052016),
            Color(0xFF031410)
        )
    )

    if (showOnboarding) {
        OnboardingContent(
            lang = lang,
            isRtl = isRtl,
            hasOverlayPermission = hasOverlayPermission,
            onGrantPermission = {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${context.packageName}")
                    )
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                }
            },
            onContinue = onStart,
            onBack = { showOnboarding = false }
        )
        return
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(emeraldGradient)
    ) {
        // Background pattern
        IslamicPatternBackground(color = Champagne, alpha = 0.05f)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top: Crescent emblem
            Spacer(modifier = Modifier.height(40.dp))
            Box(contentAlignment = Alignment.Center) {
                CrescentIcon(size = 56)
            }

            // Center content
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // App name
                Text(
                    text = "ذِكر ﷺ",
                    color = Ivory,
                    fontSize = 48.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Subtitle
                Text(
                    text = if (lang == Language.ARABIC) "رفيقك اليومي للصلاة على النبي ﷺ"
                           else "Your daily companion for sending blessings upon the Prophet ﷺ",
                    color = ChampagneLight.copy(alpha = 0.8f),
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Intro
                Text(
                    text = if (lang == Language.ARABIC)
                        "تذكير لطيف يظهر على هاتفك ليعينك على الإكثار من الصلاة على النبي ﷺ، في أوقات تختارها بنفسك."
                    else
                        "A gentle reminder that appears on your phone to help you frequently send blessings upon the Prophet ﷺ, at times you choose yourself.",
                    color = Ivory.copy(alpha = 0.6f),
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp
                )
                Spacer(modifier = Modifier.height(20.dp))

                // Quranic verse panel
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFF052016).copy(alpha = 0.6f),
                    border = BorderStroke(0.5.dp, Champagne.copy(alpha = 0.15f))
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        GeometricDivider(
                            modifier = Modifier.width(200.dp).height(20.dp),
                            color = Champagne.copy(alpha = 0.5f)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "إِنَّ اللَّهَ وَمَلَائِكَتَهُ يُصَلُّونَ عَلَى النَّبِيِّ ۚ يَا أَيُّهَا الَّذِينَ آمَنُوا صَلُّوا عَلَيْهِ وَسَلِّمُوا تَسْلِيمًا",
                            color = Ivory,
                            fontSize = 16.sp,
                            textAlign = TextAlign.Center,
                            lineHeight = 34.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (lang == Language.ARABIC) "سورة الأحزاب، الآية 56" else "Surah Al-Ahzab, Verse 56",
                            color = Champagne.copy(alpha = 0.6f),
                            fontSize = 11.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(20.dp))

                // Capsule preview
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color(0xFF0A0A0A),
                    border = BorderStroke(0.5.dp, Champagne.copy(alpha = 0.15f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CrescentIcon(size = 14)
                        Text(
                            text = "صلِّ على النبي ﷺ",
                            color = Color.White,
                            fontSize = 12.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))

                // Start button
                Button(
                    onClick = { showOnboarding = true },
                    modifier = Modifier
                        .fillMaxWidth(0.8f)
                        .height(56.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Champagne,
                        contentColor = EmeraldDark
                    )
                ) {
                    Text(
                        text = if (lang == Language.ARABIC) "ابدأ" else "Begin",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Bottom: language selector + privacy + credit
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Language selector
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color(0xFF052016).copy(alpha = 0.5f))
                        .border(0.5.dp, Champagne.copy(alpha = 0.1f), RoundedCornerShape(50))
                        .padding(4.dp)
                ) {
                    LangButton("العربية", lang == Language.ARABIC) { onLanguageChange(Language.ARABIC) }
                    LangButton("English", lang == Language.ENGLISH) { onLanguageChange(Language.ENGLISH) }
                }

                Text(
                    text = if (lang == Language.ARABIC) "خصوصيتك أولويتنا — بياناتك تبقى على جهازك."
                           else "Your privacy is our priority — your data stays on your device.",
                    color = Ivory.copy(alpha = 0.4f),
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "صنع من طرف فؤاد كفي",
                    color = Champagne.copy(alpha = 0.4f),
                    fontSize = 11.sp
                )
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun LangButton(label: String, active: Boolean, onClick: () -> Unit) {
    TextButton(onClick = onClick) {
        Text(
            text = label,
            fontSize = 13.sp,
            color = if (active) ChampagneLight else Ivory.copy(alpha = 0.4f),
            fontWeight = if (active) FontWeight.Medium else FontWeight.Normal
        )
    }
}

@Composable
private fun OnboardingContent(
    lang: Language,
    isRtl: Boolean,
    hasOverlayPermission: Boolean,
    onGrantPermission: () -> Unit,
    onContinue: () -> Unit,
    onBack: () -> Unit
) {
    val emeraldGradient = Brush.verticalGradient(
        colors = listOf(Color(0xFF052016), Color(0xFF031410))
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(emeraldGradient)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        IslamicPatternBackground(color = Champagne, alpha = 0.03f)

        Surface(
            shape = RoundedCornerShape(24.dp),
            color = EmeraldDeep.copy(alpha = 0.7f),
            border = BorderStroke(0.5.dp, Champagne.copy(alpha = 0.15f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Icon
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Brush.linearGradient(listOf(EmeraldMid, EmeraldDark))),
                    contentAlignment = Alignment.Center
                ) {
                    CrescentIcon(size = 32)
                }
                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = if (lang == Language.ARABIC) "التذكير العائم" else "Floating Reminder",
                    color = Ivory,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (lang == Language.ARABIC)
                        "يظهر تذكير أنيق فوق تطبيقاتك الأخرى لتشجيعك على الصلاة على النبي ﷺ."
                    else
                        "An elegant reminder appears above your other apps to encourage you to send blessings upon the Prophet ﷺ.",
                    color = Ivory.copy(alpha = 0.7f),
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Permission status
                PermissionRow(
                    label = if (lang == Language.ARABIC) "إذن العرض فوق التطبيقات" else "Overlay Permission",
                    granted = hasOverlayPermission,
                    actionLabel = if (lang == Language.ARABIC) "منح الإذن" else "Grant Permission",
                    onAction = onGrantPermission,
                    lang = lang
                )
                Spacer(modifier = Modifier.height(8.dp))

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF3D2A00).copy(alpha = 0.3f)
                ) {
                    Text(
                        text = if (lang == Language.ARABIC)
                            "في تطبيق أندرويد الأصلي، يظهر التذكير فوق التطبيقات الأخرى باستخدام WindowManager."
                        else
                            "In the native Android app, the reminder appears over other apps using WindowManager.",
                        color = Color(0xFFE8CD8A).copy(alpha = 0.5f),
                        fontSize = 11.sp,
                        modifier = Modifier.padding(12.dp),
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))

                // Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = onBack,
                        modifier = Modifier.weight(1f).height(48.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Ivory.copy(alpha = 0.7f))
                    ) {
                        Text(if (lang == Language.ARABIC) "رجوع" else "Back")
                    }
                    Button(
                        onClick = onContinue,
                        modifier = Modifier.weight(1f).height(48.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Champagne,
                            contentColor = EmeraldDark
                        )
                    ) {
                        Text(if (lang == Language.ARABIC) "متابعة" else "Continue", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionRow(
    label: String,
    granted: Boolean,
    actionLabel: String,
    onAction: () -> Unit,
    lang: Language
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF052016).copy(alpha = 0.5f),
        border = BorderStroke(0.5.dp, Champagne.copy(alpha = 0.1f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(RoundedCornerShape(50))
                        .background(if (granted) EmeraldLight else Champagne.copy(alpha = 0.3f))
                )
                Text(label, color = Ivory.copy(alpha = 0.7f), fontSize = 13.sp)
            }
            if (granted) {
                Text(
                    text = if (lang == Language.ARABIC) "تم منح الإذن" else "Granted",
                    color = EmeraldLight,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            } else {
                TextButton(onClick = onAction) {
                    Text(actionLabel, color = Champagne, fontSize = 12.sp)
                }
            }
        }
    }
}
