package com.fouadkafi.dhikr.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.fouadkafi.dhikr.domain.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "dhikr_settings")

class SettingsManager(private val context: Context) {

    private object Keys {
        val LANGUAGE = stringPreferencesKey("language")
        val THEME = stringPreferencesKey("theme")
        val OVERLAY_STYLE = stringPreferencesKey("overlay_style")
        val ANIMATIONS = booleanPreferencesKey("animations")
        val VIBRATION = booleanPreferencesKey("vibration")
        val SOUND = booleanPreferencesKey("sound")
        val REMINDERS_ENABLED = booleanPreferencesKey("reminders_enabled")
        val REMINDER_INTERVAL = intPreferencesKey("reminder_interval")
        val FRIDAY_ENABLED = booleanPreferencesKey("friday_enabled")
        val FRIDAY_INTERVAL = intPreferencesKey("friday_interval")
        val QUIET_START = stringPreferencesKey("quiet_start")
        val QUIET_END = stringPreferencesKey("quiet_end")
        val ACTIVE_START = stringPreferencesKey("active_start")
        val ACTIVE_END = stringPreferencesKey("active_end")
        val SCREEN_ON_ONLY = booleanPreferencesKey("screen_on_only")
        val DAILY_GOAL = intPreferencesKey("daily_goal")
        val OVERLAY_TAP_COUNTS = booleanPreferencesKey("overlay_tap_counts")
        val TEMP_PAUSE_UNTIL = longPreferencesKey("temp_pause_until")
        val FRIDAY_CALC = stringPreferencesKey("friday_calc")
        val MANUAL_SUNSET = stringPreferencesKey("manual_sunset")
        val ACHIEVEMENTS = booleanPreferencesKey("achievements")
        val ONBOARDED = booleanPreferencesKey("onboarded")

        // Stats
        val LIFETIME_COUNT = intPreferencesKey("lifetime_count")
        val TODAY_COUNT = intPreferencesKey("today_count")
        val PERSONAL_BEST = intPreferencesKey("personal_best")
        val CURRENT_STREAK = intPreferencesKey("current_streak")
        val LAST_ACTIVE_DATE = stringPreferencesKey("last_active_date")
        val MILESTONES_SHOWN = stringPreferencesKey("milestones_shown")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            language = Language.fromCode(prefs[Keys.LANGUAGE] ?: "ar"),
            theme = ThemeMode.valueOf(prefs[Keys.THEME] ?: "SYSTEM"),
            overlayStyle = OverlayStyle.valueOf(prefs[Keys.OVERLAY_STYLE] ?: "DYNAMIC_ISLAND"),
            animationsEnabled = prefs[Keys.ANIMATIONS] ?: true,
            vibrationEnabled = prefs[Keys.VIBRATION] ?: false,
            soundEnabled = prefs[Keys.SOUND] ?: false,
            remindersEnabled = prefs[Keys.REMINDERS_ENABLED] ?: false,
            reminderIntervalMinutes = prefs[Keys.REMINDER_INTERVAL] ?: 10,
            fridayModeEnabled = prefs[Keys.FRIDAY_ENABLED] ?: true,
            fridayIntervalMinutes = prefs[Keys.FRIDAY_INTERVAL] ?: 2,
            quietHoursStart = prefs[Keys.QUIET_START] ?: "22:00",
            quietHoursEnd = prefs[Keys.QUIET_END] ?: "06:00",
            activeHoursStart = prefs[Keys.ACTIVE_START] ?: "06:00",
            activeHoursEnd = prefs[Keys.ACTIVE_END] ?: "23:00",
            screenOnOnly = prefs[Keys.SCREEN_ON_ONLY] ?: true,
            dailyGoal = prefs[Keys.DAILY_GOAL] ?: 100,
            overlayTapCounts = prefs[Keys.OVERLAY_TAP_COUNTS] ?: false,
            tempPauseUntil = prefs[Keys.TEMP_PAUSE_UNTIL],
            fridayCalcMethod = FridayCalcMethod.valueOf(prefs[Keys.FRIDAY_CALC] ?: "MANUAL"),
            manualFridaySunset = prefs[Keys.MANUAL_SUNSET] ?: "18:30",
            achievementsEnabled = prefs[Keys.ACHIEVEMENTS] ?: true,
            onboarded = prefs[Keys.ONBOARDED] ?: false
        )
    }

    suspend fun updateSettings(partial: PartialSettings) {
        context.dataStore.edit { prefs ->
            partial.language?.let { prefs[Keys.LANGUAGE] = it.code }
            partial.theme?.let { prefs[Keys.THEME] = it.name }
            partial.overlayStyle?.let { prefs[Keys.OVERLAY_STYLE] = it.name }
            partial.animationsEnabled?.let { prefs[Keys.ANIMATIONS] = it }
            partial.vibrationEnabled?.let { prefs[Keys.VIBRATION] = it }
            partial.soundEnabled?.let { prefs[Keys.SOUND] = it }
            partial.remindersEnabled?.let { prefs[Keys.REMINDERS_ENABLED] = it }
            partial.reminderIntervalMinutes?.let { prefs[Keys.REMINDER_INTERVAL] = it }
            partial.fridayModeEnabled?.let { prefs[Keys.FRIDAY_ENABLED] = it }
            partial.fridayIntervalMinutes?.let { prefs[Keys.FRIDAY_INTERVAL] = it }
            partial.quietHoursStart?.let { prefs[Keys.QUIET_START] = it }
            partial.quietHoursEnd?.let { prefs[Keys.QUIET_END] = it }
            partial.activeHoursStart?.let { prefs[Keys.ACTIVE_START] = it }
            partial.activeHoursEnd?.let { prefs[Keys.ACTIVE_END] = it }
            partial.screenOnOnly?.let { prefs[Keys.SCREEN_ON_ONLY] = it }
            partial.dailyGoal?.let { prefs[Keys.DAILY_GOAL] = it }
            partial.overlayTapCounts?.let { prefs[Keys.OVERLAY_TAP_COUNTS] = it }
            partial.tempPauseUntil?.let { prefs[Keys.TEMP_PAUSE_UNTIL] = it }
            partial.fridayCalcMethod?.let { prefs[Keys.FRIDAY_CALC] = it.name }
            partial.manualFridaySunset?.let { prefs[Keys.MANUAL_SUNSET] = it }
            partial.achievementsEnabled?.let { prefs[Keys.ACHIEVEMENTS] = it }
            partial.onboarded?.let { prefs[Keys.ONBOARDED] = it }
        }
    }

    suspend fun updateLanguage(lang: Language) = updateSettings(PartialSettings(language = lang))
    suspend fun setOnboarded(value: Boolean) = updateSettings(PartialSettings(onboarded = value))
    suspend fun updateRemindersEnabled(enabled: Boolean) = updateSettings(PartialSettings(remindersEnabled = enabled))
}

data class PartialSettings(
    val language: Language? = null,
    val theme: ThemeMode? = null,
    val overlayStyle: OverlayStyle? = null,
    val animationsEnabled: Boolean? = null,
    val vibrationEnabled: Boolean? = null,
    val soundEnabled: Boolean? = null,
    val remindersEnabled: Boolean? = null,
    val reminderIntervalMinutes: Int? = null,
    val fridayModeEnabled: Boolean? = null,
    val fridayIntervalMinutes: Int? = null,
    val quietHoursStart: String? = null,
    val quietHoursEnd: String? = null,
    val activeHoursStart: String? = null,
    val activeHoursEnd: String? = null,
    val screenOnOnly: Boolean? = null,
    val dailyGoal: Int? = null,
    val overlayTapCounts: Boolean? = null,
    val tempPauseUntil: Long? = null,
    val fridayCalcMethod: FridayCalcMethod? = null,
    val manualFridaySunset: String? = null,
    val achievementsEnabled: Boolean? = null,
    val onboarded: Boolean? = null
)
