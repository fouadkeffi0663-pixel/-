package com.fouadkafi.dhikr.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Emerald palette
val EmeraldDeep = Color(0xFF0A3D2E)
val EmeraldMid = Color(0xFF14532D)
val EmeraldDark = Color(0xFF052016)
val Midnight = Color(0xFF031410)
val Ivory = Color(0xFFFDF9EE)
val Champagne = Color(0xFFD4AF6E)
val ChampagneLight = Color(0xFFF0DDAF)
val ChampagneDark = Color(0xFFA88038)
val Sage = Color(0xFF8BA87A)
val EmeraldLight = Color(0xFF16A34A)

private val DarkColorScheme = darkColorScheme(
    primary = Champagne,
    secondary = EmeraldLight,
    tertiary = ChampagneLight,
    background = Midnight,
    surface = EmeraldDeep,
    onPrimary = EmeraldDark,
    onSecondary = Color.White,
    onBackground = Ivory,
    onSurface = Ivory,
    surfaceVariant = Color(0xFF0F4D2A),
    onSurfaceVariant = Color(0xFFC4D4B8)
)

private val LightColorScheme = lightColorScheme(
    primary = ChampagneDark,
    secondary = EmeraldMid,
    tertiary = ChampagneDark,
    background = Ivory,
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = EmeraldDark,
    onSurface = EmeraldDark,
    surfaceVariant = Color(0xFFF0FDF6),
    onSurfaceVariant = Color(0xFF15803D)
)

@Composable
fun DhikrTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography(
            bodyLarge = Typography().bodyLarge.copy(
                fontFamily = FontFamily.Default,
                lineHeight = 26.sp
            )
        ),
        content = content
    )
}

