import { useState, useEffect, useRef } from 'react';
import { CrescentIcon, IslamicPattern, StarEmblem, GeometricDivider } from './IslamicPattern';
import type { Language, AppSettings, Stats, Screen } from '../types';
import { t } from '../i18n';
import { MILESTONES } from '../types';

interface CounterProps {
  language: Language;
  settings: AppSettings;
  stats: Stats;
  onIncrement: () => void;
  onResetToday: () => void;
  onCorrectCount: (newCount: number) => void;
  onNavigate: (screen: Screen) => void;
  onMarkMilestone: (count: number) => void;
  effectiveTheme: 'light' | 'dark';
}

export function CounterScreen({
  language,
  settings,
  stats,
  onIncrement,
  onResetToday,
  onCorrectCount,
  onNavigate,
  onMarkMilestone,
  effectiveTheme,
}: CounterProps) {
  const isRtl = language === 'ar';
  const isDark = effectiveTheme === 'dark';
  const [showRipple, setShowRipple] = useState(false);
  const [showMilestone, setShowMilestone] = useState<{ count: number; messageAr: string; messageEn: string } | null>(null);
  const [showResetDialog, setShowResetDialog] = useState(false);
  const [showCorrectDialog, setShowCorrectDialog] = useState(false);
  const [correctValue, setCorrectValue] = useState(stats.todayCount.toString());
  const [animateCount, setAnimateCount] = useState(false);
  const prevCountRef = useRef(stats.todayCount);

  // Check for new milestones
  useEffect(() => {
    for (const m of MILESTONES) {
      if (stats.lifetimeCount >= m.count && !stats.milestonesShown.includes(m.count)) {
        setShowMilestone(m);
        onMarkMilestone(m.count);
        break;
      }
    }
  }, [stats.lifetimeCount, stats.milestonesShown, onMarkMilestone]);

  // Animate count change
  useEffect(() => {
    if (stats.todayCount !== prevCountRef.current) {
      setAnimateCount(true);
      const timer = setTimeout(() => setAnimateCount(false), 300);
      prevCountRef.current = stats.todayCount;
      return () => clearTimeout(timer);
    }
  }, [stats.todayCount]);

  const handleTap = () => {
    onIncrement();
    setShowRipple(true);
    setTimeout(() => setShowRipple(false), 600);
    if (settings.vibrationEnabled && 'vibrate' in navigator) {
      navigator.vibrate(30);
    }
  };

  const bgClass = isDark
    ? 'bg-gradient-to-b from-midnight-900 to-midnight-950'
    : 'bg-gradient-to-b from-emerald-50 to-ivory-100';
  const textClass = isDark ? 'text-ivory-100' : 'text-emerald-950';
  const subTextClass = isDark ? 'text-ivory-200/60' : 'text-emerald-800/60';
  const cardClass = isDark
    ? 'bg-emerald-850/40 border-champagne-400/10'
    : 'bg-white border-emerald-200/40';

  const goalProgress = stats.todayCount > 0 && settings.dailyGoal > 0
    ? Math.min(100, (stats.todayCount / settings.dailyGoal) * 100)
    : 0;

  return (
    <div dir={isRtl ? 'rtl' : 'ltr'} className={`min-h-screen ${bgClass} ${textClass} relative overflow-hidden`}>
      <IslamicPattern className={`absolute inset-0 ${isDark ? 'text-champagne-400' : 'text-emerald-700'}`} opacity={isDark ? 0.03 : 0.02} />

      <div className="relative z-10 max-w-lg mx-auto p-5 pt-8 safe-top safe-bottom flex flex-col min-h-screen">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => onNavigate('dashboard')}
            className={`w-11 h-11 rounded-xl ${cardClass} border flex items-center justify-center hover:scale-105 transition-transform`}
            aria-label={t('back', language)}
          >
            <BackIcon />
          </button>
          <h1 className="text-lg font-arabic font-bold">{t('counter', language)}</h1>
          <div className="w-11" />
        </div>

        {/* Today count display */}
        <div className="text-center mb-2">
          <p className={`text-sm ${subTextClass} mb-1`}>{t('todayCount', language)}</p>
          <p
            className={`text-6xl font-bold text-champagne-400 transition-transform ${animateCount ? 'scale-110' : 'scale-100'}`}
            style={{ transition: 'transform 0.3s ease' }}
          >
            {stats.todayCount.toLocaleString()}
          </p>
        </div>

        {/* Goal progress bar */}
        <div className={`rounded-2xl border ${cardClass} p-3 mb-4`}>
          <div className="flex items-center justify-between mb-2">
            <p className={`text-xs ${subTextClass}`}>{t('dailyGoal', language)}</p>
            <p className="text-xs font-medium">
              {stats.todayCount} {t('of', language)} {settings.dailyGoal}
            </p>
          </div>
          <div className={`h-2 rounded-full overflow-hidden ${isDark ? 'bg-emerald-950/50' : 'bg-emerald-100'}`}>
            <div
              className="h-full rounded-full bg-gradient-to-r from-champagne-400 to-champagne-600 transition-all duration-500"
              style={{ width: `${goalProgress}%` }}
            />
          </div>
        </div>

        {/* Big tap button */}
        <div className="flex-1 flex flex-col items-center justify-center py-8">
          <button
            onClick={handleTap}
            className="no-select relative w-64 h-64 rounded-full bg-gradient-to-br from-emerald-700 via-emerald-800 to-emerald-950 border-2 border-champagne-400/20 shadow-2xl shadow-emerald-900/40 hover:shadow-emerald-900/60 active:scale-95 transition-all flex flex-col items-center justify-center gap-3"
            aria-label={t('tapToCount', language)}
          >
            {/* Decorative ring */}
            <div className="absolute inset-3 rounded-full border border-champagne-400/10" />
            <div className="absolute inset-6 rounded-full border border-champagne-400/5" />

            {showRipple && (
              <div className="absolute inset-0 rounded-full bg-champagne-400/20 animate-ping" />
            )}

            <CrescentIcon size={48} className={settings.animationsEnabled ? 'animate-glow' : ''} />
            <GeometricDivider className="text-champagne-400/30" />
            <p className="text-ivory-100 font-arabic text-lg font-bold text-center px-6 leading-relaxed">
              {t('tapToCount', language)}
            </p>
            <p className={`text-xs ${subTextClass} mt-1`}>
              {t('tapHint', language)}
            </p>
          </button>
        </div>

        {/* Quick stats */}
        <div className="grid grid-cols-3 gap-3 mb-4">
          <div className={`rounded-2xl border ${cardClass} p-3 text-center`}>
            <p className={`text-xs ${subTextClass} mb-1`}>{t('lifetimeCount', language)}</p>
            <p className="text-lg font-bold text-champagne-400">
              {stats.lifetimeCount.toLocaleString()}
            </p>
          </div>
          <div className={`rounded-2xl border ${cardClass} p-3 text-center`}>
            <p className={`text-xs ${subTextClass} mb-1`}>{t('currentStreak', language)}</p>
            <p className="text-lg font-bold text-emerald-500">
              {stats.currentStreak} {t('days', language)}
            </p>
          </div>
          <div className={`rounded-2xl border ${cardClass} p-3 text-center`}>
            <p className={`text-xs ${subTextClass} mb-1`}>{t('personalBest', language)}</p>
            <p className="text-lg font-bold text-emerald-500">
              {stats.personalBestDay}
            </p>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex gap-3 mb-4">
          <button
            onClick={() => { setCorrectValue(stats.todayCount.toString()); setShowCorrectDialog(true); }}
            className={`flex-1 py-3 rounded-2xl ${cardClass} border text-sm font-medium hover:scale-[1.02] transition-transform`}
          >
            {t('correctCount', language)}
          </button>
          <button
            onClick={() => setShowResetDialog(true)}
            className={`flex-1 py-3 rounded-2xl ${cardClass} border text-sm font-medium text-red-400/70 hover:scale-[1.02] transition-transform`}
          >
            {t('reset', language)}
          </button>
        </div>

        {/* Nav tabs */}
        <div className={`flex items-center justify-around rounded-2xl border ${cardClass} p-2`}>
          <NavTab icon="home" label={t('dashboard', language)} active={false} onClick={() => onNavigate('dashboard')} isDark={isDark} />
          <NavTab icon="counter" label={t('counter', language)} active={true} onClick={() => onNavigate('counter')} isDark={isDark} />
          <NavTab icon="stats" label={t('statistics', language)} active={false} onClick={() => onNavigate('statistics')} isDark={isDark} />
          <NavTab icon="settings" label={t('settings', language)} active={false} onClick={() => onNavigate('settings')} isDark={isDark} />
        </div>
      </div>

      {/* Milestone dialog */}
      {showMilestone && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-6" onClick={() => setShowMilestone(null)}>
          <div
            className={`max-w-sm w-full rounded-3xl border border-champagne-400/20 p-8 text-center ${isDark ? 'bg-emerald-850' : 'bg-white'}`}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-center mb-4">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-champagne-300 to-champagne-600 flex items-center justify-center">
                <StarEmblem size={32} className="text-emerald-950" />
              </div>
            </div>
            <p className="text-champagne-400 text-sm font-medium mb-2">{t('milestoneReached', language)}</p>
            <p className="text-3xl font-bold mb-3">{showMilestone.count.toLocaleString()}</p>
            <p className={`text-sm ${subTextClass} leading-relaxed mb-6`}>
              {language === 'ar' ? showMilestone.messageAr : showMilestone.messageEn}
            </p>
            <button
              onClick={() => setShowMilestone(null)}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-emerald-800 text-ivory-100 font-bold hover:shadow-lg transition-all"
            >
              {t('continue', language)}
            </button>
          </div>
        </div>
      )}

      {/* Reset dialog */}
      {showResetDialog && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-6" onClick={() => setShowResetDialog(false)}>
          <div
            className={`max-w-sm w-full rounded-3xl border ${cardClass} p-6 text-center`}
            onClick={(e) => e.stopPropagation()}
          >
            <p className="text-base mb-6 leading-relaxed">{t('confirmResetToday', language)}</p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowResetDialog(false)}
                className={`flex-1 py-3.5 rounded-2xl ${cardClass} border text-sm font-medium`}
              >
                {t('cancel', language)}
              </button>
              <button
                onClick={() => { onResetToday(); setShowResetDialog(false); }}
                className="flex-1 py-3.5 rounded-2xl bg-red-500/80 text-white text-sm font-bold hover:bg-red-500 transition-colors"
              >
                {t('confirm', language)}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Correct count dialog */}
      {showCorrectDialog && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-6" onClick={() => setShowCorrectDialog(false)}>
          <div
            className={`max-w-sm w-full rounded-3xl border ${cardClass} p-6`}
            onClick={(e) => e.stopPropagation()}
          >
            <p className="text-sm mb-4 font-medium">{t('correctCount', language)}</p>
            <input
              type="number"
              value={correctValue}
              onChange={(e) => setCorrectValue(e.target.value)}
              className={`w-full py-3 px-4 rounded-2xl ${isDark ? 'bg-emerald-950/50 text-ivory-100' : 'bg-emerald-50 text-emerald-950'} border border-champagne-400/20 text-lg text-center mb-4 outline-none focus:border-champagne-400/50`}
              autoFocus
            />
            <div className="flex gap-3">
              <button
                onClick={() => setShowCorrectDialog(false)}
                className={`flex-1 py-3.5 rounded-2xl ${cardClass} border text-sm font-medium`}
              >
                {t('cancel', language)}
              </button>
              <button
                onClick={() => {
                  const val = parseInt(correctValue, 10);
                  if (!isNaN(val) && val >= 0) {
                    onCorrectCount(val);
                    setShowCorrectDialog(false);
                  }
                }}
                className="flex-1 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-emerald-800 text-ivory-100 text-sm font-bold"
              >
                {t('confirm', language)}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function BackIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>
    </svg>
  );
}

function NavTab({
  icon,
  label,
  active,
  onClick,
  isDark,
}: {
  icon: string;
  label: string;
  active: boolean;
  onClick: () => void;
  isDark: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-all ${
        active
          ? isDark
            ? 'bg-champagne-400/15 text-champagne-300'
            : 'bg-emerald-100 text-emerald-700'
          : isDark
            ? 'text-ivory-200/40 hover:text-ivory-200/70'
            : 'text-emerald-800/40 hover:text-emerald-800/70'
      }`}
    >
      <NavIcon name={icon} />
      <span className="text-xs">{label}</span>
    </button>
  );
}

function NavIcon({ name }: { name: string }) {
  switch (name) {
    case 'home':
      return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>;
    case 'counter':
      return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>;
    case 'stats':
      return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>;
    case 'settings':
      return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>;
    default:
      return null;
  }
}
