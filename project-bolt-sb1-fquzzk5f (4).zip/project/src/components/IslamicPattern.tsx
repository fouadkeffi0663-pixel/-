interface PatternProps {
  className?: string;
  opacity?: number;
}

export function IslamicPattern({ className = '', opacity = 0.08 }: PatternProps) {
  return (
    <svg
      className={className}
      width="100%"
      height="100%"
      xmlns="http://www.w3.org/2000/svg"
      style={{ opacity }}
      aria-hidden="true"
    >
      <defs>
        <pattern id="islamic-star" x="0" y="0" width="80" height="80" patternUnits="userSpaceOnUse">
          <path
            d="M40 5 L55 25 L75 25 L60 40 L75 55 L55 55 L40 75 L25 55 L5 55 L20 40 L5 25 L25 25 Z"
            fill="none"
            stroke="currentColor"
            strokeWidth="0.5"
          />
          <circle cx="40" cy="40" r="12" fill="none" stroke="currentColor" strokeWidth="0.3" />
          <path d="M40 28 L52 40 L40 52 L28 40 Z" fill="none" stroke="currentColor" strokeWidth="0.3" />
        </pattern>
        <pattern id="islamic-grid" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">
          <path d="M0 20 L20 0 L40 20 L20 40 Z" fill="none" stroke="currentColor" strokeWidth="0.4" />
          <path d="M20 0 L20 40 M0 20 L40 20" fill="none" stroke="currentColor" strokeWidth="0.2" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#islamic-star)" />
    </svg>
  );
}

export function ArabesqueCorner({ className = '', flip = false }: { className?: string; flip?: boolean }) {
  return (
    <svg
      className={className}
      width="180"
      height="180"
      viewBox="0 0 180 180"
      xmlns="http://www.w3.org/2000/svg"
      style={{ transform: flip ? 'scaleX(-1)' : undefined }}
      aria-hidden="true"
      fill="none"
      stroke="currentColor"
    >
      <path d="M10 10 Q60 10 60 60 Q60 110 110 110 Q160 110 160 60" strokeWidth="0.8" opacity="0.5" />
      <path d="M10 10 Q40 10 40 40 Q40 80 80 80 Q120 80 120 40" strokeWidth="0.5" opacity="0.3" />
      <circle cx="40" cy="40" r="8" strokeWidth="0.5" opacity="0.4" />
      <circle cx="80" cy="80" r="12" strokeWidth="0.5" opacity="0.3" />
      <path d="M20 10 Q20 30 40 30 M10 20 Q30 20 30 40" strokeWidth="0.4" opacity="0.25" />
      <path d="M60 60 Q70 50 80 60 Q70 70 60 60" strokeWidth="0.4" opacity="0.3" />
    </svg>
  );
}

export function CrescentIcon({ className = '', size = 48 }: { className?: string; size?: number }) {
  return (
    <svg
      className={className}
      width={size}
      height={size}
      viewBox="0 0 48 48"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="crescent-grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#f0ddaf" />
          <stop offset="100%" stopColor="#a88038" />
        </linearGradient>
      </defs>
      <path
        d="M24 4 A20 20 0 1 0 24 44 A16 16 0 1 1 24 4Z"
        fill="url(#crescent-grad)"
      />
    </svg>
  );
}

export function StarEmblem({ className = '', size = 32 }: { className?: string; size?: number }) {
  return (
    <svg
      className={className}
      width={size}
      height={size}
      viewBox="0 0 32 32"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <path
        d="M16 2 L19 12 L29 12 L21 18 L24 28 L16 22 L8 28 L11 18 L3 12 L13 12 Z"
        fill="currentColor"
      />
    </svg>
  );
}

export function GeometricDivider({ className = '' }: { className?: string }) {
  return (
    <svg
      className={className}
      width="200"
      height="20"
      viewBox="0 0 200 20"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
      fill="none"
      stroke="currentColor"
    >
      <line x1="0" y1="10" x2="70" y2="10" strokeWidth="0.5" opacity="0.5" />
      <path d="M100 2 L108 10 L100 18 L92 10 Z" strokeWidth="0.8" opacity="0.7" />
      <circle cx="100" cy="10" r="3" strokeWidth="0.5" opacity="0.5" />
      <line x1="130" y1="10" x2="200" y2="10" strokeWidth="0.5" opacity="0.5" />
      <circle cx="75" cy="10" r="2" strokeWidth="0.4" opacity="0.4" />
      <circle cx="125" cy="10" r="2" strokeWidth="0.4" opacity="0.4" />
    </svg>
  );
}
