import { useState, useEffect } from 'react';
import { CrescentIcon, IslamicPattern, ArabesqueCorner, GeometricDivider } from './IslamicPattern';
import type { Language } from '../types';
import { t } from '../i18n';

interface WelcomeProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  onStart: () => void;
  animationsEnabled: boolean;
}

export function WelcomeScreen({ language, onLanguageChange, onStart, animationsEnabled }: WelcomeProps) {
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [overlayPermissionGranted, setOverlayPermissionGranted] = useState(false);
  const isRtl = language === 'ar';
  const anim = animationsEnabled;

  useEffect(() => {
    // Check Notification API permission as web equivalent
    if ('Notification' in window) {
      setOverlayPermissionGranted(Notification.permission === 'granted');
    }
  }, []);

  const handleStart = () => {
    setShowOnboarding(true);
  };

  const handleGrantPermission = async () => {
    if ('Notification' in window) {
      const result = await Notification.requestPermission();
      setOverlayPermissionGranted(result === 'granted');
    }
  };

  const handleContinue = () => {
    onStart();
  };

  if (showOnboarding) {
    return (
      <div
        dir={isRtl ? 'rtl' : 'ltr'}
        className="min-h-screen bg-gradient-to-b from-midnight-900 via-emerald-900 to-midnight-950 relative overflow-hidden flex items-center justify-center p-6"
      >
        <IslamicPattern className="absolute inset-0 text-champagne-400" opacity={0.04} />
        <div className="absolute top-0 left-0 text-champagne-400 opacity-30">
          <ArabesqueCorner />
        </div>
        <div className="absolute top-0 right-0 text-champagne-400 opacity-30">
          <ArabesqueCorner flip />
        </div>

        <div
          className={`relative z-10 max-w-md w-full ${anim ? 'animate-fade-in-up' : ''}`}
        >
          {/* Onboarding card */}
          <div className="bg-emerald-850/60 backdrop-blur-xl rounded-3xl border border-champagne-400/15 p-8 text-center">
            <div className="flex justify-center mb-6">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-700 to-emerald-900 flex items-center justify-center border border-champagne-400/20">
                <CrescentIcon size={36} />
              </div>
            </div>

            <h2 className="text-2xl font-arabic font-bold text-ivory-100 mb-3">
              {t('onboardingTitle', language)}
            </h2>
            <p className="text-ivory-200/70 text-sm leading-relaxed mb-6">
              {t('onboardingDesc', language)}
            </p>

            {/* Capsule preview */}
            <div className="flex justify-center mb-6">
              <div className={`${anim ? 'animate-capsule-expand' : ''} bg-black/80 rounded-full px-6 py-3 border border-champagne-400/20 shadow-2xl`}>
                <div className="flex items-center gap-2">
                  <CrescentIcon size={16} />
                  <span className="text-white text-sm font-arabic">
                    {t('capsulePreview', language)}
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-emerald-950/40 rounded-2xl p-4 mb-6 text-start">
              <p className="text-ivory-200/60 text-xs leading-relaxed">
                {t('onboardingPermission', language)}
              </p>
            </div>

            {/* Permission status */}
            <div className="space-y-3 mb-6">
              <PermissionRow
                label={t('overlayPermission', language)}
                granted={overlayPermissionGranted}
                onAction={handleGrantPermission}
                actionLabel={t('grantPermission', language)}
                language={language}
              />
              <PermissionRow
                label={t('notificationPermission', language)}
                granted={overlayPermissionGranted}
                onAction={handleGrantPermission}
                actionLabel={t('grantPermission', language)}
                language={language}
              />
            </div>

            <div className="bg-amber-950/30 rounded-2xl p-3 mb-6 border border-amber-700/20">
              <p className="text-amber-200/50 text-xs leading-relaxed text-center">
                {t('webReminderNote', language)}
              </p>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setShowOnboarding(false)}
                className="flex-1 py-3.5 rounded-2xl bg-emerald-800/50 text-ivory-200/70 text-sm font-medium border border-champagne-400/10 hover:bg-emerald-800/70 transition-colors"
              >
                {t('back', language)}
              </button>
              <button
                onClick={handleContinue}
                className="flex-1 py-3.5 rounded-2xl bg-gradient-to-r from-champagne-400 to-champagne-600 text-emerald-950 text-sm font-bold hover:shadow-lg hover:shadow-champagne-500/20 transition-all"
              >
                {t('continue', language)}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      dir={isRtl ? 'rtl' : 'ltr'}
      className="min-h-screen bg-gradient-to-b from-emerald-850 via-emerald-900 to-midnight-950 relative overflow-hidden flex flex-col items-center justify-between p-6 safe-top safe-bottom"
    >
      {/* Background pattern */}
      <IslamicPattern className="absolute inset-0 text-champagne-400" opacity={0.05} />

      {/* Arabesque corners */}
      <div className={`absolute top-0 ${isRtl ? 'right-0' : 'left-0'} text-champagne-400 opacity-20 ${anim ? 'animate-fade-in' : ''}`}>
        <ArabesqueCorner />
      </div>
      <div className={`absolute top-0 ${isRtl ? 'left-0' : 'right-0'} text-champagne-400 opacity-20 ${anim ? 'animate-fade-in' : ''}`}>
        <ArabesqueCorner flip />
      </div>

      {/* Vignette overlay */}
      <div className="absolute inset-0 bg-radial-vignette pointer-events-none" style={{
        background: 'radial-gradient(ellipse at center, transparent 30%, rgba(3,20,16,0.6) 100%)'
      }} />

      {/* Top emblem */}
      <div className={`relative z-10 mt-8 ${anim ? 'animate-fade-in-down' : ''}`}>
        <div className="relative">
          <div className="absolute inset-0 bg-champagne-400/10 blur-2xl rounded-full" />
          <div className="relative flex flex-col items-center gap-2">
            <CrescentIcon size={56} className={anim ? 'animate-glow' : ''} />
          </div>
        </div>
      </div>

      {/* Central content */}
      <div className="relative z-10 flex flex-col items-center max-w-md w-full px-2">
        {/* App name */}
        <h1
          className={`text-5xl sm:text-6xl font-arabic font-bold text-ivory-100 text-center mb-2 ${anim ? 'animate-slide-up' : ''}`}
          style={{ textShadow: '0 2px 20px rgba(212,175,110,0.15)' }}
        >
          ذِكر ﷺ
        </h1>

        {/* Subtitle */}
        <p className={`text-champagne-300/80 text-base font-arabic text-center mb-4 ${anim ? 'animate-fade-in-up' : ''}`}
           style={{ animationDelay: '0.2s', opacity: anim ? undefined : 1 }}>
          {t('appSubtitle', language)}
        </p>

        {/* Introduction */}
        <p className={`text-ivory-200/60 text-sm leading-relaxed text-center mb-5 px-4 ${anim ? 'animate-fade-in-up' : ''}`}
           style={{ animationDelay: '0.4s', opacity: anim ? undefined : 1 }}>
          {t('intro', language)}
        </p>

        {/* Quranic verse panel */}
        <div
          className={`relative w-full bg-emerald-950/40 backdrop-blur-md rounded-2xl border border-champagne-400/15 p-5 mb-5 ${anim ? 'animate-fade-in-up' : ''}`}
          style={{ animationDelay: '0.6s', opacity: anim ? undefined : 1 }}
        >
          <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2">
            <GeometricDivider className="text-champagne-400" />
          </div>
          <p className="font-quran text-ivory-100 text-center text-lg leading-loose mb-3">
            {t('quranVerse', language)}
          </p>
          <p className="text-champagne-400/60 text-xs text-center">
            {t('quranRef', language)}
          </p>
        </div>

        {/* Capsule preview */}
        <div className={`flex justify-center mb-6 ${anim ? 'animate-scale-in' : ''}`}
             style={{ animationDelay: '0.8s', opacity: anim ? undefined : 1 }}>
          <div className="bg-black/85 rounded-full px-5 py-2.5 border border-champagne-400/15 shadow-xl">
            <div className="flex items-center gap-2">
              <CrescentIcon size={14} />
              <span className="text-white text-xs font-arabic">
                {t('capsulePreview', language)}
              </span>
            </div>
          </div>
        </div>

        {/* Start button */}
        <button
          onClick={handleStart}
          className={`w-full max-w-xs py-4 rounded-2xl bg-gradient-to-r from-champagne-400 to-champagne-600 text-emerald-950 text-lg font-bold shadow-lg shadow-champagne-500/20 hover:shadow-xl hover:shadow-champagne-500/30 hover:scale-[1.02] active:scale-[0.98] transition-all ${anim ? 'animate-fade-in-up' : ''}`}
          style={{ animationDelay: '1s', opacity: anim ? undefined : 1 }}
        >
          {t('start', language)}
        </button>
      </div>

      {/* Bottom section */}
      <div className={`relative z-10 w-full max-w-md flex flex-col items-center gap-3 mb-6 ${anim ? 'animate-fade-in' : ''}`}
           style={{ animationDelay: '1.2s', opacity: anim ? undefined : 1 }}>
        {/* Language selector */}
        <div className="flex items-center gap-2 bg-emerald-950/30 rounded-full p-1 border border-champagne-400/10">
          <button
            onClick={() => onLanguageChange('ar')}
            className={`px-4 py-1.5 rounded-full text-sm transition-all ${
              language === 'ar'
                ? 'bg-champagne-400/20 text-champagne-300 font-medium'
                : 'text-ivory-200/40 hover:text-ivory-200/70'
            }`}
          >
            العربية
          </button>
          <button
            onClick={() => onLanguageChange('en')}
            className={`px-4 py-1.5 rounded-full text-sm transition-all ${
              language === 'en'
                ? 'bg-champagne-400/20 text-champagne-300 font-medium'
                : 'text-ivory-200/40 hover:text-ivory-200/70'
            }`}
          >
            English
          </button>
        </div>

        {/* Privacy note */}
        <p className="text-ivory-200/40 text-xs text-center">
          {t('privacyNote', language)}
        </p>

        {/* Developer credit */}
        <p className="text-champagne-400/40 text-xs text-center font-arabic">
          {t('developerCredit', language)}
        </p>
      </div>
    </div>
  );
}

function PermissionRow({
  label,
  granted,
  onAction,
  actionLabel,
  language,
}: {
  label: string;
  granted: boolean;
  onAction: () => void;
  actionLabel: string;
  language: Language;
}) {
  return (
    <div className="flex items-center justify-between bg-emerald-950/40 rounded-xl px-4 py-3 border border-champagne-400/10">
      <div className="flex items-center gap-3">
        <div className={`w-2.5 h-2.5 rounded-full ${granted ? 'bg-emerald-400' : 'bg-champagne-400/30'}`} />
        <span className="text-ivory-200/70 text-sm">{label}</span>
      </div>
      {granted ? (
        <span className="text-emerald-400 text-xs font-medium">{t('permissionGranted', language)}</span>
      ) : (
        <button
          onClick={onAction}
          className="text-champagne-400 text-xs font-medium hover:text-champagne-300 transition-colors"
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
}
