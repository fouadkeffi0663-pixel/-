import { useState, useEffect } from 'react';
import { CrescentIcon, IslamicPattern, StarEmblem } from './IslamicPattern';
import type { Language, AppSettings, Stats, Screen } from '../types';
import { t } from '../i18n';
import { getCurrentInterval, isFridayPeriod, isTempPaused } from '../lib/scheduling';
import { getTodayDate } from '../useAppData';

interface DashboardProps {
  language: Language;
  settings: AppSettings;
  stats: Stats;
  onToggleReminders: () => void;
  onNavigate: (screen: Screen) => void;
  effectiveTheme: 'light' | 'dark';
}

export function Dashboard({
  language,
  settings,
  stats,
  onToggleReminders,
  onNavigate,
  effectiveTheme,
}: DashboardProps) {
  const isRtl = language === 'ar';
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(interval);
  }, []);

  const currentInterval = getCurrentInterval(settings);
  const fridayActive = settings.fridayModeEnabled && isFridayPeriod(
    settings.fridayCalcMethod,
    settings.manualFridayStart,
    settings.manualFridayEnd,
    now
  );
  const tempPaused = isTempPaused(settings.tempPauseUntil);
  const reminderActive = settings.remindersEnabled && !tempPaused;

  const greetingKey = getGreetingKey(now.getHours());
  const goalProgress = stats.todayCount > 0 && settings.dailyGoal > 0
    ? Math.min(100, (stats.todayCount / settings.dailyGoal) * 100)
    : 0;

  const nextReminderTime = reminderActive
    ? new Date(now.getTime() + currentInterval * 60000)
    : null;

  const isDark = effectiveTheme === 'dark';
  const bgClass = isDark
    ? 'bg-gradient-to-b from-midnight-900 to-midnight-950'
    : 'bg-gradient-to-b from-emerald-50 to-ivory-100';
  const textClass = isDark ? 'text-ivory-100' : 'text-emerald-950';
  const subTextClass = isDark ? 'text-ivory-200/60' : 'text-emerald-800/60';
  const cardClass = isDark
    ? 'bg-emerald-850/40 border-champagne-400/10'
    : 'bg-white border-emerald-200/40';

  return (
    <div dir={isRtl ? 'rtl' : 'ltr'} className={`min-h-screen ${bgClass} ${textClass} relative overflow-hidden`}>
      <IslamicPattern className={`absolute inset-0 ${isDark ? 'text-champagne-400' : 'text-emerald-700'}`} opacity={isDark ? 0.03 : 0.02} />

      <div className="relative z-10 max-w-lg mx-auto p-5 pt-8 safe-top safe-bottom">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-emerald-700 to-emerald-900 flex items-center justify-center border border-champagne-400/20">
              <CrescentIcon size={24} />
            </div>
            <div>
              <p className={`text-sm ${subTextClass}`}>{t(greetingKey, language)}</p>
              <h1 className="text-lg font-arabic font-bold">ذِكر ﷺ</h1>
            </div>
          </div>
          <button
            onClick={() => onNavigate('settings')}
            className={`w-11 h-11 rounded-xl ${cardClass} border flex items-center justify-center hover:scale-105 transition-transform`}
            aria-label={t('settings', language)}
          >
            <SettingsIcon />
          </button>
        </div>

        {/* Reminder status card */}
        <div className={`rounded-3xl border ${cardClass} p-5 mb-4 ${settings.animationsEnabled ? 'animate-fade-in-up' : ''}`}>
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className={`text-xs ${subTextClass} mb-1`}>{t('reminderStatus', language)}</p>
              <div className="flex items-center gap-2">
                <div className={`w-2.5 h-2.5 rounded-full ${reminderActive ? 'bg-emerald-400 animate-gentle-pulse' : tempPaused ? 'bg-amber-400' : 'bg-red-400/60'}`} />
                <span className="text-lg font-bold">
                  {reminderActive ? t('active', language) : tempPaused ? t('paused', language) : t('disabled', language)}
                </span>
                {fridayActive && (
                  <span className="text-xs px-2 py-0.5 rounded-full bg-champagne-400/15 text-champagne-400 font-medium">
                    {t('fridayActive', language)}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Enable/Pause control */}
          <button
            onClick={onToggleReminders}
            className={`w-full py-4 rounded-2xl font-bold text-base transition-all active:scale-[0.98] ${
              reminderActive
                ? 'bg-amber-900/20 text-amber-400 border border-amber-700/30 hover:bg-amber-900/30'
                : 'bg-gradient-to-r from-emerald-600 to-emerald-800 text-ivory-100 hover:shadow-lg hover:shadow-emerald-700/20'
            }`}
          >
            {!settings.remindersEnabled
              ? t('enable', language)
              : tempPaused
              ? t('resume', language)
              : t('pause', language)}
          </button>
        </div>

        {/* Current interval & next reminder */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className={`rounded-2xl border ${cardClass} p-4 ${settings.animationsEnabled ? 'animate-fade-in-up' : ''}`}
               style={{ animationDelay: '0.1s' }}>
            <p className={`text-xs ${subTextClass} mb-1`}>{t('currentInterval', language)}</p>
            <p className="text-2xl font-bold">
              {currentInterval}
              <span className={`text-sm ${subTextClass} mr-1`}> {t('minutes', language)}</span>
            </p>
            {fridayActive && (
              <p className="text-xs text-champagne-400 mt-1">{t('fridayMode', language)}</p>
            )}
          </div>
          <div className={`rounded-2xl border ${cardClass} p-4 ${settings.animationsEnabled ? 'animate-fade-in-up' : ''}`}
               style={{ animationDelay: '0.2s' }}>
            <p className={`text-xs ${subTextClass} mb-1`}>{t('nextReminder', language)}</p>
            {nextReminderTime ? (
              <p className="text-2xl font-bold">
                {nextReminderTime.toLocaleTimeString(isRtl ? 'ar' : 'en', { hour: '2-digit', minute: '2-digit' })}
              </p>
            ) : (
              <p className={`text-sm ${subTextClass} mt-2`}>{t('reminderDisabled', language)}</p>
            )}
          </div>
        </div>

        {/* Today's count + Lifetime */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <StatCard
            label={t('todayCount', language)}
            value={stats.todayCount}
            subTextClass={subTextClass}
            cardClass={cardClass}
            accent="gold"
            animate={settings.animationsEnabled}
            delay={0.3}
          />
          <StatCard
            label={t('lifetimeCount', language)}
            value={stats.lifetimeCount}
            subTextClass={subTextClass}
            cardClass={cardClass}
            accent="emerald"
            animate={settings.animationsEnabled}
            delay={0.4}
          />
        </div>

        {/* Streak + Personal best */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <StatCard
            label={t('currentStreak', language)}
            value={stats.currentStreak}
            suffix={` ${t('days', language)}`}
            subTextClass={subTextClass}
            cardClass={cardClass}
            accent="emerald"
            animate={settings.animationsEnabled}
            delay={0.5}
          />
          <StatCard
            label={t('personalBest', language)}
            value={stats.personalBestDay}
            subTextClass={subTextClass}
            cardClass={cardClass}
            accent="gold"
            animate={settings.animationsEnabled}
            delay={0.6}
          />
        </div>

        {/* Daily goal progress */}
        <div className={`rounded-2xl border ${cardClass} p-4 mb-4 ${settings.animationsEnabled ? 'animate-fade-in-up' : ''}`}
             style={{ animationDelay: '0.7s' }}>
          <div className="flex items-center justify-between mb-2">
            <p className={`text-sm ${subTextClass}`}>{t('dailyGoal', language)}</p>
            <p className="text-sm font-medium">
              {stats.todayCount} {t('of', language)} {settings.dailyGoal}
            </p>
          </div>
          <div className={`h-3 rounded-full overflow-hidden ${isDark ? 'bg-emerald-950/50' : 'bg-emerald-100'}`}>
            <div
              className="h-full rounded-full bg-gradient-to-r from-champagne-400 to-champagne-600 transition-all duration-500"
              style={{ width: `${goalProgress}%` }}
            />
          </div>
          <div className="flex items-center justify-between mt-2">
            <p className={`text-xs ${subTextClass}`}>{Math.round(goalProgress)}%</p>
            {goalProgress >= 100 && (
              <div className="flex items-center gap-1 text-champagne-400">
                <StarEmblem size={12} />
                <span className="text-xs font-medium">{t('milestoneReached', language)}</span>
              </div>
            )}
          </div>
        </div>

        {/* Open counter button */}
        <button
          onClick={() => onNavigate('counter')}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-700 to-emerald-900 text-ivory-100 font-bold text-base hover:shadow-lg hover:shadow-emerald-700/20 active:scale-[0.98] transition-all mb-3"
        >
          {t('openCounter', language)}
        </button>

        {/* Navigation tabs */}
        <div className={`flex items-center justify-around rounded-2xl border ${cardClass} p-2 mt-2`}>
          <NavTab icon="home" label={t('dashboard', language)} active={true} onClick={() => onNavigate('dashboard')} isDark={isDark} />
          <NavTab icon="counter" label={t('counter', language)} active={false} onClick={() => onNavigate('counter')} isDark={isDark} />
          <NavTab icon="stats" label={t('statistics', language)} active={false} onClick={() => onNavigate('statistics')} isDark={isDark} />
          <NavTab icon="settings" label={t('settings', language)} active={false} onClick={() => onNavigate('settings')} isDark={isDark} />
        </div>
      </div>
    </div>
  );
}

function StatCard({
  label,
  value,
  suffix,
  subTextClass,
  cardClass,
  accent,
  animate,
  delay,
}: {
  label: string;
  value: number;
  suffix?: string;
  subTextClass: string;
  cardClass: string;
  accent: 'gold' | 'emerald';
  animate: boolean;
  delay: number;
}) {
  return (
    <div
      className={`rounded-2xl border ${cardClass} p-4 ${animate ? 'animate-fade-in-up' : ''}`}
      style={{ animationDelay: `${delay}s` }}
    >
      <p className={`text-xs ${subTextClass} mb-1`}>{label}</p>
      <p className={`text-2xl font-bold ${accent === 'gold' ? 'text-champagne-400' : 'text-emerald-500'}`}>
        {value.toLocaleString()}{suffix}
      </p>
    </div>
  );
}

function NavTab({
  icon,
  label,
  active,
  onClick,
  isDark,
}: {
  icon: string;
  label: string;
  active: boolean;
  onClick: () => void;
  isDark: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-all ${
        active
          ? isDark
            ? 'bg-champagne-400/15 text-champagne-300'
            : 'bg-emerald-100 text-emerald-700'
          : isDark
            ? 'text-ivory-200/40 hover:text-ivory-200/70'
            : 'text-emerald-800/40 hover:text-emerald-800/70'
      }`}
    >
      <NavIcon name={icon} />
      <span className="text-xs">{label}</span>
    </button>
  );
}

function NavIcon({ name }: { name: string }) {
  switch (name) {
    case 'home':
      return (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>
        </svg>
      );
    case 'counter':
      return (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>
        </svg>
      );
    case 'stats':
      return (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>
        </svg>
      );
    case 'settings':
      return (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>
        </svg>
      );
    default:
      return null;
  }
}

function SettingsIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>
    </svg>
  );
}

function getGreetingKey(hour: number): string {
  if (hour < 12) return 'greeting';
  return 'greeting';
}
