import { useState } from 'react';
import { CrescentIcon, IslamicPattern, GeometricDivider } from './IslamicPattern';
import type { Language, AppSettings, Stats, Screen, ThemeMode, OverlayStyle } from '../types';
import { t } from '../i18n';
import { INTERVAL_PRESETS, DEFAULT_FRIDAY_INTERVALS } from '../types';

interface SettingsProps {
  language: Language;
  settings: AppSettings;
  stats: Stats;
  onUpdateSettings: (partial: Partial<AppSettings>) => void;
  onNavigate: (screen: Screen) => void;
  onResetAll: () => void;
  onEraseAllData: () => void;
  effectiveTheme: 'light' | 'dark';
}

type Section = 'reminders' | 'appearance' | 'counting' | 'permissions' | 'privacy' | 'about';

export function SettingsScreen({
  language,
  settings,
  stats,
  onUpdateSettings,
  onNavigate,
  onResetAll,
  onEraseAllData,
  effectiveTheme,
}: SettingsProps) {
  const isRtl = language === 'ar';
  const isDark = effectiveTheme === 'dark';
  const [expandedSection, setExpandedSection] = useState<Section | null>('reminders');
  const [showResetDialog, setShowResetDialog] = useState(false);
  const [showEraseDialog, setShowEraseDialog] = useState(false);
  const [showAnimationPreview, setShowAnimationPreview] = useState(false);

  const bgClass = isDark
    ? 'bg-gradient-to-b from-midnight-900 to-midnight-950'
    : 'bg-gradient-to-b from-emerald-50 to-ivory-100';
  const textClass = isDark ? 'text-ivory-100' : 'text-emerald-950';
  const subTextClass = isDark ? 'text-ivory-200/60' : 'text-emerald-800/60';
  const cardClass = isDark
    ? 'bg-emerald-850/40 border-champagne-400/10'
    : 'bg-white border-emerald-200/40';
  const sectionClass = isDark
    ? 'bg-emerald-950/30 border-champagne-400/10'
    : 'bg-emerald-50/50 border-emerald-200/30';

  const toggleSection = (s: Section) => {
    setExpandedSection(expandedSection === s ? null : s);
  };

  return (
    <div dir={isRtl ? 'rtl' : 'ltr'} className={`min-h-screen ${bgClass} ${textClass} relative overflow-hidden`}>
      <IslamicPattern className={`absolute inset-0 ${isDark ? 'text-champagne-400' : 'text-emerald-700'}`} opacity={isDark ? 0.03 : 0.02} />

      <div className="relative z-10 max-w-lg mx-auto p-5 pt-8 safe-top safe-bottom">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => onNavigate('dashboard')}
            className={`w-11 h-11 rounded-xl ${cardClass} border flex items-center justify-center hover:scale-105 transition-transform`}
            aria-label={t('back', language)}
          >
            <BackIcon />
          </button>
          <h1 className="text-lg font-arabic font-bold">{t('settings', language)}</h1>
          <div className="w-11" />
        </div>

        {/* Section: Reminders */}
        <SectionCard
          title={t('reminders', language)}
          icon="bell"
          expanded={expandedSection === 'reminders'}
          onToggle={() => toggleSection('reminders')}
          cardClass={cardClass}
          subTextClass={subTextClass}
          isDark={isDark}
        >
          <ToggleRow
            label={t('enableReminders', language)}
            value={settings.remindersEnabled}
            onChange={(v) => onUpdateSettings({ remindersEnabled: v })}
            isDark={isDark}
            subTextClass={subTextClass}
          />
          <Divider isDark={isDark} />
          <IntervalPicker
            label={t('standardInterval', language)}
            value={settings.reminderInterval}
            presets={INTERVAL_PRESETS}
            onChange={(v) => onUpdateSettings({ reminderInterval: v })}
            language={language}
            subTextClass={subTextClass}
            isDark={isDark}
          />
          <Divider isDark={isDark} />
          <ToggleRow
            label={t('fridayModeEnable', language)}
            value={settings.fridayModeEnabled}
            onChange={(v) => onUpdateSettings({ fridayModeEnabled: v })}
            isDark={isDark}
            subTextClass={subTextClass}
          />
          {settings.fridayModeEnabled && (
            <>
              <p className={`text-xs ${subTextClass} px-1 py-2 leading-relaxed`}>
                {t('fridayExplanation', language)}
              </p>
              <IntervalPicker
                label={t('fridayInterval', language)}
                value={settings.fridayInterval}
                presets={DEFAULT_FRIDAY_INTERVALS}
                onChange={(v) => onUpdateSettings({ fridayInterval: v })}
                language={language}
                subTextClass={subTextClass}
                isDark={isDark}
              />
              <div className="mt-2">
                <p className={`text-xs ${subTextClass} mb-2`}>{t('fridayCalcMethod', language) || (language === 'ar' ? 'طريقة حساب الغروب' : 'Sunset calculation')}</p>
                <div className="flex gap-2">
                  <CalcMethodBtn
                    label={t('manualSchedule', language)}
                    active={settings.fridayCalcMethod === 'manual'}
                    onClick={() => onUpdateSettings({ fridayCalcMethod: 'manual' })}
                    isDark={isDark}
                  />
                  <CalcMethodBtn
                    label={language === 'ar' ? 'فلكي (تقريبي)' : 'Astronomical (approx.)'}
                    active={settings.fridayCalcMethod === 'astronomical'}
                    onClick={() => onUpdateSettings({ fridayCalcMethod: 'astronomical' })}
                    isDark={isDark}
                  />
                </div>
                {settings.fridayCalcMethod === 'manual' && (
                  <div className="flex gap-3 mt-3">
                    <TimeInput
                      label={t('sunset', language)}
                      value={settings.manualFridayStart}
                      onChange={(v) => onUpdateSettings({ manualFridayStart: v, manualFridayEnd: v })}
                      isDark={isDark}
                      subTextClass={subTextClass}
                    />
                  </div>
                )}
              </div>
            </>
          )}
          <Divider isDark={isDark} />
          <div className="py-2">
            <p className={`text-sm ${subTextClass} mb-2`}>{t('quietHours', language)}</p>
            <div className="flex gap-3">
              <TimeInput
                label={t('from', language)}
                value={settings.quietHoursStart || ''}
                onChange={(v) => onUpdateSettings({ quietHoursStart: v })}
                isDark={isDark}
                subTextClass={subTextClass}
              />
              <TimeInput
                label={t('to', language)}
                value={settings.quietHoursEnd || ''}
                onChange={(v) => onUpdateSettings({ quietHoursEnd: v })}
                isDark={isDark}
                subTextClass={subTextClass}
              />
            </div>
          </div>
          <Divider isDark={isDark} />
          <div className="py-2">
            <p className={`text-sm ${subTextClass} mb-2`}>{t('activeHours', language)}</p>
            <div className="flex gap-3">
              <TimeInput
                label={t('from', language)}
                value={settings.activeHoursStart || ''}
                onChange={(v) => onUpdateSettings({ activeHoursStart: v })}
                isDark={isDark}
                subTextClass={subTextClass}
              />
              <TimeInput
                label={t('to', language)}
                value={settings.activeHoursEnd || ''}
                onChange={(v) => onUpdateSettings({ activeHoursEnd: v })}
                isDark={isDark}
                subTextClass={subTextClass}
              />
            </div>
          </div>
          <Divider isDark={isDark} />
          <ToggleRow
            label={t('animations', language)}
            value={settings.animationsEnabled}
            onChange={(v) => onUpdateSettings({ animationsEnabled: v })}
            isDark={isDark}
            subTextClass={subTextClass}
          />
          <button
            onClick={() => setShowAnimationPreview(true)}
            className={`w-full text-start py-2 text-sm ${subTextClass} hover:text-champagne-400 transition-colors`}
          >
            {t('animationPreview', language)}
          </button>
          <Divider isDark={isDark} />
          <ToggleRow
            label={t('vibration', language)}
            value={settings.vibrationEnabled}
            onChange={(v) => onUpdateSettings({ vibrationEnabled: v })}
            isDark={isDark}
            subTextClass={subTextClass}
          />
          <ToggleRow
            label={t('sound', language)}
            value={settings.soundEnabled}
            onChange={(v) => onUpdateSettings({ soundEnabled: v })}
            isDark={isDark}
            subTextClass={subTextClass}
          />
          <ToggleRow
            label={t('screenOffBehavior', language)}
            value={settings.screenOffOnly}
            onChange={(v) => onUpdateSettings({ screenOffOnly: v })}
            isDark={isDark}
            subTextClass={subTextClass}
          />
        </SectionCard>

        {/* Section: Appearance */}
        <SectionCard
          title={t('appearance', language)}
          icon="palette"
          expanded={expandedSection === 'appearance'}
          onToggle={() => toggleSection('appearance')}
          cardClass={cardClass}
          subTextClass={subTextClass}
          isDark={isDark}
        >
          <div className="py-2">
            <p className={`text-sm ${subTextClass} mb-2`}>{t('theme', language)}</p>
            <div className="flex gap-2">
              {(['light', 'dark', 'system'] as ThemeMode[]).map((mode) => (
                <SegmentBtn
                  key={mode}
                  label={t(mode, language)}
                  active={settings.theme === mode}
                  onClick={() => onUpdateSettings({ theme: mode })}
                  isDark={isDark}
                />
              ))}
            </div>
          </div>
          <Divider isDark={isDark} />
          <div className="py-2">
            <p className={`text-sm ${subTextClass} mb-2`}>{t('overlayStyleLabel', language)}</p>
            <div className="flex gap-2">
              {(['dynamic-island', 'frosted-glass'] as OverlayStyle[]).map((style) => (
                <SegmentBtn
                  key={style}
                  label={t(style === 'dynamic-island' ? 'dynamicIsland' : 'frostedGlass', language)}
                  active={settings.overlayStyle === style}
                  onClick={() => onUpdateSettings({ overlayStyle: style })}
                  isDark={isDark}
                />
              ))}
            </div>
          </div>
          <Divider isDark={isDark} />
          <div className="py-2">
            <p className={`text-sm ${subTextClass} mb-2`}>{t('languageLabel', language)}</p>
            <div className="flex gap-2">
              <SegmentBtn
                label="العربية"
                active={settings.language === 'ar'}
                onClick={() => onUpdateSettings({ language: 'ar' })}
                isDark={isDark}
              />
              <SegmentBtn
                label="English"
                active={settings.language === 'en'}
                onClick={() => onUpdateSettings({ language: 'en' })}
                isDark={isDark}
              />
            </div>
          </div>
        </SectionCard>

        {/* Section: Counting & Goals */}
        <SectionCard
          title={t('countingGoals', language)}
          icon="target"
          expanded={expandedSection === 'counting'}
          onToggle={() => toggleSection('counting')}
          cardClass={cardClass}
          subTextClass={subTextClass}
          isDark={isDark}
        >
          <div className="py-2">
            <div className="flex items-center justify-between mb-2">
              <p className={`text-sm ${subTextClass}`}>{t('dailyGoalLabel', language)}</p>
              <p className="text-sm font-medium text-champagne-400">{settings.dailyGoal}</p>
            </div>
            <input
              type="range"
              min="10"
              max="1000"
              step="10"
              value={settings.dailyGoal}
              onChange={(e) => onUpdateSettings({ dailyGoal: parseInt(e.target.value, 10) })}
              className="w-full"
            />
          </div>
          <Divider isDark={isDark} />
          <div className="py-2">
            <p className={`text-sm ${subTextClass} mb-1`}>{t('lifetimeTotal', language)}</p>
            <p className="text-2xl font-bold text-champagne-400">{stats.lifetimeCount.toLocaleString()}</p>
          </div>
          <button
            onClick={() => onNavigate('statistics')}
            className={`w-full text-start py-2 text-sm ${subTextClass} hover:text-champagne-400 transition-colors`}
          >
            {t('achievementHistory', language)}
          </button>
          <button
            onClick={() => onNavigate('statistics')}
            className={`w-full text-start py-2 text-sm ${subTextClass} hover:text-champagne-400 transition-colors`}
          >
            {t('dailyHistory', language)}
          </button>
          <Divider isDark={isDark} />
          <button
            onClick={() => setShowResetDialog(true)}
            className="w-full text-start py-2 text-sm text-red-400/70 hover:text-red-400 transition-colors"
          >
            {t('resetStatistics', language)}
          </button>
        </SectionCard>

        {/* Section: Permissions */}
        <SectionCard
          title={t('permissionsReliability', language)}
          icon="shield"
          expanded={expandedSection === 'permissions'}
          onToggle={() => toggleSection('permissions')}
          cardClass={cardClass}
          subTextClass={subTextClass}
          isDark={isDark}
        >
          <div className={`rounded-xl ${sectionClass} border p-3 mb-2`}>
            <p className={`text-sm ${subTextClass} mb-1`}>{t('overlayPermission', language)}</p>
            <p className="text-xs text-amber-400/60">{t('notAvailable', language)}</p>
          </div>
          <div className={`rounded-xl ${sectionClass} border p-3 mb-2`}>
            <p className={`text-sm ${subTextClass} mb-1`}>{t('notificationPermission', language)}</p>
            <p className="text-xs text-amber-400/60">{t('notAvailable', language)}</p>
          </div>
          <div className={`rounded-xl ${sectionClass} border p-3 mb-2`}>
            <p className={`text-sm ${subTextClass} mb-1`}>{t('batteryOptimization', language)}</p>
            <p className={`text-xs ${subTextClass} leading-relaxed mt-1`}>{t('backgroundExplain', language)}</p>
          </div>
        </SectionCard>

        {/* Section: Privacy */}
        <SectionCard
          title={t('privacy', language)}
          icon="lock"
          expanded={expandedSection === 'privacy'}
          onToggle={() => toggleSection('privacy')}
          cardClass={cardClass}
          subTextClass={subTextClass}
          isDark={isDark}
        >
          <p className={`text-sm ${subTextClass} leading-relaxed py-2`}>
            {t('privacyExplain', language)}
          </p>
          <Divider isDark={isDark} />
          <button
            onClick={() => setShowEraseDialog(true)}
            className="w-full text-start py-2 text-sm text-red-400/70 hover:text-red-400 transition-colors"
          >
            {t('eraseAllData', language)}
          </button>
        </SectionCard>

        {/* Section: About */}
        <SectionCard
          title={t('about', language)}
          icon="info"
          expanded={expandedSection === 'about'}
          onToggle={() => toggleSection('about')}
          cardClass={cardClass}
          subTextClass={subTextClass}
          isDark={isDark}
        >
          <div className="flex flex-col items-center py-4 gap-3">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-700 to-emerald-900 flex items-center justify-center border border-champagne-400/20">
              <CrescentIcon size={30} />
            </div>
            <h2 className="text-2xl font-arabic font-bold">ذِكر ﷺ</h2>
            <GeometricDivider className="text-champagne-400/40" />
            <p className={`text-sm ${subTextClass} text-center leading-relaxed px-4`}>
              {t('aboutDesc', language)}
            </p>
            <div className="flex items-center gap-4 mt-2">
              <div className="text-center">
                <p className={`text-xs ${subTextClass}`}>{t('appVersion', language)}</p>
                <p className="text-sm font-medium">1.0.0</p>
              </div>
            </div>
            <p className="text-champagne-400/50 text-xs font-arabic mt-2">
              {t('developerCredit', language)}
            </p>
          </div>
        </SectionCard>

        {/* Nav tabs */}
        <div className={`flex items-center justify-around rounded-2xl border ${cardClass} p-2 mt-4`}>
          <NavTab icon="home" label={t('dashboard', language)} active={false} onClick={() => onNavigate('dashboard')} isDark={isDark} />
          <NavTab icon="counter" label={t('counter', language)} active={false} onClick={() => onNavigate('counter')} isDark={isDark} />
          <NavTab icon="stats" label={t('statistics', language)} active={false} onClick={() => onNavigate('statistics')} isDark={isDark} />
          <NavTab icon="settings" label={t('settings', language)} active={true} onClick={() => onNavigate('settings')} isDark={isDark} />
        </div>
      </div>

      {/* Animation preview */}
      {showAnimationPreview && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center" onClick={() => setShowAnimationPreview(false)}>
          <div className="flex flex-col items-center gap-4" onClick={(e) => e.stopPropagation()}>
            <div className={`${settings.animationsEnabled ? 'animate-capsule-expand' : ''} bg-black/90 rounded-full px-8 py-4 border border-champagne-400/20 shadow-2xl`}>
              <div className="flex items-center gap-3">
                <CrescentIcon size={20} />
                <span className="text-white text-base font-arabic">{t('capsulePreview', language)}</span>
              </div>
            </div>
            <button
              onClick={() => setShowAnimationPreview(false)}
              className="px-8 py-3 rounded-2xl bg-champagne-400/20 text-champagne-300 text-sm font-medium"
            >
              {t('continue', language)}
            </button>
          </div>
        </div>
      )}

      {/* Reset dialog */}
      {showResetDialog && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-6" onClick={() => setShowResetDialog(false)}>
          <div className={`max-w-sm w-full rounded-3xl border ${cardClass} p-6 text-center`} onClick={(e) => e.stopPropagation()}>
            <p className="text-base mb-6 leading-relaxed">{t('confirmReset', language)}</p>
            <div className="flex gap-3">
              <button onClick={() => setShowResetDialog(false)} className={`flex-1 py-3.5 rounded-2xl ${cardClass} border text-sm font-medium`}>{t('cancel', language)}</button>
              <button onClick={() => { onResetAll(); setShowResetDialog(false); }} className="flex-1 py-3.5 rounded-2xl bg-red-500/80 text-white text-sm font-bold hover:bg-red-500 transition-colors">{t('confirm', language)}</button>
            </div>
          </div>
        </div>
      )}

      {/* Erase dialog */}
      {showEraseDialog && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-6" onClick={() => setShowEraseDialog(false)}>
          <div className={`max-w-sm w-full rounded-3xl border ${cardClass} p-6 text-center`} onClick={(e) => e.stopPropagation()}>
            <p className="text-base mb-6 leading-relaxed">{t('confirmErase', language)}</p>
            <div className="flex gap-3">
              <button onClick={() => setShowEraseDialog(false)} className={`flex-1 py-3.5 rounded-2xl ${cardClass} border text-sm font-medium`}>{t('cancel', language)}</button>
              <button onClick={() => { onEraseAllData(); setShowEraseDialog(false); }} className="flex-1 py-3.5 rounded-2xl bg-red-500/80 text-white text-sm font-bold hover:bg-red-500 transition-colors">{t('confirm', language)}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// --- Reusable components ---

function SectionCard({
  title,
  icon,
  expanded,
  onToggle,
  children,
  cardClass,
  subTextClass,
  isDark,
}: {
  title: string;
  icon: string;
  expanded: boolean;
  onToggle: () => void;
  children: React.ReactNode;
  cardClass: string;
  subTextClass: string;
  isDark: boolean;
}) {
  return (
    <div className={`rounded-2xl border ${cardClass} mb-3 overflow-hidden`}>
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between p-4 hover:bg-champagne-400/5 transition-colors"
      >
        <div className="flex items-center gap-3">
          <SectionIcon name={icon} isDark={isDark} />
          <span className="text-sm font-bold">{title}</span>
        </div>
        <svg
          width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
          className={`transition-transform ${expanded ? 'rotate-180' : ''} ${subTextClass}`}
        >
          <polyline points="6 9 12 15 18 9" />
        </svg>
      </button>
      {expanded && (
        <div className="px-4 pb-4 pt-1">
          {children}
        </div>
      )}
    </div>
  );
}

function ToggleRow({
  label,
  value,
  onChange,
  isDark,
  subTextClass,
}: {
  label: string;
  value: boolean;
  onChange: (v: boolean) => void;
  isDark: boolean;
  subTextClass: string;
}) {
  return (
    <div className="flex items-center justify-between py-2">
      <span className="text-sm">{label}</span>
      <button
        onClick={() => onChange(!value)}
        className={`relative w-12 h-7 rounded-full transition-colors ${value ? 'bg-emerald-600' : isDark ? 'bg-emerald-950/60' : 'bg-emerald-200'}`}
        role="switch"
        aria-checked={value}
      >
        <div
          className={`absolute top-1 w-5 h-5 rounded-full bg-white transition-transform ${value ? 'left-1 translate-x-5' : 'left-1'}`}
        />
      </button>
    </div>
  );
}

function IntervalPicker({
  label,
  value,
  presets,
  onChange,
  language,
  subTextClass,
  isDark,
}: {
  label: string;
  value: number;
  presets: number[];
  onChange: (v: number) => void;
  language: Language;
  subTextClass: string;
  isDark: boolean;
}) {
  return (
    <div className="py-2">
      <p className={`text-sm ${subTextClass} mb-2`}>{label}</p>
      <div className="flex flex-wrap gap-2">
        {presets.map((preset) => (
          <button
            key={preset}
            onClick={() => onChange(preset)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
              value === preset
                ? 'bg-gradient-to-r from-emerald-600 to-emerald-800 text-ivory-100'
                : isDark
                  ? 'bg-emerald-950/40 text-ivory-200/60 hover:bg-emerald-950/60'
                  : 'bg-emerald-50 text-emerald-800/60 hover:bg-emerald-100'
            }`}
          >
            {preset} {t('minutes', language)}
          </button>
        ))}
      </div>
    </div>
  );
}

function TimeInput({
  label,
  value,
  onChange,
  isDark,
  subTextClass,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  isDark: boolean;
  subTextClass: string;
}) {
  return (
    <div className="flex-1">
      <label className={`text-xs ${subTextClass} block mb-1`}>{label}</label>
      <input
        type="time"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={`w-full py-2 px-3 rounded-lg border border-champagne-400/15 text-sm ${isDark ? 'bg-emerald-950/50 text-ivory-100' : 'bg-white text-emerald-950'} outline-none focus:border-champagne-400/40`}
      />
    </div>
  );
}

function SegmentBtn({
  label,
  active,
  onClick,
  isDark,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
  isDark: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-all ${
        active
          ? 'bg-gradient-to-r from-emerald-600 to-emerald-800 text-ivory-100'
          : isDark
            ? 'bg-emerald-950/40 text-ivory-200/60 hover:bg-emerald-950/60'
            : 'bg-emerald-50 text-emerald-800/60 hover:bg-emerald-100'
      }`}
    >
      {label}
    </button>
  );
}

function CalcMethodBtn({
  label,
  active,
  onClick,
  isDark,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
  isDark: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex-1 py-2 rounded-lg text-xs font-medium transition-all ${
        active
          ? 'bg-champagne-400/20 text-champagne-300 border border-champagne-400/30'
          : isDark
            ? 'bg-emerald-950/40 text-ivory-200/50 border border-champagne-400/5'
            : 'bg-emerald-50 text-emerald-800/50 border border-emerald-200/30'
      }`}
    >
      {label}
    </button>
  );
}

function Divider({ isDark }: { isDark: boolean }) {
  return <div className={`h-px ${isDark ? 'bg-champagne-400/10' : 'bg-emerald-200/40'} my-1`} />;
}

function SectionIcon({ name, isDark }: { name: string; isDark: boolean }) {
  const color = isDark ? 'text-champagne-400/60' : 'text-emerald-600/60';
  const icons: Record<string, React.ReactNode> = {
    bell: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={color}><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>,
    palette: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={color}><circle cx="13.5" cy="6.5" r=".5"/><circle cx="17.5" cy="10.5" r=".5"/><circle cx="8.5" cy="7.5" r=".5"/><circle cx="6.5" cy="12.5" r=".5"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"/></svg>,
    target: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={color}><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>,
    shield: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={color}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>,
    lock: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={color}><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>,
    info: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={color}><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>,
  };
  return <>{icons[name] || null}</>;
}

function BackIcon() {
  return <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>;
}

function NavTab({ icon, label, active, onClick, isDark }: { icon: string; label: string; active: boolean; onClick: () => void; isDark: boolean }) {
  return (
    <button onClick={onClick} className={`flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-all ${active ? (isDark ? 'bg-champagne-400/15 text-champagne-300' : 'bg-emerald-100 text-emerald-700') : (isDark ? 'text-ivory-200/40 hover:text-ivory-200/70' : 'text-emerald-800/40 hover:text-emerald-800/70')}`}>
      <NavIcon name={icon} />
      <span className="text-xs">{label}</span>
    </button>
  );
}

function NavIcon({ name }: { name: string }) {
  switch (name) {
    case 'home': return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>;
    case 'counter': return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>;
    case 'stats': return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>;
    case 'settings': return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>;
    default: return null;
  }
}
