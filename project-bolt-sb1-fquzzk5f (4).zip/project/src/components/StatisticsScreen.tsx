import { useState } from 'react';
import { CrescentIcon, IslamicPattern, StarEmblem } from './IslamicPattern';
import type { Language, AppSettings, Stats, Screen } from '../types';
import { t } from '../i18n';
import { MILESTONES } from '../types';

interface StatsScreenProps {
  language: Language;
  settings: AppSettings;
  stats: Stats;
  onNavigate: (screen: Screen) => void;
  onResetAll: () => void;
  effectiveTheme: 'light' | 'dark';
}

export function StatisticsScreen({
  language,
  settings,
  stats,
  onNavigate,
  onResetAll,
  effectiveTheme,
}: StatsScreenProps) {
  const isRtl = language === 'ar';
  const isDark = effectiveTheme === 'dark';
  const [showResetDialog, setShowResetDialog] = useState(false);

  const bgClass = isDark
    ? 'bg-gradient-to-b from-midnight-900 to-midnight-950'
    : 'bg-gradient-to-b from-emerald-50 to-ivory-100';
  const textClass = isDark ? 'text-ivory-100' : 'text-emerald-950';
  const subTextClass = isDark ? 'text-ivory-200/60' : 'text-emerald-800/60';
  const cardClass = isDark
    ? 'bg-emerald-850/40 border-champagne-400/10'
    : 'bg-white border-emerald-200/40';

  // Last 30 days
  const sortedHistory = [...stats.dailyHistory].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 30);
  const maxCount = Math.max(...sortedHistory.map(d => d.count), 1);

  return (
    <div dir={isRtl ? 'rtl' : 'ltr'} className={`min-h-screen ${bgClass} ${textClass} relative overflow-hidden`}>
      <IslamicPattern className={`absolute inset-0 ${isDark ? 'text-champagne-400' : 'text-emerald-700'}`} opacity={isDark ? 0.03 : 0.02} />

      <div className="relative z-10 max-w-lg mx-auto p-5 pt-8 safe-top safe-bottom">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => onNavigate('dashboard')}
            className={`w-11 h-11 rounded-xl ${cardClass} border flex items-center justify-center hover:scale-105 transition-transform`}
            aria-label={t('back', language)}
          >
            <BackIcon />
          </button>
          <h1 className="text-lg font-arabic font-bold">{t('statistics', language)}</h1>
          <div className="w-11" />
        </div>

        {/* Summary cards */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className={`rounded-2xl border ${cardClass} p-4`}>
            <p className={`text-xs ${subTextClass} mb-1`}>{t('lifetimeCount', language)}</p>
            <p className="text-2xl font-bold text-champagne-400">{stats.lifetimeCount.toLocaleString()}</p>
          </div>
          <div className={`rounded-2xl border ${cardClass} p-4`}>
            <p className={`text-xs ${subTextClass} mb-1`}>{t('personalBest', language)}</p>
            <p className="text-2xl font-bold text-emerald-500">{stats.personalBestDay}</p>
          </div>
          <div className={`rounded-2xl border ${cardClass} p-4`}>
            <p className={`text-xs ${subTextClass} mb-1`}>{t('currentStreak', language)}</p>
            <p className="text-2xl font-bold text-emerald-500">
              {stats.currentStreak} <span className="text-sm">{t('days', language)}</span>
            </p>
          </div>
          <div className={`rounded-2xl border ${cardClass} p-4`}>
            <p className={`text-xs ${subTextClass} mb-1`}>{t('todayCount', language)}</p>
            <p className="text-2xl font-bold text-champagne-400">{stats.todayCount}</p>
          </div>
        </div>

        {/* Streak info */}
        <div className={`rounded-2xl border ${cardClass} p-4 mb-4`}>
          <p className={`text-xs ${subTextClass} leading-relaxed`}>{t('streakInfo', language)}</p>
        </div>

        {/* Daily history chart */}
        <div className={`rounded-2xl border ${cardClass} p-4 mb-4`}>
          <h2 className="text-sm font-bold mb-4">{t('dailyHistory', language)}</h2>
          {sortedHistory.length === 0 ? (
            <p className={`text-sm ${subTextClass} text-center py-8`}>{t('noHistory', language)}</p>
          ) : (
            <div className="space-y-2">
              {sortedHistory.map((day) => {
                const barWidth = (day.count / maxCount) * 100;
                const dateObj = new Date(day.date + 'T00:00:00');
                const dateLabel = dateObj.toLocaleDateString(isRtl ? 'ar' : 'en', { month: 'short', day: 'numeric' });
                return (
                  <div key={day.date} className="flex items-center gap-3">
                    <span className={`text-xs ${subTextClass} w-16 flex-shrink-0`}>{dateLabel}</span>
                    <div className={`flex-1 h-7 rounded-lg overflow-hidden ${isDark ? 'bg-emerald-950/50' : 'bg-emerald-100'}`}>
                      <div
                        className="h-full rounded-lg bg-gradient-to-r from-emerald-500 to-emerald-700 flex items-center justify-end px-2 transition-all duration-500"
                        style={{ width: `${Math.max(barWidth, 8)}%` }}
                      >
                        <span className="text-xs text-white font-medium">{day.count}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Achievements / Milestones */}
        <div className={`rounded-2xl border ${cardClass} p-4 mb-4`}>
          <h2 className="text-sm font-bold mb-4">{t('achievements', language)}</h2>
          <div className="grid grid-cols-3 gap-3">
            {MILESTONES.map((m) => {
              const unlocked = stats.lifetimeCount >= m.count;
              return (
                <div
                  key={m.count}
                  className={`rounded-xl p-3 text-center border ${
                    unlocked
                      ? 'bg-gradient-to-br from-champagne-400/15 to-champagne-600/10 border-champagne-400/30'
                      : isDark ? 'bg-emerald-950/30 border-champagne-400/5' : 'bg-emerald-50 border-emerald-200/30'
                  }`}
                >
                  <div className="flex justify-center mb-2">
                    {unlocked ? (
                      <StarEmblem size={20} className="text-champagne-400" />
                    ) : (
                      <div className={`w-5 h-5 rounded-full border-2 ${isDark ? 'border-ivory-200/20' : 'border-emerald-300'}`} />
                    )}
                  </div>
                  <p className={`text-sm font-bold ${unlocked ? 'text-champagne-400' : subTextClass}`}>
                    {m.count.toLocaleString()}
                  </p>
                  <p className={`text-xs ${unlocked ? 'text-champagne-400/60' : subTextClass}`}>
                    {unlocked ? t('unlocked', language) : t('locked', language)}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Reset all */}
        <button
          onClick={() => setShowResetDialog(true)}
          className={`w-full py-3.5 rounded-2xl ${cardClass} border text-sm font-medium text-red-400/70 hover:scale-[1.01] transition-transform mb-4`}
        >
          {t('resetStatistics', language)}
        </button>

        {/* Nav tabs */}
        <div className={`flex items-center justify-around rounded-2xl border ${cardClass} p-2`}>
          <NavTab icon="home" label={t('dashboard', language)} active={false} onClick={() => onNavigate('dashboard')} isDark={isDark} />
          <NavTab icon="counter" label={t('counter', language)} active={false} onClick={() => onNavigate('counter')} isDark={isDark} />
          <NavTab icon="stats" label={t('statistics', language)} active={true} onClick={() => onNavigate('statistics')} isDark={isDark} />
          <NavTab icon="settings" label={t('settings', language)} active={false} onClick={() => onNavigate('settings')} isDark={isDark} />
        </div>
      </div>

      {/* Reset dialog */}
      {showResetDialog && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-6" onClick={() => setShowResetDialog(false)}>
          <div
            className={`max-w-sm w-full rounded-3xl border ${cardClass} p-6 text-center`}
            onClick={(e) => e.stopPropagation()}
          >
            <p className="text-base mb-6 leading-relaxed">{t('confirmReset', language)}</p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowResetDialog(false)}
                className={`flex-1 py-3.5 rounded-2xl ${cardClass} border text-sm font-medium`}
              >
                {t('cancel', language)}
              </button>
              <button
                onClick={() => { onResetAll(); setShowResetDialog(false); }}
                className="flex-1 py-3.5 rounded-2xl bg-red-500/80 text-white text-sm font-bold hover:bg-red-500 transition-colors"
              >
                {t('confirm', language)}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}


function BackIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>
    </svg>
  );
}

function NavTab({
  icon,
  label,
  active,
  onClick,
  isDark,
}: {
  icon: string;
  label: string;
  active: boolean;
  onClick: () => void;
  isDark: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-all ${
        active
          ? isDark
            ? 'bg-champagne-400/15 text-champagne-300'
            : 'bg-emerald-100 text-emerald-700'
          : isDark
            ? 'text-ivory-200/40 hover:text-ivory-200/70'
            : 'text-emerald-800/40 hover:text-emerald-800/70'
      }`}
    >
      <NavIcon name={icon} />
      <span className="text-xs">{label}</span>
    </button>
  );
}

function NavIcon({ name }: { name: string }) {
  switch (name) {
    case 'home':
      return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>;
    case 'counter':
      return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>;
    case 'stats':
      return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>;
    case 'settings':
      return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>;
    default:
      return null;
  }
}
