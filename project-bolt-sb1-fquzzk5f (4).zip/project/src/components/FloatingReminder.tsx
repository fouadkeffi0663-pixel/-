import { useState, useEffect, useRef } from 'react';
import { CrescentIcon } from './IslamicPattern';
import type { Language, AppSettings } from '../types';
import { t } from '../i18n';

interface FloatingReminderProps {
  language: Language;
  settings: AppSettings;
  onCountTap: () => void;
  onDismiss: () => void;
}

type Phase = 'entering' | 'expanding' | 'displaying' | 'contracting' | 'exiting' | 'idle';

export function FloatingReminder({
  language,
  settings,
  onCountTap,
  onDismiss,
}: FloatingReminderProps) {
  const isRtl = language === 'ar';
  const [phase, setPhase] = useState<Phase>('idle');
  const [visible, setVisible] = useState(false);
  const [textVisible, setTextVisible] = useState(false);
  const animTimers = useRef<ReturnType<typeof setTimeout>[]>([]);
  const isFrosted = settings.overlayStyle === 'frosted-glass';

  useEffect(() => {
    return () => {
      animTimers.current.forEach(clearTimeout);
    };
  }, []);

  const clearTimers = () => {
    animTimers.current.forEach(clearTimeout);
    animTimers.current = [];
  };

  const runSequence = () => {
    if (!settings.animationsEnabled) {
      setVisible(true);
      setTextVisible(true);
      setPhase('displaying');
      const t1 = setTimeout(() => {
        setVisible(false);
        setTextVisible(false);
        setPhase('idle');
        onDismiss();
      }, 2000);
      animTimers.current.push(t1);
      return;
    }

    clearTimers();
    setPhase('entering');
    setVisible(true);

    const t1 = setTimeout(() => {
      setPhase('expanding');
    }, 300);

    const t2 = setTimeout(() => {
      setPhase('displaying');
      setTextVisible(true);
    }, 750);

    const t3 = setTimeout(() => {
      setTextVisible(false);
      setPhase('contracting');
    }, 2750);

    const t4 = setTimeout(() => {
      setPhase('exiting');
    }, 3150);

    const t5 = setTimeout(() => {
      setVisible(false);
      setPhase('idle');
      onDismiss();
    }, 3450);

    animTimers.current.push(t1, t2, t3, t4, t5);
  };

  // Expose trigger method via a custom event
  useEffect(() => {
    const handler = () => runSequence();
    window.addEventListener('dhikr-show-reminder', handler);
    return () => window.removeEventListener('dhikr-show-reminder', handler);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [settings.animationsEnabled, settings.overlayStyle]);

  if (!visible) return null;

  const capsuleWidth = phase === 'expanding' || phase === 'displaying' ? 280 : 90;
  const capsuleHeight = phase === 'expanding' || phase === 'displaying' ? 64 : 28;
  const opacity = phase === 'entering' ? 0.7 : phase === 'exiting' ? 0 : 1;
  const translateY = phase === 'entering' ? -20 : phase === 'exiting' ? -20 : 0;

  const bgClass = isFrosted
    ? 'bg-emerald-950/70 backdrop-blur-xl border-champagne-400/15'
    : 'bg-black/90 border-champagne-400/10';

  return (
    <div
      dir={isRtl ? 'rtl' : 'ltr'}
      className="fixed top-4 left-1/2 -translate-x-1/2 z-[9999] pointer-events-auto"
      style={{ zIndex: 99999 }}
    >
      <div
        className={`rounded-full ${bgClass} border shadow-2xl flex items-center justify-center overflow-hidden transition-all duration-300 ease-out`}
        style={{
          width: `${capsuleWidth}px`,
          height: `${capsuleHeight}px`,
          opacity,
          transform: `translateY(${translateY}px)`,
          transitionProperty: 'width, height, opacity, transform',
        }}
        onClick={() => {
          if (settings.overlayTapCounts && phase === 'displaying') {
            onCountTap();
          }
        }}
      >
        {textVisible ? (
          <div className="flex items-center gap-2 px-4 animate-fade-in">
            <CrescentIcon size={16} />
            <span className="text-white text-sm font-arabic whitespace-nowrap">
              {t('capsulePreview', language)}
            </span>
          </div>
        ) : (
          <div className="flex items-center gap-1.5">
            <CrescentIcon size={14} />
          </div>
        )}
      </div>
      {phase === 'displaying' && (
        <button
          onClick={() => {
            clearTimers();
            setPhase('exiting');
            const t = setTimeout(() => {
              setVisible(false);
              setPhase('idle');
              onDismiss();
            }, 300);
            animTimers.current.push(t);
          }}
          className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-emerald-900/80 text-ivory-200/50 text-xs flex items-center justify-center hover:text-ivory-200/80"
          aria-label={t('skip', language)}
        >
          ×
        </button>
      )}
    </div>
  );
}
