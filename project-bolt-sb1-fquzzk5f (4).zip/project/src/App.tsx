import { useState, useEffect, useRef, useCallback } from 'react';
import { WelcomeScreen } from './components/WelcomeScreen';
import { Dashboard } from './components/Dashboard';
import { CounterScreen } from './components/CounterScreen';
import { StatisticsScreen } from './components/StatisticsScreen';
import { SettingsScreen } from './components/SettingsScreen';
import { FloatingReminder } from './components/FloatingReminder';
import { useAppData, getTodayDate } from './useAppData';
import { getEffectiveTheme, getCurrentInterval, shouldShowReminder, isFridayPeriod } from './lib/scheduling';
import type { Screen } from './types';

const ONBOARDED_KEY = 'dhikr_onboarded_v1';

function App() {
  const {
    settings,
    stats,
    updateSettings,
    incrementCount,
    resetTodayCount,
    resetAllStats,
    markMilestoneShown,
    correctCount,
  } = useAppData();

  const [screen, setScreen] = useState<Screen>('welcome');
  const [effectiveTheme, setEffectiveTheme] = useState<'light' | 'dark'>('dark');
  const [hasOnboarded, setHasOnboarded] = useState<boolean>(() => {
    return localStorage.getItem(ONBOARDED_KEY) === 'true';
  });
  const reminderTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const lastReminderTimeRef = useRef<number>(0);

  // Set initial screen
  useEffect(() => {
    if (hasOnboarded) {
      setScreen('dashboard');
    }
  }, [hasOnboarded]);

  // Update effective theme
  useEffect(() => {
    const update = () => setEffectiveTheme(getEffectiveTheme(settings.theme));
    update();
    if (settings.theme === 'system') {
      const mq = window.matchMedia('(prefers-color-scheme: dark)');
      mq.addEventListener('change', update);
      return () => mq.removeEventListener('change', update);
    }
  }, [settings.theme]);

  // Apply dark class and RTL
  useEffect(() => {
    const root = document.documentElement;
    if (effectiveTheme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    root.setAttribute('dir', settings.language === 'ar' ? 'rtl' : 'ltr');
    root.setAttribute('lang', settings.language);
  }, [effectiveTheme, settings.language]);

  // Reminder scheduling
  useEffect(() => {
    if (!settings.remindersEnabled) {
      if (reminderTimerRef.current) {
        clearInterval(reminderTimerRef.current);
        reminderTimerRef.current = null;
      }
      return;
    }

    const checkAndShow = () => {
      const now = new Date();
      const canShow = shouldShowReminder(settings, now);
      if (!canShow) return;

      const currentInterval = getCurrentInterval(settings);
      const intervalMs = currentInterval * 60 * 1000;
      const elapsed = Date.now() - lastReminderTimeRef.current;

      if (elapsed >= intervalMs) {
        lastReminderTimeRef.current = Date.now();
        window.dispatchEvent(new CustomEvent('dhikr-show-reminder'));
      }
    };

    // Check every 15 seconds for more responsive timing
    reminderTimerRef.current = setInterval(checkAndShow, 15000);

    return () => {
      if (reminderTimerRef.current) {
        clearInterval(reminderTimerRef.current);
        reminderTimerRef.current = null;
      }
    };
  }, [settings]);

  const handleStart = useCallback(() => {
    localStorage.setItem(ONBOARDED_KEY, 'true');
    setHasOnboarded(true);
    setScreen('dashboard');
  }, []);

  const handleToggleReminders = useCallback(() => {
    if (!settings.remindersEnabled) {
      updateSettings({ remindersEnabled: true });
      lastReminderTimeRef.current = Date.now();
    } else {
      // Check if temp paused -> resume, otherwise pause
      if (settings.tempPauseUntil && Date.now() < settings.tempPauseUntil) {
        updateSettings({ tempPauseUntil: null });
      } else {
        // Toggle off
        updateSettings({ remindersEnabled: false });
      }
    }
  }, [settings.remindersEnabled, settings.tempPauseUntil, updateSettings]);

  const handleEraseAllData = useCallback(() => {
    resetAllStats();
    localStorage.removeItem(ONBOARDED_KEY);
    localStorage.removeItem('dhikr_settings_v1');
    localStorage.removeItem('dhikr_stats_v1');
    setHasOnboarded(false);
    setScreen('welcome');
    window.location.reload();
  }, [resetAllStats]);

  const isRtl = settings.language === 'ar';

  // Welcome screen
  if (screen === 'welcome' || !hasOnboarded) {
    return (
      <WelcomeScreen
        language={settings.language}
        onLanguageChange={(lang) => updateSettings({ language: lang })}
        onStart={handleStart}
        animationsEnabled={settings.animationsEnabled}
      />
    );
  }

  return (
    <div className="theme-transition">
      {screen === 'dashboard' && (
        <Dashboard
          language={settings.language}
          settings={settings}
          stats={stats}
          onToggleReminders={handleToggleReminders}
          onNavigate={setScreen}
          effectiveTheme={effectiveTheme}
        />
      )}
      {screen === 'counter' && (
        <CounterScreen
          language={settings.language}
          settings={settings}
          stats={stats}
          onIncrement={incrementCount}
          onResetToday={resetTodayCount}
          onCorrectCount={correctCount}
          onNavigate={setScreen}
          onMarkMilestone={markMilestoneShown}
          effectiveTheme={effectiveTheme}
        />
      )}
      {screen === 'statistics' && (
        <StatisticsScreen
          language={settings.language}
          settings={settings}
          stats={stats}
          onNavigate={setScreen}
          onResetAll={resetAllStats}
          effectiveTheme={effectiveTheme}
        />
      )}
      {screen === 'settings' && (
        <SettingsScreen
          language={settings.language}
          settings={settings}
          stats={stats}
          onUpdateSettings={updateSettings}
          onNavigate={setScreen}
          onResetAll={resetAllStats}
          onEraseAllData={handleEraseAllData}
          effectiveTheme={effectiveTheme}
        />
      )}

      {/* Floating reminder overlay */}
      <FloatingReminder
        language={settings.language}
        settings={settings}
        onCountTap={() => {
          if (settings.overlayTapCounts) {
            incrementCount();
          }
        }}
        onDismiss={() => {}}
      />
    </div>
  );
}

export default App;
