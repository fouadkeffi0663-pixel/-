export function getEffectiveTheme(theme: 'light' | 'dark' | 'system'): 'light' | 'dark' {
  if (theme === 'system') {
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }
  return theme;
}

export function isFridayPeriod(
  method: 'manual' | 'astronomical',
  manualStart: string,
  manualEnd: string,
  date = new Date()
): boolean {
  const day = date.getDay(); // 0=Sun, 4=Thu, 5=Fri, 6=Sat

  if (method === 'manual') {
    const [startH, startM] = manualStart.split(':').map(Number);
    const [endH, endM] = manualEnd.split(':').map(Number);
    const startMinutes = startH * 60 + startM;
    const endMinutes = endH * 60 + endM;
    const nowMinutes = date.getHours() * 60 + date.getMinutes();

    // Thursday after sunset (start) through Friday sunset (end)
    if (day === 4 && nowMinutes >= startMinutes) return true;
    if (day === 5 && nowMinutes < endMinutes) return true;
    // If end is next day (sunset Fri) and we're still in Friday before sunset
    if (day === 5 && endMinutes <= startMinutes && nowMinutes >= startMinutes) return false;
    return false;
  }

  // Astronomical approximation — sunset ~18:30 local as fallback
  // In a real native app this would use a proper prayer time library
  const sunsetHour = 18;
  const sunsetMinute = 30;
  const sunsetMinutes = sunsetHour * 60 + sunsetMinute;
  const nowMinutes = date.getHours() * 60 + date.getMinutes();

  if (day === 4 && nowMinutes >= sunsetMinutes) return true;
  if (day === 5 && nowMinutes < sunsetMinutes) return true;
  return false;
}

export function isInQuietHours(
  start: string | null,
  end: string | null,
  date = new Date()
): boolean {
  if (!start || !end) return false;
  const [sH, sM] = start.split(':').map(Number);
  const [eH, eM] = end.split(':').map(Number);
  const startMin = sH * 60 + sM;
  const endMin = eH * 60 + eM;
  const nowMin = date.getHours() * 60 + date.getMinutes();

  if (startMin <= endMin) {
    return nowMin >= startMin && nowMin < endMin;
  }
  // wraps midnight
  return nowMin >= startMin || nowMin < endMin;
}

export function isInActiveHours(
  start: string | null,
  end: string | null,
  date = new Date()
): boolean {
  if (!start || !end) return true; // no restriction
  const [sH, sM] = start.split(':').map(Number);
  const [eH, eM] = end.split(':').map(Number);
  const startMin = sH * 60 + sM;
  const endMin = eH * 60 + eM;
  const nowMin = date.getHours() * 60 + date.getMinutes();

  if (startMin <= endMin) {
    return nowMin >= startMin && nowMin < endMin;
  }
  return nowMin >= startMin || nowMin < endMin;
}

export function isTempPaused(tempPauseUntil: number | null): boolean {
  if (!tempPauseUntil) return false;
  return Date.now() < tempPauseUntil;
}

export function shouldShowReminder(
  settings: {
    remindersEnabled: boolean;
    quietHoursStart: string | null;
    quietHoursEnd: string | null;
    activeHoursStart: string | null;
    activeHoursEnd: string | null;
    tempPauseUntil: number | null;
    fridayModeEnabled: boolean;
    fridayCalcMethod: 'manual' | 'astronomical';
    manualFridayStart: string;
    manualFridayEnd: string;
    reminderInterval: number;
    fridayInterval: number;
  },
  date = new Date()
): boolean {
  if (!settings.remindersEnabled) return false;
  if (isTempPaused(settings.tempPauseUntil)) return false;
  if (isInQuietHours(settings.quietHoursStart, settings.quietHoursEnd, date)) return false;
  if (!isInActiveHours(settings.activeHoursStart, settings.activeHoursEnd, date)) return false;
  return true;
}

export function getCurrentInterval(settings: {
  fridayModeEnabled: boolean;
  fridayInterval: number;
  reminderInterval: number;
  fridayCalcMethod: 'manual' | 'astronomical';
  manualFridayStart: string;
  manualFridayEnd: string;
}): number {
  if (settings.fridayModeEnabled && isFridayPeriod(
    settings.fridayCalcMethod,
    settings.manualFridayStart,
    settings.manualFridayEnd
  )) {
    return settings.fridayInterval;
  }
  return settings.reminderInterval;
}

export function calculateStreak(history: { date: string; count: number }[]): number {
  if (history.length === 0) return 0;
  const sorted = [...history].filter(d => d.count > 0).sort((a, b) => a.date.localeCompare(b.date));
  if (sorted.length === 0) return 0;

  const today = new Date();
  const todayStr = today.toISOString().split('T')[0];
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayStr = yesterday.toISOString().split('T')[0];

  // Must include today or yesterday to have a streak
  const hasToday = sorted.some(d => d.date === todayStr);
  const hasYesterday = sorted.some(d => d.date === yesterdayStr);
  if (!hasToday && !hasYesterday) return 0;

  let streak = 0;
  let checkDate = hasToday ? new Date(today) : new Date(yesterday);

  for (let i = 0; i < sorted.length; i++) {
    const checkStr = checkDate.toISOString().split('T')[0];
    const found = sorted.some(d => d.date === checkStr);
    if (found) {
      streak++;
      checkDate.setDate(checkDate.getDate() - 1);
    } else {
      break;
    }
  }

  return streak;
}
