export type Language = 'ar' | 'en';
export type ThemeMode = 'light' | 'dark' | 'system';
export type OverlayStyle = 'dynamic-island' | 'frosted-glass';
export type Screen = 'welcome' | 'dashboard' | 'counter' | 'statistics' | 'settings';
export type ReminderStatus = 'active' | 'paused' | 'disabled';

export interface AppSettings {
  language: Language;
  theme: ThemeMode;
  overlayStyle: OverlayStyle;
  animationsEnabled: boolean;
  vibrationEnabled: boolean;
  soundEnabled: boolean;
  remindersEnabled: boolean;
  reminderInterval: number; // minutes
  fridayModeEnabled: boolean;
  fridayInterval: number; // minutes
  quietHoursStart: string | null; // "22:00"
  quietHoursEnd: string | null; // "06:00"
  activeHoursStart: string | null; // "06:00"
  activeHoursEnd: string | null; // "23:00"
  screenOffOnly: boolean; // show only when screen is on
  dailyGoal: number;
  overlayTapCounts: boolean;
  tempPauseUntil: number | null; // timestamp
  fridayCalcMethod: 'manual' | 'astronomical';
  manualFridayStart: string; // "18:30"
  manualFridayEnd: string; // "18:30"
  achievementsEnabled: boolean;
}

export interface DayRecord {
  date: string; // "2026-10-16"
  count: number;
}

export interface Stats {
  lifetimeCount: number;
  todayCount: number;
  dailyHistory: DayRecord[];
  milestonesShown: number[];
  personalBestDay: number;
  currentStreak: number;
  lastActiveDate: string | null;
}

export interface Milestone {
  count: number;
  messageAr: string;
  messageEn: string;
}

export const MILESTONES: Milestone[] = [
  { count: 100, messageAr: 'أحسنت، واصل الذكر.', messageEn: 'Well done, keep up the dhikr.' },
  { count: 500, messageAr: 'بارك الله في وقتك، استمر على الخير.', messageEn: 'May Allah bless your time, continue doing good.' },
  { count: 1000, messageAr: 'لقد حققت هدفًا جديدًا، جعل الله ذكرك مباركًا.', messageEn: 'You have reached a new milestone, may Allah make your dhikr blessed.' },
  { count: 2500, messageAr: 'نِعْمَ القلب الذي لا ينسى الصلاة على النبي ﷺ.', messageEn: 'Blessed is the heart that remembers to send blessings upon the Prophet ﷺ.' },
  { count: 5000, messageAr: 'نسأل الله أن يجعلك من الذاكرين الله كثيرًا.', messageEn: 'We ask Allah to make you among those who remember Him often.' },
  { count: 10000, messageAr: 'ثبتك الله على ذكره، وجعلها نورًا لك في الدنيا والآخرة.', messageEn: 'May Allah keep you steadfast in His remembrance, a light for you in this world and the next.' },
];

export const DEFAULT_SETTINGS: AppSettings = {
  language: 'ar',
  theme: 'system',
  overlayStyle: 'dynamic-island',
  animationsEnabled: true,
  vibrationEnabled: false,
  soundEnabled: false,
  remindersEnabled: false,
  reminderInterval: 10,
  fridayModeEnabled: true,
  fridayInterval: 2,
  quietHoursStart: '22:00',
  quietHoursEnd: '06:00',
  activeHoursStart: '06:00',
  activeHoursEnd: '23:00',
  screenOffOnly: true,
  dailyGoal: 100,
  overlayTapCounts: false,
  tempPauseUntil: null,
  fridayCalcMethod: 'manual',
  manualFridayStart: '18:30',
  manualFridayEnd: '18:30',
  achievementsEnabled: true,
};

export const DEFAULT_STATS: Stats = {
  lifetimeCount: 0,
  todayCount: 0,
  dailyHistory: [],
  milestonesShown: [],
  personalBestDay: 0,
  currentStreak: 0,
  lastActiveDate: null,
};

export const INTERVAL_PRESETS = [1, 2, 5, 10, 15, 20, 30, 45, 60];

export const DEFAULT_FRIDAY_INTERVALS = [1, 2, 5, 10, 15, 30];
