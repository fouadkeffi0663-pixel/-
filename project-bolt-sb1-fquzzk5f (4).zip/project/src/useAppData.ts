import { useState, useEffect, useCallback } from 'react';
import type { AppSettings, Stats } from './types';
import { DEFAULT_SETTINGS, DEFAULT_STATS } from './types';

const SETTINGS_KEY = 'dhikr_settings_v1';
const STATS_KEY = 'dhikr_stats_v1';

function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return { ...DEFAULT_SETTINGS };
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_SETTINGS, ...parsed };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

function loadStats(): Stats {
  try {
    const raw = localStorage.getItem(STATS_KEY);
    if (!raw) return { ...DEFAULT_STATS };
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_STATS, ...parsed };
  } catch {
    return { ...DEFAULT_STATS };
  }
}

export function getTodayDate(): string {
  return new Date().toISOString().split('T')[0];
}

export function useAppData() {
  const [settings, setSettings] = useState<AppSettings>(loadSettings);
  const [stats, setStats] = useState<Stats>(loadStats);

  useEffect(() => {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem(STATS_KEY, JSON.stringify(stats));
  }, [stats]);

  const updateSettings = useCallback((partial: Partial<AppSettings>) => {
    setSettings(prev => ({ ...prev, ...partial }));
  }, []);

  const incrementCount = useCallback(() => {
    const today = getTodayDate();
    setStats(prev => {
      const history = [...prev.dailyHistory];
      const todayIdx = history.findIndex(d => d.date === today);
      const newTodayCount = prev.todayCount + 1;

      if (todayIdx >= 0) {
        history[todayIdx] = { ...history[todayIdx], count: history[todayIdx].count + 1 };
      } else {
        history.push({ date: today, count: 1 });
      }

      // Calculate streak
      let streak = prev.currentStreak;
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = yesterday.toISOString().split('T')[0];

      if (prev.lastActiveDate === today) {
        // already counted today, keep streak
      } else if (prev.lastActiveDate === yesterdayStr) {
        streak = prev.currentStreak + 1;
      } else {
        streak = 1;
      }

      return {
        ...prev,
        lifetimeCount: prev.lifetimeCount + 1,
        todayCount: newTodayCount,
        dailyHistory: history,
        personalBestDay: Math.max(prev.personalBestDay, newTodayCount),
        currentStreak: streak,
        lastActiveDate: today,
      };
    });
  }, []);

  const resetTodayCount = useCallback(() => {
    const today = getTodayDate();
    setStats(prev => {
      const history = prev.dailyHistory.map(d =>
        d.date === today ? { ...d, count: 0 } : d
      );
      return { ...prev, todayCount: 0, dailyHistory: history };
    });
  }, []);

  const resetAllStats = useCallback(() => {
    setStats({ ...DEFAULT_STATS });
  }, []);

  const markMilestoneShown = useCallback((count: number) => {
    setStats(prev => ({
      ...prev,
      milestonesShown: [...prev.milestonesShown, count],
    }));
  }, []);

  const correctCount = useCallback((newTodayCount: number) => {
    const today = getTodayDate();
    setStats(prev => {
      const history = [...prev.dailyHistory];
      const todayIdx = history.findIndex(d => d.date === today);
      const diff = newTodayCount - prev.todayCount;
      if (todayIdx >= 0) {
        history[todayIdx] = { ...history[todayIdx], count: newTodayCount };
      } else if (newTodayCount > 0) {
        history.push({ date: today, count: newTodayCount });
      }
      return {
        ...prev,
        todayCount: newTodayCount,
        lifetimeCount: Math.max(0, prev.lifetimeCount + diff),
        dailyHistory: history,
        personalBestDay: Math.max(prev.personalBestDay, newTodayCount),
      };
    });
  }, []);

  return {
    settings,
    stats,
    updateSettings,
    incrementCount,
    resetTodayCount,
    resetAllStats,
    markMilestoneShown,
    correctCount,
  };
}
