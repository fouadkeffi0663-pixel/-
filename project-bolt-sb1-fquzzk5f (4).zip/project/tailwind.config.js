/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        emerald: {
          50: '#f0fdf6',
          100: '#dcfce9',
          200: '#bbf7d0',
          300: '#86efad',
          400: '#4ade80',
          500: '#22c55e',
          600: '#16a34a',
          700: '#15803d',
          800: '#166534',
          850: '#0f4d2a',
          900: '#14532d',
          950: '#052e16',
        },
        midnight: {
          700: '#0a3d2e',
          800: '#073224',
          900: '#052016',
          950: '#031410',
        },
        ivory: {
          50: '#fefdf9',
          100: '#fdf9ee',
          200: '#f9f0d4',
          300: '#f3e3b0',
        },
        champagne: {
          200: '#f0ddaf',
          300: '#e8cd8a',
          400: '#d4af6e',
          500: '#c49a4f',
          600: '#a88038',
        },
        sage: {
          200: '#c4d4b8',
          300: '#a8c098',
          400: '#8ba87a',
          500: '#6f8f5e',
        },
      },
      fontFamily: {
        arabic: ['"Noto Naskh Arabic"', '"Amiri"', 'serif'],
        sans: ['"Noto Sans Arabic"', 'system-ui', 'sans-serif'],
        quran: ['"Amiri"', '"Noto Naskh Arabic"', 'serif'],
      },
      animation: {
        'fade-in': 'fadeIn 0.8s ease-out forwards',
        'fade-in-up': 'fadeInUp 0.7s ease-out forwards',
        'fade-in-down': 'fadeInDown 0.7s ease-out forwards',
        'slide-up': 'slideUp 0.6s ease-out forwards',
        'gentle-pulse': 'gentlePulse 3s ease-in-out infinite',
        'glow': 'glow 4s ease-in-out infinite',
        'float': 'float 6s ease-in-out infinite',
        'scale-in': 'scaleIn 0.5s ease-out forwards',
        'capsule-expand': 'capsuleExpand 0.45s ease-out forwards',
        'shimmer': 'shimmer 3s linear infinite',
      },
      keyframes: {
        fadeIn: { '0%': { opacity: '0' }, '100%': { opacity: '1' } },
        fadeInUp: {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeInDown: {
          '0%': { opacity: '0', transform: 'translateY(-20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(40px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        scaleIn: {
          '0%': { opacity: '0', transform: 'scale(0.9)' },
          '100%': { opacity: '1', transform: 'scale(1)' },
        },
        gentlePulse: {
          '0%, 100%': { opacity: '0.6' },
          '50%': { opacity: '1' },
        },
        glow: {
          '0%, 100%': { boxShadow: '0 0 20px rgba(212, 175, 110, 0.15)' },
          '50%': { boxShadow: '0 0 40px rgba(212, 175, 110, 0.3)' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-8px)' },
        },
        capsuleExpand: {
          '0%': { transform: 'scaleX(0.3)' },
          '100%': { transform: 'scaleX(1)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
      },
    },
  },
  plugins: [],
};
