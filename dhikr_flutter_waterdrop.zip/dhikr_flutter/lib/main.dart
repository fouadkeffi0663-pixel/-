import 'dart:async';
import 'dart:ui' show lerpDouble;

import 'package:flutter/material.dart';

void main() {
  runApp(const DhikrApp());
}

class DhikrApp extends StatefulWidget {
  const DhikrApp({super.key});

  @override
  State<DhikrApp> createState() => _DhikrAppState();
}

class _DhikrAppState extends State<DhikrApp> {
  ThemeMode _themeMode = ThemeMode.light;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ذِكر ﷺ',
      themeMode: _themeMode,
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0B5D3B),
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF7F8F4),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF4FA77C),
          brightness: Brightness.dark,
        ),
      ),
      home: MainScreen(
        onToggleTheme: () {
          setState(() {
            _themeMode =
                _themeMode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
          });
        },
      ),
    );
  }
}

class MainScreen extends StatefulWidget {
  final VoidCallback onToggleTheme;
  const MainScreen({super.key, required this.onToggleTheme});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen>
    with SingleTickerProviderStateMixin {
  bool remindersEnabled = true;
  int interval = 8;
  int count = 0;
  bool fridayMode = false;
  bool _notificationVisible = false;
  Timer? _notificationTimer;
  late final AnimationController _notificationController;

  final intervals = <int>[1, 5, 10, 15, 30, 60];

  @override
  void initState() {
    super.initState();
    _notificationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
      upperBound: 2,
    );
  }

  @override
  void dispose() {
    _notificationTimer?.cancel();
    _notificationController.dispose();
    super.dispose();
  }

  String intervalText(int value) {
    if (value == 60) return 'كل ساعة';
    return 'كل $value دقائق';
  }

  Future<void> _showDhikrNotification() async {
    // لا نسمح بإشعار ثانٍ أثناء دورة الإشعار الحالية.
    if (_notificationVisible || !mounted) return;

    _notificationTimer?.cancel();
    setState(() => _notificationVisible = true);
    _notificationController.value = 0;
    await _notificationController.animateTo(
      1,
      duration: const Duration(milliseconds: 900),
      curve: Curves.easeOutCubic,
    );
    if (!mounted || !_notificationVisible) return;

    // يبقى ظاهرًا قليلًا قبل أن يغادر بسلاسة.
    _notificationTimer = Timer(const Duration(milliseconds: 2200), () async {
      if (!mounted) return;
      await _notificationController.animateTo(
        2,
        duration: const Duration(milliseconds: 700),
        curve: Curves.easeInOutCubic,
      );
      if (mounted) setState(() => _notificationVisible = false);
    });
  }

  void _incrementAndNotify() {
    setState(() => count++);
    _showDhikrNotification();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Stack(
        children: [
          Scaffold(
            appBar: AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0,
              title: const Text(
                'ذِكر ﷺ',
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800),
              ),
              actions: [
                IconButton(
                  tooltip: 'الوضع الليلي',
                  onPressed: widget.onToggleTheme,
                  icon: const Icon(Icons.dark_mode_outlined),
                ),
                const SizedBox(width: 8),
              ],
            ),
            body: SafeArea(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(18, 4, 18, 28),
                children: [
                  Text(
                    'تذكير بسيط بالصلاة على النبي ﷺ',
                    style: TextStyle(
                      color: cs.onSurfaceVariant,
                      fontSize: 15,
                    ),
                  ),
                  const SizedBox(height: 22),
                  Card(
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(28),
                      side: BorderSide(color: cs.outlineVariant),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              const Expanded(
                                child: Text(
                                  'التذكير العام',
                                  style: TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ),
                              Switch(
                                value: remindersEnabled,
                                onChanged: (v) =>
                                    setState(() => remindersEnabled = v),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Align(
                            alignment: Alignment.centerRight,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 13, vertical: 8),
                              decoration: BoxDecoration(
                                color: cs.errorContainer,
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(
                                remindersEnabled ? 'مفعّل' : 'متوقف',
                                style: TextStyle(
                                  color: cs.onErrorContainer,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 18),
                          FilledButton.tonalIcon(
                            onPressed: _incrementAndNotify,
                            icon: const Text('ﷺ',
                                style: TextStyle(fontWeight: FontWeight.bold)),
                            label: const Text(
                              'صل على النبي',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            style: FilledButton.styleFrom(
                              minimumSize: const Size(double.infinity, 56),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(22),
                              ),
                            ),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            'عدد صلواتك اليوم: $count',
                            style: TextStyle(
                              color: cs.onSurfaceVariant,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 28),
                  const Text(
                    'وقت ظهور التذكير',
                    style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: intervals.map((value) {
                      final selected = interval == value;
                      return ChoiceChip(
                        label: Text(intervalText(value)),
                        selected: selected,
                        onSelected: (_) => setState(() => interval = value),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 28),
                  Card(
                    elevation: 0,
                    child: SwitchListTile(
                      value: fridayMode,
                      onChanged: (v) => setState(() => fridayMode = v),
                      title: const Text(
                        'وضع الجمعة',
                        style: TextStyle(fontWeight: FontWeight.w800),
                      ),
                      subtitle: const Text('تخصيص التذكير ليوم الجمعة'),
                      secondary: const Icon(Icons.mosque_outlined),
                    ),
                  ),
                  const SizedBox(height: 18),
                  Card(
                    elevation: 0,
                    child: ListTile(
                      leading: const Icon(Icons.restart_alt),
                      title: const Text(
                        'إعادة العداد',
                        style: TextStyle(fontWeight: FontWeight.w700),
                      ),
                      subtitle: const Text('إرجاع عداد اليوم إلى صفر'),
                      onTap: () => setState(() => count = 0),
                    ),
                  ),
                  const SizedBox(height: 30),
                  Center(
                    child: Text(
                      'صنع من طرف: فؤاد كفي',
                      style: TextStyle(
                        color: cs.onSurfaceVariant,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (_notificationVisible)
            _DhikrFloatingNotification(
          animation: _notificationController,
              colorScheme: cs,
            ),
        ],
      ),
    );
  }
}

class _DhikrFloatingNotification extends StatelessWidget {
  final Animation<double> animation;
  final ColorScheme colorScheme;

  const _DhikrFloatingNotification({
    required this.animation,
    required this.colorScheme,
  });

  @override
  Widget build(BuildContext context) {
    return Positioned(
      left: 18,
      right: 18,
      bottom: 34,
      child: IgnorePointer(
        child: AnimatedBuilder(
          animation: animation,
          builder: (context, child) {
            final isEntering = animation.value <= 1;
            final progress = isEntering ? animation.value : animation.value - 1;
            final eased = Curves.easeOutCubic.transform(
              progress.clamp(0.0, 1.0).toDouble(),
            );
            final width = isEntering
                ? lerpDouble(62, 360, eased)!
                : lerpDouble(360, 62, eased)!;
            final height = isEntering
                ? lerpDouble(48, 66, eased)!
                : lerpDouble(66, 48, eased)!;
            final textOpacity = Curves.easeOut.transform(
              isEntering
                  ? ((animation.value - .28) / .50)
                      .clamp(0.0, 1.0)
                      .toDouble()
                  : (1 - progress).clamp(0.0, 1.0).toDouble(),
            );
            final opacity = isEntering
                ? Curves.easeInOut.transform(animation.value)
                : 1 - Curves.easeInOut.transform(progress);
            final y = isEntering
                ? lerpDouble(130, 0, eased)!
                : lerpDouble(0, -130, eased)!;

            return Center(
              child: Opacity(
                opacity: opacity,
                child: Transform.translate(
                  offset: Offset(0, y),
                  child: Transform.scale(
                    scale: lerpDouble(.82, 1, eased)!,
                    child: PhysicalShape(
                      clipper: WaterDropClipper(
                        pointness: isEntering ? 1 - eased : 0,
                      ),
                      color: colorScheme.primary,
                      elevation: 10,
                      shadowColor: colorScheme.primary.withOpacity(.35),
                      child: SizedBox(
                        width: width,
                        height: height + (isEntering ? 10 : 0),
                        child: Center(
                          child: Opacity(
                            opacity: textOpacity,
                            child: const Padding(
                              padding: EdgeInsets.symmetric(horizontal: 18),
                              child: Text(
                                'صلِّ على النبي ﷺ',
                                maxLines: 1,
                                overflow: TextOverflow.fade,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class WaterDropClipper extends CustomClipper<Path> {
  final double pointness;

  const WaterDropClipper({required this.pointness});

  @override
  Path getClip(Size size) {
    final w = size.width;
    final h = size.height;
    final p = pointness.clamp(0.0, 1.0).toDouble();
    final radius = 25 + (10 * (1 - p));
    final pointDepth = 22 * p;
    final path = Path()..moveTo(radius, 0);

    path.quadraticBezierTo(0, 0, 0, radius);
    path.lineTo(0, h - radius);
    path.quadraticBezierTo(0, h - pointDepth, radius, h - pointDepth);
    path.quadraticBezierTo(w * .28, h - pointDepth, w * .5, h);
    path.quadraticBezierTo(w * .72, h - pointDepth, w - radius, h - pointDepth);
    path.quadraticBezierTo(w, h - pointDepth, w, h - radius);
    path.lineTo(w, radius);
    path.quadraticBezierTo(w, 0, w - radius, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(covariant WaterDropClipper oldClipper) =>
      oldClipper.pointness != pointness;
}
