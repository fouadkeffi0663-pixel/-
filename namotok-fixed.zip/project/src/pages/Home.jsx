import { useState } from "react";

const CheckIcon = () => (
  <svg className="w-5 h-5 text-green-500 shrink-0" fill="currentColor" viewBox="0 0 20 20" aria-hidden="true">
    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
  </svg>
);

const ArrowIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
  </svg>
);

export default function HomePage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeTestimonial, setActiveTestimonial] = useState(0);

  const features = [
    { title: "سريع ومُفعَّل", description: "أداء فائق السرعة مع وقت استجابة منخفض. بني على أحدث التقنيات لضمان تجربة سلسة.", icon: "⚡" },
    { title: "أمان متقدم", description: "حماية قوية مع تشفير وتقنيات أمان حديثة تساعد على حماية بياناتك.", icon: "✓" },
    { title: "دعم مستمر", description: "فريق دعم متخصص لمساعدتك في كل خطوة وضمان تجربة استخدام ممتازة.", icon: "♥" },
    { title: "تحليلات متقدمة", description: "لوحة تحكم واضحة وتقارير مفيدة تساعدك على اتخاذ قرارات مبنية على البيانات.", icon: "▥" },
  ];

  const services = [
    { step: "01", title: "سجّل حسابك", description: "أنشئ حسابك المجاني في دقيقة واحدة فقط." },
    { step: "02", title: "اضبط إعداداتك", description: "خصص المنصة حسب احتياجاتك من خلال واجهة سهلة الاستخدام." },
    { step: "03", title: "ابدأ الآن", description: "استفد من الميزات المتاحة وابدأ بتحقيق أهدافك." },
  ];

  const stats = [
    { number: "50K+", label: "مستخدم" },
    { number: "99.9%", label: "موثوقية" },
    { number: "4.9/5", label: "تقييم" },
    { number: "24/7", label: "دعم" },
  ];

  const testimonials = [
    { name: "أحمد محمد", role: "مؤسس شركة تقنية", content: "منصة رائعة وسهلة الاستخدام. ساعدتنا على تنظيم العمل بطريقة أفضل.", avatar: "أ" },
    { name: "سارة العلي", role: "مديرة تسويق رقمي", content: "الواجهة بسيطة والنتائج واضحة. تجربة استخدام ممتازة.", avatar: "س" },
    { name: "خالد الرشيد", role: "مطور برمجيات", content: "التفاصيل والواجهة مرتبة، والمنصة مريحة جدًا في الاستخدام اليومي.", avatar: "خ" },
  ];

  const footerLinks = {
    المنتج: ["الميزات", "التسعير", "التحديثات", "الأمان"],
    الشركة: ["من نحن", "المدونة", "الوظائف", "الشركاء"],
    الموارد: ["التوثيق", "API", "الدعم", "الأسئلة الشائعة"],
    القانونية: ["الشروط", "الخصوصية", "الكوكيز", "التراخيص"],
  };

  const closeMenu = () => setIsMenuOpen(false);

  return (
    <div dir="rtl" className="min-h-screen bg-white text-gray-900" style={{ fontFamily: "Inter, system-ui, sans-serif" }}>
      <nav className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-md border-b border-gray-100 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <a href="#home" className="flex items-center gap-2" onClick={closeMenu} aria-label="نموتك">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-indigo-500">
                <span className="text-white font-bold text-xl">ن</span>
              </div>
              <span className="text-xl font-bold text-gray-900">نموتك</span>
            </a>

            <div className="hidden md:flex items-center gap-8">
              <a href="#home" className="text-gray-600 hover:text-gray-900 transition-colors font-medium">الرئيسية</a>
              <a href="#features" className="text-gray-600 hover:text-gray-900 transition-colors font-medium">المميزات</a>
              <a href="#services" className="text-gray-600 hover:text-gray-900 transition-colors font-medium">الخدمات</a>
              <a href="#testimonials" className="text-gray-600 hover:text-gray-900 transition-colors font-medium">آراء العملاء</a>
              <a href="#pricing" className="text-gray-600 hover:text-gray-900 transition-colors font-medium">التسعير</a>
            </div>

            <div className="hidden md:flex items-center gap-4">
              <button type="button" className="text-gray-700 font-medium hover:text-gray-900 transition-colors">تسجيل الدخول</button>
              <button type="button" className="px-5 py-2.5 rounded-lg text-white font-medium bg-indigo-500 hover:bg-indigo-600 transition-all">ابدأ مجاناً</button>
            </div>

            <button type="button" className="md:hidden p-2 rounded-lg hover:bg-gray-100" onClick={() => setIsMenuOpen((open) => !open)} aria-label="فتح القائمة" aria-expanded={isMenuOpen}>
              <svg className="w-6 h-6 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                {isMenuOpen ? <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /> : <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />}
              </svg>
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-100 py-4 shadow-lg">
            <div className="flex flex-col gap-2 px-4">
              {[['#home', 'الرئيسية'], ['#features', 'المميزات'], ['#services', 'الخدمات'], ['#testimonials', 'آراء العملاء'], ['#pricing', 'التسعير']].map(([href, label]) => (
                <a key={href} href={href} onClick={closeMenu} className="px-4 py-2 text-gray-700 rounded-lg hover:bg-gray-50 font-medium">{label}</a>
              ))}
              <div className="flex flex-col gap-2 mt-4 pt-4 border-t border-gray-100">
                <button type="button" className="px-4 py-2 text-gray-700 font-medium">تسجيل الدخول</button>
                <button type="button" className="px-4 py-2.5 rounded-lg text-white font-medium bg-indigo-500">ابدأ مجاناً</button>
              </div>
            </div>
          </div>
        )}
      </nav>

      <main id="home">
        <section className="pt-32 pb-20 lg:pt-40 lg:pb-32 overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-4xl mx-auto">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-indigo-50 text-indigo-600 text-sm font-medium mb-8">
                <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
                الإصدار 3.0 متاح الآن
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
                نبني <span className="text-indigo-500">مستقبل</span> رقمياً أفضل
              </h1>
              <p className="text-xl text-gray-600 mb-10 max-w-2xl mx-auto leading-relaxed">
                منصة شاملة تجمع بين القوة والبساطة. حل واحد متكامل لإدارة أعمالك وتحقيق أهدافك الرقمية بكفاءة عالية.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
                <button type="button" className="w-full sm:w-auto px-8 py-4 rounded-xl text-white font-semibold text-lg bg-indigo-500 hover:bg-indigo-600 transition-all shadow-lg hover:-translate-y-0.5">ابدأ تجربتك المجانية</button>
                <button type="button" className="w-full sm:w-auto px-8 py-4 rounded-xl border-2 border-gray-200 text-gray-700 font-semibold text-lg hover:border-gray-300 hover:bg-gray-50 transition-all flex items-center justify-center gap-2">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5v14l11-7z" /></svg>
                  شاهد العرض التوضيحي
                </button>
              </div>
              <div className="flex flex-wrap items-center justify-center gap-6 text-gray-500 text-sm">
                {['بدون بطاقة ائتمان', 'إلغاء في أي وقت', 'دعم فني 24/7'].map((text) => <div key={text} className="flex items-center gap-2"><CheckIcon />{text}</div>)}
              </div>
            </div>

            <div className="mt-16 lg:mt-24 relative">
              <div className="relative mx-auto max-w-5xl">
                <div className="absolute inset-0 bg-gradient-to-t from-white via-transparent to-transparent z-10 pointer-events-none" />
                <div className="absolute -inset-4 bg-gradient-to-r from-indigo-100 via-purple-50 to-indigo-100 rounded-3xl blur-3xl opacity-60" />
                <div className="relative bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden">
                  <div className="flex items-center gap-2 px-4 py-3 bg-gray-50 border-b border-gray-200">
                    <div className="flex gap-1.5"><span className="w-3 h-3 rounded-full bg-red-400" /><span className="w-3 h-3 rounded-full bg-yellow-400" /><span className="w-3 h-3 rounded-full bg-green-400" /></div>
                    <div className="flex-1 mx-4"><div className="bg-white rounded-md px-3 py-1 text-xs text-gray-400 text-center">namtok.com/dashboard</div></div>
                  </div>
                  <div className="p-5 sm:p-8 bg-gray-50">
                    <div className="flex flex-col sm:flex-row gap-5">
                      <aside className="sm:w-44 bg-white rounded-xl border border-gray-200 p-3 space-y-2">
                        {['لوحة التحكم', 'التحليلات', 'المشاريع', 'الإعدادات'].map((item, index) => <div key={item} className={`px-3 py-2 rounded-lg text-sm ${index === 0 ? 'bg-indigo-50 text-indigo-600 font-semibold' : 'text-gray-500'}`}>{item}</div>)}
                      </aside>
                      <div className="flex-1 space-y-5">
                        <div className="flex items-center justify-between"><div><h2 className="text-xl font-bold">لوحة التحكم</h2><p className="text-sm text-gray-500 mt-1">نظرة سريعة على نشاطك</p></div><div className="w-9 h-9 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold">ن</div></div>
                        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">{stats.map((stat) => <div key={stat.label} className="bg-white rounded-xl border border-gray-200 p-4"><div className="text-xl font-bold text-gray-900">{stat.number}</div><div className="text-xs text-gray-500 mt-1">{stat.label}</div></div>)}</div>
                        <div className="bg-white rounded-xl border border-gray-200 p-5"><div className="flex justify-between items-center mb-5"><h3 className="font-semibold">النشاط الأسبوعي</h3><span className="text-xs text-green-600">+18.4%</span></div><div className="h-32 flex items-end gap-2">{[35, 52, 42, 70, 58, 82, 66, 92, 75, 86, 68, 96].map((height, i) => <div key={i} className="flex-1 rounded-t bg-indigo-300" style={{ height: `${height}%` }} />)}</div></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="features" className="py-20 bg-gray-50 scroll-mt-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-14"><p className="text-indigo-500 font-semibold mb-3">المميزات</p><h2 className="text-3xl sm:text-4xl font-bold mb-4">كل ما تحتاجه في مكان واحد</h2><p className="text-gray-600">أدوات مصممة لتكون قوية، واضحة، وسهلة الاستخدام.</p></div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">{features.map((feature) => <article key={feature.title} className="bg-white rounded-2xl border border-gray-100 p-6 shadow-sm hover:shadow-lg transition-shadow"><div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-500 flex items-center justify-center text-xl font-bold mb-5">{feature.icon}</div><h3 className="text-lg font-bold mb-3">{feature.title}</h3><p className="text-gray-600 leading-relaxed text-sm">{feature.description}</p></article>)}</div>
          </div>
        </section>

        <section id="services" className="py-20 scroll-mt-20">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-14"><p className="text-indigo-500 font-semibold mb-3">كيف تعمل</p><h2 className="text-3xl sm:text-4xl font-bold mb-4">ابدأ في ثلاث خطوات بسيطة</h2></div>
            <div className="grid md:grid-cols-3 gap-6">{services.map((service) => <article key={service.step} className="relative rounded-2xl border border-gray-200 p-7 bg-white"><span className="text-5xl font-black text-indigo-100">{service.step}</span><h3 className="text-xl font-bold mt-4 mb-3">{service.title}</h3><p className="text-gray-600 leading-relaxed">{service.description}</p></article>)}</div>
          </div>
        </section>

        <section id="pricing" className="py-20 bg-gray-50 scroll-mt-20">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8"><div className="text-center mb-12"><p className="text-indigo-500 font-semibold mb-3">التسعير</p><h2 className="text-3xl sm:text-4xl font-bold">خطة بسيطة للبدء</h2></div><div className="max-w-md mx-auto bg-white rounded-3xl border-2 border-indigo-100 shadow-xl p-8"><div className="text-center"><h3 className="text-2xl font-bold">مجاني</h3><p className="text-gray-500 mt-2">للبدء وتجربة المنصة</p><div className="my-7"><span className="text-5xl font-black">0</span><span className="text-gray-500"> دج</span></div></div><ul className="space-y-4 text-gray-600">{['الوصول إلى المميزات الأساسية', 'لوحة تحكم واضحة', 'تحديثات مستمرة', 'دعم للمستخدمين'].map((item) => <li key={item} className="flex items-center gap-3"><CheckIcon />{item}</li>)}</ul><button type="button" className="w-full mt-8 py-3.5 rounded-xl bg-indigo-500 hover:bg-indigo-600 text-white font-semibold">ابدأ مجاناً</button></div></div>
        </section>

        <section id="testimonials" className="py-20 scroll-mt-20">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8"><div className="text-center mb-12"><p className="text-indigo-500 font-semibold mb-3">آراء العملاء</p><h2 className="text-3xl sm:text-4xl font-bold">ماذا يقول المستخدمون؟</h2></div><div className="bg-gray-50 rounded-3xl p-7 sm:p-10"><div className="flex items-center gap-4 mb-6"><div className="w-14 h-14 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center text-xl font-bold">{testimonials[activeTestimonial].avatar}</div><div><h3 className="font-bold">{testimonials[activeTestimonial].name}</h3><p className="text-sm text-gray-500">{testimonials[activeTestimonial].role}</p></div></div><p className="text-xl text-gray-700 leading-relaxed min-h-20">“{testimonials[activeTestimonial].content}”</p><div className="flex items-center justify-between mt-8"><button type="button" className="p-3 rounded-full bg-white border border-gray-200 hover:bg-gray-100" onClick={() => setActiveTestimonial((i) => (i - 1 + testimonials.length) % testimonials.length)} aria-label="السابق"><ArrowIcon /></button><div className="flex gap-2">{testimonials.map((_, i) => <button type="button" key={i} onClick={() => setActiveTestimonial(i)} aria-label={`العميل ${i + 1}`} className={`w-2.5 h-2.5 rounded-full ${i === activeTestimonial ? 'bg-indigo-500' : 'bg-gray-300'}`} />)}</div><button type="button" className="p-3 rounded-full bg-white border border-gray-200 hover:bg-gray-100 rotate-180" onClick={() => setActiveTestimonial((i) => (i + 1) % testimonials.length)} aria-label="التالي"><ArrowIcon /></button></div></div></div>
        </section>
      </main>

      <footer className="bg-gray-950 text-gray-300 pt-14 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"><div className="grid grid-cols-2 md:grid-cols-4 gap-8 pb-10 border-b border-white/10">{Object.entries(footerLinks).map(([group, links]) => <div key={group}><h3 className="text-white font-bold mb-4">{group}</h3><ul className="space-y-3">{links.map((link) => <li key={link}><a href="#home" className="text-sm hover:text-white transition-colors">{link}</a></li>)}</ul></div>)}</div><div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-6 text-sm text-gray-500"><span>© 2026 نموتك. جميع الحقوق محفوظة.</span><span>صنع من طرف: فؤاد كفي</span></div></div>
      </footer>
    </div>
  );
}
