# ذِكر ﷺ

تطبيق Android عربي بسيط للتذكير بالصلاة على النبي ﷺ. مبني باستخدام Kotlin وJetpack Compose وDataStore وAlarmManager.

## البناء محليًا

1. افتح المشروع في Android Studio.
2. استخدم JDK 17 أو أحدث وAndroid SDK 35.
3. شغّل `./gradlew assembleDebug`.

## البناء على GitHub

يحتوي المشروع على GitHub Actions في `.github/workflows/android.yml`. بعد رفع المشروع إلى GitHub وتشغيل workflow، سيظهر ملف APK في قسم **Actions → Artifacts**.

## ملاحظات

يتطلب التذكير العائم تفعيل صلاحية **الظهور فوق التطبيقات الأخرى** من إعدادات Android. نسخة Release تحتاج توقيعًا بمفتاح إصدار قبل النشر.
