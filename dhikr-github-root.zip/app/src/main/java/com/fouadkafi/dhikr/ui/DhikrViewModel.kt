package com.fouadkafi.dhikr.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fouadkafi.dhikr.data.SettingsRepository
import com.fouadkafi.dhikr.model.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DhikrViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SettingsRepository(app)
    val settings = repo.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())
    fun setOnboardingDone() = change { this[androidx.datastore.preferences.core.booleanPreferencesKey("onboarding")] = true }
    fun setEnabled(v: Boolean) = change { this[androidx.datastore.preferences.core.booleanPreferencesKey("enabled")] = v }
    fun setInterval(v: Int) = change { this[androidx.datastore.preferences.core.intPreferencesKey("interval")] = v }
    fun setFriday(v: Boolean) = change { this[androidx.datastore.preferences.core.booleanPreferencesKey("friday")] = v }
    fun setPosition(v: FloatingPosition) = change { this[androidx.datastore.preferences.core.stringPreferencesKey("position")] = if (v == FloatingPosition.TOP_LEFT) "left" else "right" }
    fun setTheme(v: ThemeMode) = change { this[androidx.datastore.preferences.core.stringPreferencesKey("theme")] = when(v) { ThemeMode.LIGHT -> "light"; ThemeMode.DARK -> "dark"; ThemeMode.SYSTEM -> "system" } }
    private fun change(block: androidx.datastore.preferences.core.MutablePreferences.() -> Unit) = viewModelScope.launch { repo.update(block) }
}
