package com.fouadkafi.dhikr.overlay

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.TextView
import android.graphics.drawable.GradientDrawable

class ReminderOverlayService : Service() {
    private var window: WindowManager? = null
    private var view: TextView? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        show(intent?.getBooleanExtra("friday", false) == true, intent?.getBooleanExtra("left", false) == true)
        Handler(Looper.getMainLooper()).postDelayed({ remove(); stopSelf() }, 6500)
        return START_NOT_STICKY
    }
    private fun show(friday: Boolean, left: Boolean) {
        remove(); window = getSystemService(WINDOW_SERVICE) as WindowManager
        view = TextView(this).apply {
            text = "صلِ على النبي ﷺ"; textSize = if (friday) 19f else 17f; setTextColor(Color.rgb(35, 54, 42)); gravity = Gravity.CENTER; setPadding(26, 12, 26, 12); alpha = .97f
            background = GradientDrawable().apply { setColor(Color.argb(238, 250, 220, 120)); setStroke(2, Color.rgb(35, 105, 72)); cornerRadius = 30f }
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or if (left) Gravity.LEFT else Gravity.RIGHT; x = 18; y = 58
        }
        try { window?.addView(view, params) } catch (_: Exception) { remove() }
    }
    private fun remove() { try { view?.let { window?.removeView(it) } } catch (_: Exception) {}; view = null }
    override fun onDestroy() { remove(); super.onDestroy() }
    override fun onBind(intent: Intent?) = null
}
