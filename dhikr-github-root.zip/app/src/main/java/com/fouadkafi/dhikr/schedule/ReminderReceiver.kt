package com.fouadkafi.dhikr.schedule

import android.content.*
import com.fouadkafi.dhikr.data.SettingsRepository
import com.fouadkafi.dhikr.model.AppSettings
import com.fouadkafi.dhikr.overlay.ReminderOverlayService
import com.fouadkafi.dhikr.util.FridayCalculator
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val settings = SettingsRepository(context.applicationContext).settings.first()
                if (settings.reminderEnabled) {
                    val friday = settings.fridayMode && FridayCalculator.isFridayMode()
                    val effective = settings.copy(intervalMinutes = if (friday) 1 else settings.intervalMinutes)
                    context.startService(Intent(context, ReminderOverlayService::class.java).putExtra("friday", friday).putExtra("left", effective.position.name == "TOP_LEFT"))
                    ReminderScheduler.schedule(context, effective)
                }
            } finally { pending.finish() }
        }
    }
}
