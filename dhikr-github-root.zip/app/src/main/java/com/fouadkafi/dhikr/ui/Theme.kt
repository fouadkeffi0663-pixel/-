package com.fouadkafi.dhikr.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.fouadkafi.dhikr.model.ThemeMode

private val Green = Color(0xFF236B4A)
private val Gold = Color(0xFFE8B94E)
@Composable fun DhikrTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when(mode) { ThemeMode.DARK -> true; ThemeMode.LIGHT -> false; ThemeMode.SYSTEM -> isSystemInDarkTheme() }
    val scheme = if (dark) darkColorScheme(primary = Color(0xFF8BD5A7), secondary = Gold, surface = Color(0xFF142019)) else lightColorScheme(primary = Green, secondary = Color(0xFFB27C08), surface = Color(0xFFFFFBF3), background = Color(0xFFFFFBF3))
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}
