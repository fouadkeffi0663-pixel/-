package com.fouadkafi.dhikr.schedule

import android.content.*
import com.fouadkafi.dhikr.data.SettingsRepository
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch { try { ReminderScheduler.schedule(context, SettingsRepository(context.applicationContext).settings.first()) } finally { pending.finish() } }
    }
}
