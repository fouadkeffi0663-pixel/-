package com.fouadkafi.dhikr.util

import java.time.*

object FridayCalculator {
    /** Conservative offline approximation: local solar sunset is unavailable without location; use 18:00 fallback. */
    fun isFridayMode(now: ZonedDateTime = ZonedDateTime.now()): Boolean {
        val day = now.dayOfWeek
        val sunset = LocalTime.of(18, 0)
        return (day == DayOfWeek.THURSDAY && now.toLocalTime() >= sunset) ||
            (day == DayOfWeek.FRIDAY && now.toLocalTime() < sunset)
    }
}
