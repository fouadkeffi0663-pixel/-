package com.fouadkafi.dhikr.schedule

import android.app.*
import android.content.*
import com.fouadkafi.dhikr.model.AppSettings
import java.util.concurrent.TimeUnit

object ReminderScheduler {
    private const val REQUEST = 9017
    fun schedule(context: Context, settings: AppSettings) {
        cancel(context)
        if (!settings.reminderEnabled) return
        val alarm = context.getSystemService(AlarmManager::class.java)
        val intent = Intent(context, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(context, REQUEST, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val delay = TimeUnit.MINUTES.toMillis(settings.intervalMinutes.toLong())
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + delay, pending)
    }
    fun cancel(context: Context) {
        val pending = PendingIntent.getBroadcast(context, REQUEST, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
        if (pending != null) context.getSystemService(AlarmManager::class.java).cancel(pending)
    }
}
