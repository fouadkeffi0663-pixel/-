package com.fouadkafi.dhikr

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import com.fouadkafi.dhikr.model.*
import com.fouadkafi.dhikr.schedule.ReminderScheduler
import com.fouadkafi.dhikr.ui.*

class MainActivity : ComponentActivity() {
    private val overlayLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { val vm: DhikrViewModel = viewModel(); val settings by vm.settings.collectAsState(); DhikrTheme(settings.theme) { CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { LaunchedEffect(settings) { ReminderScheduler.schedule(this@MainActivity, settings) }; if (!settings.onboardingDone) Onboarding { vm.setOnboardingDone() } else MainScreen(settings, vm) } } } }
    override fun onResume() { super.onResume() }
    fun openOverlaySettings() { overlayLauncher.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }

    @Composable private fun Onboarding(done: () -> Unit) {
        val pager = rememberPagerState(pageCount = { 3 }); val scope = rememberCoroutineScope(); val titles = listOf("ذكرٌ جميل في كل يوم", "فضل الصلاة على النبي ﷺ", "تذكير لطيف، بلا إزعاج"); val bodies = listOf("اجعل الصلاة على النبي ﷺ عادةً هادئة ترافق يومك.", "قال الله تعالى: إِنَّ اللَّهَ وَمَلَائِكَتَهُ يُصَلُّونَ عَلَى النَّبِيِّ ۚ يَا أَيُّهَا الَّذِينَ آمَنُوا صَلُّوا عَلَيْهِ وَسَلِّمُوا تَسْلِيمًا\n\nسورة الأحزاب: 56", "يظهر ذِكر ﷺ تذكيراً عائماً صغيراً فوق التطبيقات في الأوقات التي تختارها.")
        Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) { TextButton(onClick = done) { Text("تخطي") } }
            HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { page -> Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Box(Modifier.size(150.dp).background(MaterialTheme.colorScheme.primary.copy(.12f), RoundedCornerShape(48.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(70.dp)) }; Spacer(Modifier.height(34.dp)); Text(titles[page], style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Spacer(Modifier.height(16.dp)); Text(bodies[page], style = MaterialTheme.typography.bodyLarge, lineHeight = 30.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center) } }
            Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) { repeat(3) { i -> Box(Modifier.padding(4.dp).size(if (pager.currentPage == i) 22.dp else 8.dp, 8.dp).background(if (pager.currentPage == i) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))) } }
            Spacer(Modifier.height(20.dp)); Button(onClick = { if (pager.currentPage == 2) done() else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } }, modifier = Modifier.fillMaxWidth().height(54.dp)) { Text(if (pager.currentPage == 2) "ابدأ الآن" else "التالي", fontSize = 17.sp) }
            if (pager.currentPage > 0) TextButton(onClick = { /* swipe/back handles navigation */ }) { Text("اسحب للعودة") }
        }
    }

    @Composable private fun MainScreen(s: AppSettings, vm: DhikrViewModel) {
        var custom by remember { mutableStateOf(false) }; var showSettings by remember { mutableStateOf(false) }; val allowed = Settings.canDrawOverlays(this)
        val intervals = listOf(1 to "دقيقة واحدة", 5 to "5 دقائق", 10 to "10 دقائق", 15 to "15 دقيقة", 30 to "30 دقيقة", 60 to "ساعة", 120 to "ساعتان", 180 to "3 ساعات")
        Scaffold { pad -> Column(Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 18.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Column { Text("ذِكر ﷺ", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text("تذكير بسيط بالصلاة على النبي ﷺ", color = MaterialTheme.colorScheme.onSurfaceVariant) }; IconButton(onClick = { showSettings = !showSettings }) { Icon(Icons.Default.Settings, "الإعدادات") } }
            Spacer(Modifier.height(24.dp)); Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), shape = RoundedCornerShape(24.dp)) { Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Column { Text("التذكير العائم", fontWeight = FontWeight.Bold); Text(if (s.reminderEnabled && allowed) "●  فعّال" else "○  غير فعّال", color = if (s.reminderEnabled && allowed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant) }; Switch(checked = s.reminderEnabled, onCheckedChange = { vm.setEnabled(it) }) } }
            if (!allowed) { Spacer(Modifier.height(14.dp)); OutlinedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text("يلزم تفعيل الظهور فوق التطبيقات", fontWeight = FontWeight.Bold); Text("حتى يظهر التذكير الصغير فوق التطبيقات الأخرى.", color = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(8.dp)); Button(onClick = { openOverlaySettings() }) { Text("إدارة الصلاحية") } } } }
            Spacer(Modifier.height(24.dp)); Text("وقت ظهور التذكير", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); Card(shape = RoundedCornerShape(18.dp)) { Column { intervals.forEach { (v, label) -> Row(Modifier.fillMaxWidth().clickable { vm.setInterval(v) }.padding(horizontal = 16.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) { RadioButton(v == s.intervalMinutes, { vm.setInterval(v) }); Text(label) } }; Row(Modifier.fillMaxWidth().clickable { custom = true }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Edit, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(12.dp)); Text("وقت مخصص") } } }
            Spacer(Modifier.height(22.dp)); SettingRow("وضع الجمعة", "يعمل تلقائياً من مغرب الخميس إلى مغرب الجمعة.", s.fridayMode, vm::setFriday); Spacer(Modifier.height(12.dp)); Text("موقع التذكير", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Row { FilterChip(selected = s.position == FloatingPosition.TOP_RIGHT, onClick = { vm.setPosition(FloatingPosition.TOP_RIGHT) }, label = { Text("أعلى اليمين") }); Spacer(Modifier.width(8.dp)); FilterChip(selected = s.position == FloatingPosition.TOP_LEFT, onClick = { vm.setPosition(FloatingPosition.TOP_LEFT) }, label = { Text("أعلى اليسار") }) }
            Spacer(Modifier.height(18.dp)); Text("مظهر التطبيق", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Row { listOf(ThemeMode.SYSTEM to "تلقائي", ThemeMode.LIGHT to "فاتح", ThemeMode.DARK to "داكن").forEach { (m, label) -> FilterChip(selected = s.theme == m, onClick = { vm.setTheme(m) }, label = { Text(label) }); Spacer(Modifier.width(6.dp)) } }
            Spacer(Modifier.height(28.dp)); HorizontalDivider(); Spacer(Modifier.height(18.dp)); Text("ذِكر ﷺ  •  الإصدار 1.0.0", color = MaterialTheme.colorScheme.onSurfaceVariant); Text("صنع من طرف: فؤاد كفي", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        } }
        if (custom) CustomDialog(s.intervalMinutes, { vm.setInterval(it); custom = false }, { custom = false })
    }
    @Composable private fun SettingRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Switch(checked, onChange) } }
    @Composable private fun CustomDialog(current: Int, save: (Int) -> Unit, close: () -> Unit) { var text by remember { mutableStateOf(current.toString()) }; var hours by remember { mutableStateOf(false) }; AlertDialog(onDismissRequest = close, title = { Text("وقت مخصص") }, text = { Column { OutlinedTextField(text, { text = it.filter(Char::isDigit) }, label = { Text(if (hours) "عدد الساعات" else "عدد الدقائق") }, singleLine = true); Row(verticalAlignment = Alignment.CenterVertically) { RadioButton(!hours, { hours = false }); Text("دقائق"); RadioButton(hours, { hours = true }); Text("ساعات") } } }, confirmButton = { TextButton(onClick = { val n = text.toIntOrNull(); if (n != null && n > 0) save(if (hours) n * 60 else n) }) { Text("حفظ") } }, dismissButton = { TextButton(onClick = close) { Text("إلغاء") } }) }
}
