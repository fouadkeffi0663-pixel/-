package com.fouadkafi.dhikr.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.fouadkafi.dhikr.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

data class SettingsRepository(private val context: Context) {
    private val store get() = context.settingsDataStore
    val settings: Flow<AppSettings> = store.data.map { p ->
        AppSettings(
            p[Keys.ONBOARDING] ?: false, p[Keys.ENABLED] ?: false,
            p[Keys.INTERVAL] ?: 10, p[Keys.FRIDAY] ?: true,
            if ((p[Keys.POSITION] ?: "right") == "left") FloatingPosition.TOP_LEFT else FloatingPosition.TOP_RIGHT,
            when (p[Keys.THEME] ?: "system") { "light" -> ThemeMode.LIGHT; "dark" -> ThemeMode.DARK; else -> ThemeMode.SYSTEM }
        )
    }
    suspend fun update(block: MutablePreferences.() -> Unit) = store.edit(block)
    private object Keys { val ONBOARDING = booleanPreferencesKey("onboarding"); val ENABLED = booleanPreferencesKey("enabled"); val INTERVAL = intPreferencesKey("interval"); val FRIDAY = booleanPreferencesKey("friday"); val POSITION = stringPreferencesKey("position"); val THEME = stringPreferencesKey("theme") }
}
private val Context.settingsDataStore by preferencesDataStore("dhikr_settings")
