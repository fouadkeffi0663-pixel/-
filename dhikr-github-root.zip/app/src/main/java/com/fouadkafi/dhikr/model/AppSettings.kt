package com.fouadkafi.dhikr.model

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class FloatingPosition { TOP_RIGHT, TOP_LEFT }
data class AppSettings(
    val onboardingDone: Boolean = false,
    val reminderEnabled: Boolean = false,
    val intervalMinutes: Int = 10,
    val fridayMode: Boolean = true,
    val position: FloatingPosition = FloatingPosition.TOP_RIGHT,
    val theme: ThemeMode = ThemeMode.SYSTEM
)
