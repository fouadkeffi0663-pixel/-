from PIL import Image, ImageDraw, ImageFont
try:
    import arabic_reshaper
    from bidi.algorithm import get_display
    def ar(s): return get_display(arabic_reshaper.reshape(s))
except Exception:
    def ar(s): return s
size=432
im=Image.new('RGB',(size,size),(35,107,74)); d=ImageDraw.Draw(im)
# subtle gold crescent and frame
d.rounded_rectangle((14,14,418,418), radius=92, outline=(232,185,78), width=10)
d.ellipse((106,74,326,294), outline=(232,185,78), width=8)
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
f=ImageFont.truetype(font,76)
text=ar('ذِكر ﷺ')
b=d.textbbox((0,0),text,font=f)
d.text(((size-(b[2]-b[0]))/2,205),text,font=f,fill=(255,248,232),stroke_width=1)
im.save('/home/ubuntu/dhikr/app/src/main/res/drawable/ic_launcher.png')
