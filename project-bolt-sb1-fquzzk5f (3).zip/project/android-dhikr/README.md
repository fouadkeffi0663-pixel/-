# ذِكر ﷺ — Dhikr Android App

تطبيق أندرويد أصلي لتذكير المستخدم بالصلاة على النبي ﷺ، مع تذكير عائم يظهر فوق التطبيقات الأخرى.

Native Android app for reminding users to send blessings upon Prophet Muhammad ﷺ, with a floating overlay reminder that appears over other apps.

**المطوّر:** صنع من طرف فؤاد كفي

---

## المتطلبات / Requirements

- **JDK 17** (OpenJDK 17 أو أعلى)
- **Android SDK** — compileSdk 34, minSdk 26
- **Gradle 8.5** (مُضمّن عبر Gradle Wrapper)
- **Kotlin 1.9.22**
- **Android Studio** (أوصي بإصدار Hedgehog أو أحدث) — الأسهل

---

## بناء المشروع / Build Instructions

### الطريقة 1: باستخدام Android Studio (الأسهل)

1. افتح Android Studio
2. اختر `Open` ثم حدّد مجلد `android-dhikr`
3. انتظر حتى يكتمل Gradle Sync
4. اضغط `Build > Build Bundle(s) / APK(s) > Build APK(s)`
5. سيظهر ملف APK في:
   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```

### الطريقة 2: باستخدام سطر الأوامر

```bash
# 1. تأكد من تثبيت JDK 17
java -version

# 2. عيّن ANDROID_HOME
export ANDROID_HOME=/path/to/android/sdk

# 3. امنح صلاحية التنفيذ للـ wrapper
chmod +x gradlew

# 4. ابنِ ملف APK
./gradlew assembleDebug

# 5. ملف APK سيكون في:
# app/build/outputs/apk/debug/app-debug.apk
```

### بناء نسخة موقّعة (Release APK)

```bash
# 1. أنشئ ملف keystore
keytool -genkey -v -keystore dhikr-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias dhikr

# 2. أضف إلى gradle.properties أو ~/.gradle/gradle.properties:
# DHIKR_STORE_FILE=/path/to/dhikr-key.jks
# DHIKR_STORE_PASSWORD=your_password
# DHIKR_KEY_ALIAS=dhikr
# DHIKR_KEY_PASSWORD=your_password

# 3. ابنِ النسخة الموقّعة
./gradlew assembleRelease
```

---

## تثبيت التطبيق / Install on Phone

```bash
# عبر ADB
adb install app/build/outputs/apk/debug/app-debug.apk

# أو انسخ ملف APK إلى هاتفك وثبّته يدويًا
```

بعد التثبيت:
1. افتح التطبيق
2. اضغط "ابدأ"
3. امنح إذن "العرض فوق التطبيقات الأخرى" من إعدادات النظام
4. فعّل التذكيرات
5. سيظهر التذكير العائم فوق التطبيقات الأخرى

---

## الميزات / Features

- ✅ تذكير عائم أصلي باستخدام WindowManager + ComposeView
- ✅ واجهة Jetpack Compose مع Material 3
- ✅ خلفية زمردية مع زخارف إسلامية ذهبية
- ✅ دعم اللغة العربية (RTL) والإنجليزية
- ✅ وضع الجمعة (من غروب الخميس إلى غروب الجمعة)
- ✅ عداد الذكر مع الإحصائيات
- ✅ جدولة التذكيرات باستخدام AlarmManager
- ✅ حفظ البيانات محليًا باستخدام DataStore
- ✅ إنجازات (100، 500، 1000، 2500، 5000، 10000)
- ✅ سمة فاتحة وداكنة وتلقائية
- ✅ بدون إعلانات أو تتبع

---

## التقنيات / Tech Stack

- Kotlin
- Jetpack Compose
- Material 3
- DataStore (الإعدادات)
- AlarmManager (الجدولة)
- WindowManager (العرض العائم)
- Coroutines & Flow

---

## هيكل المشروع / Project Structure

```
android-dhikr/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── gradle/wrapper/
│   └── gradle-wrapper.properties
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/
        ├── main/
        │   ├── AndroidManifest.xml
        │   ├── java/com/fouadkafi/dhikr/
        │   │   ├── DhikrApp.kt
        │   │   ├── MainActivity.kt
        │   │   ├── domain/
        │   │   │   └── Models.kt
        │   │   ├── data/
        │   │   │   ├── SettingsManager.kt
        │   │   │   └── StatsManager.kt
        │   │   ├── overlay/
        │   │   │   └── OverlayService.kt
        │   │   ├── scheduling/
        │   │   │   ├── ReminderScheduler.kt
        │   │   │   ├── ReminderReceiver.kt
        │   │   │   └── BootReceiver.kt
        │   │   ├── friday/
        │   │   │   └── FridayChecker.kt
        │   │   └── ui/
        │   │       ├── theme/Theme.kt
        │   │       ├── components/IslamicComponents.kt
        │   │       └── screens/
        │   │           ├── WelcomeScreen.kt
        │   │           ├── DashboardScreen.kt
        │   │           ├── CounterScreen.kt
        │   │           ├── StatisticsScreen.kt
        │   │           └── SettingsScreen.kt
        │   └── res/
        │       ├── values/ (strings, colors, themes)
        │       ├── values-ar/ (Arabic strings)
        │       ├── values-en/ (English strings)
        │       ├── values-night/ (dark themes)
        │       ├── drawable/ (launcher icon)
        │       └── mipmap-anydpi-v26/ (adaptive icons)
        └── test/
            └── java/com/fouadkafi/dhikr/
                ├── FridayCheckerTest.kt
                └── IntervalValidationTest.kt
```

---

## القيود / Limitations

- لا يمكن بناء APK في هذه البيئة (لا يوجد Android SDK / JDK)
- يجب البناء على جهاز به Android Studio أو JDK 17 + Android SDK
- الجدولة الدقيقة قد تتأثر بقيود البطارية و Doze mode على بعض الأجهزة
- حساب غروب الشمس الفلكي تقريبي (18:30) — يُنصح بإضافة مكتبة Adhan لحساب دقيق
- اختبارات الوحدة مكتوبة لكن لم يتم تشغيلها (تتطلب بيئة Gradle)

---

## ملاحظة / Note

هذا مشروع Android أصلي بـ Kotlin و Jetpack Compose — وليس تطبيق ويب أو WebView. التذكير العائم يستخدم `WindowManager` و `TYPE_APPLICATION_OVERLAY` و `ComposeView` كما هو مطلوب.

المطوّر: **صنع من طرف فؤاد كفي**
