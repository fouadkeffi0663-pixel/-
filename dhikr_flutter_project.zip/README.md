# ذِكر ﷺ

A simple modern Arabic Salawat reminder app built with Flutter.

The GitHub Actions workflow builds a release Android APK automatically.
