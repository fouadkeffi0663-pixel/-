import 'package:flutter/material.dart';

void main() {
  runApp(const DhikrApp());
}

class DhikrApp extends StatefulWidget {
  const DhikrApp({super.key});

  @override
  State<DhikrApp> createState() => _DhikrAppState();
}

class _DhikrAppState extends State<DhikrApp> {
  ThemeMode _themeMode = ThemeMode.light;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ذِكر ﷺ',
      themeMode: _themeMode,
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0B5D3B),
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF7F8F4),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF4FA77C),
          brightness: Brightness.dark,
        ),
      ),
      home: MainScreen(
        onToggleTheme: () {
          setState(() {
            _themeMode =
                _themeMode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark;
          });
        },
      ),
    );
  }
}

class MainScreen extends StatefulWidget {
  final VoidCallback onToggleTheme;
  const MainScreen({super.key, required this.onToggleTheme});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  bool remindersEnabled = true;
  int interval = 8;
  int count = 0;
  bool fridayMode = false;

  final intervals = <int>[1, 5, 10, 15, 30, 60];

  String intervalText(int value) {
    if (value == 60) return 'كل ساعة';
    return 'كل $value دقائق';
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          title: const Text(
            'ذِكر ﷺ',
            style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800),
          ),
          actions: [
            IconButton(
              tooltip: 'الوضع الليلي',
              onPressed: widget.onToggleTheme,
              icon: const Icon(Icons.dark_mode_outlined),
            ),
            const SizedBox(width: 8),
          ],
        ),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(18, 4, 18, 28),
            children: [
              Text(
                'تذكير بسيط بالصلاة على النبي ﷺ',
                style: TextStyle(
                  color: cs.onSurfaceVariant,
                  fontSize: 15,
                ),
              ),
              const SizedBox(height: 22),

              Card(
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(28),
                  side: BorderSide(color: cs.outlineVariant),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              'التذكير العام',
                              style: const TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                          Switch(
                            value: remindersEnabled,
                            onChanged: (v) =>
                                setState(() => remindersEnabled = v),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Align(
                        alignment: Alignment.centerRight,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 13, vertical: 8),
                          decoration: BoxDecoration(
                            color: cs.errorContainer,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            remindersEnabled ? 'مفعّل' : 'متوقف',
                            style: TextStyle(
                              color: cs.onErrorContainer,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 18),
                      FilledButton.tonalIcon(
                        onPressed: () => setState(() => count++),
                        icon: const Text('ﷺ',
                            style: TextStyle(fontWeight: FontWeight.bold)),
                        label: const Text(
                          'صل على النبي',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        style: FilledButton.styleFrom(
                          minimumSize: const Size(double.infinity, 56),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(22),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'عدد صلواتك اليوم: $count',
                        style: TextStyle(
                          color: cs.onSurfaceVariant,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 28),
              const Text(
                'وقت ظهور التذكير',
                style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 12),

              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: intervals.map((value) {
                  final selected = interval == value;
                  return ChoiceChip(
                    label: Text(intervalText(value)),
                    selected: selected,
                    onSelected: (_) => setState(() => interval = value),
                  );
                }).toList(),
              ),

              const SizedBox(height: 28),
              Card(
                elevation: 0,
                child: SwitchListTile(
                  value: fridayMode,
                  onChanged: (v) => setState(() => fridayMode = v),
                  title: const Text(
                    'وضع الجمعة',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: const Text('تخصيص التذكير ليوم الجمعة'),
                  secondary: const Icon(Icons.mosque_outlined),
                ),
              ),

              const SizedBox(height: 18),
              Card(
                elevation: 0,
                child: ListTile(
                  leading: const Icon(Icons.restart_alt),
                  title: const Text(
                    'إعادة العداد',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                  subtitle: const Text('إرجاع عداد اليوم إلى صفر'),
                  onTap: () => setState(() => count = 0),
                ),
              ),

              const SizedBox(height: 30),
              Center(
                child: Text(
                  'صنع من طرف: فؤاد كفي',
                  style: TextStyle(
                    color: cs.onSurfaceVariant,
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
